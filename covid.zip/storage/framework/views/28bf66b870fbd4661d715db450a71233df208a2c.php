<footer class="footer">
    <div class="container-fluid">
        
        <div class="copyright">
            &copy; <?php echo e(now()->year); ?> <?php echo e(__('Copyright')); ?> <i class="fa fa-thumbs-up"></i> <?php echo e(__('@')); ?>

            <a href="" target="_blank"><?php echo e(__('Peter Gondi')); ?></a> &amp;
        </div>
    </div>
</footer>
<?php /**PATH C:\xampp\htdocs\covid\resources\views/layouts/footer.blade.php ENDPATH**/ ?>