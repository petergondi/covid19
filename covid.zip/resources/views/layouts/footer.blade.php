<footer class="footer">
    <div class="container-fluid">
        
        <div class="copyright">
            &copy; {{ now()->year }} {{ __('Copyright') }} <i class="fa fa-thumbs-up"></i> {{ __('@') }}
            <a href="" target="_blank">{{ __('Peter Gondi') }}</a> &amp;
        </div>
    </div>
</footer>
