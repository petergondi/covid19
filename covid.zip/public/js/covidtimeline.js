var covid_us_timeline=[
    {
      "date": "2020-01-22",
      "list": [
        
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-47"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-46"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-45"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-44"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-43"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-42"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-41"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-40"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-39"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-38"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-37"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-36"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-35"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-34"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-33"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-32"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-31"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-30"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-29"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-28"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-27"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-26"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-25"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-24"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-23"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-22"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-21"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-20"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-19"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-18"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-17"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-16"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-15"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-14"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-13"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-12"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-11"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-10"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-9"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-8"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-7"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-6"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-5"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-4"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-3"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-2"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-1"
        }
      ]
    },
    {
      "date": "2020-01-23",
      "list": [
       
      
        
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-47"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-46"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-45"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-44"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-43"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-42"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-41"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-40"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-39"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-38"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-37"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-36"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-35"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-34"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-33"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-32"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-31"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-30"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-29"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-28"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-27"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-26"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-25"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-24"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-23"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-22"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-21"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-20"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-19"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-18"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-17"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-16"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-15"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-14"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-13"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-12"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-11"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-10"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-9"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-8"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-7"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-6"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-5"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-4"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-3"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-2"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-1"
        }
      ]
    },
    {
      "date": "2020-01-24",
      "list": [
        
       
       
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-47"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-46"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-45"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-44"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-43"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-42"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-41"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-40"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-39"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-38"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-37"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-36"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-35"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-34"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-33"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-32"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-31"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-30"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-29"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-28"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-27"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-26"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-25"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-24"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-23"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-22"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-21"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-20"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-19"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-18"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-17"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-16"
        },
        {
          "confirmed": 1,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-15"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-14"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-13"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-12"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-11"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-10"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-9"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-8"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-7"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-6"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-5"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-4"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-3"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-2"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-1"
        }
      ]
    },
    {
      "date": "2020-01-25",
      "list": [
       
       
        
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-47"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-46"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-45"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-44"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-43"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-42"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-41"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-40"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-39"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-38"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-37"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-36"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-35"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-34"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-33"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-32"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-31"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-30"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-29"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-28"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-27"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-26"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-25"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-24"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-23"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-22"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-21"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-20"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-19"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-18"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-17"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-16"
        },
        {
          "confirmed": 1,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-15"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-14"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-13"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-12"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-11"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-10"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-9"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-8"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-7"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-6"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-5"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-4"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-3"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-2"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-1"
        }
      ]
    },
    {
      "date": "2020-01-26",
      "list": [
        
       
     
       
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-47"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-46"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-45"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-44"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-43"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-42"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-41"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-40"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-39"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-38"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-37"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-36"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-35"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-34"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-33"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-32"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-31"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-30"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-29"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-28"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-27"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-26"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-25"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-24"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-23"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-22"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-21"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-20"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-19"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-18"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-17"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-16"
        },
        {
          "confirmed": 1,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-15"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-14"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-13"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-12"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-11"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-10"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-9"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-8"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-7"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-6"
        },
        {
          "confirmed": 2,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-5"
        },
        {
          "confirmed": 1,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-4"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-3"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-2"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-1"
        }
      ]
    },
    {
      "date": "2020-01-27",
      "list": [
        
       
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-47"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-46"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-45"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-44"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-43"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-42"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-41"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-40"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-39"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-38"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-37"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-36"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-35"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-34"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-33"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-32"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-31"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-30"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-29"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-28"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-27"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-26"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-25"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-24"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-23"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-22"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-21"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-20"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-19"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-18"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-17"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-16"
        },
        {
          "confirmed": 1,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-15"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-14"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-13"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-12"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-11"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-10"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-9"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-8"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-7"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-6"
        },
        {
          "confirmed": 2,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-5"
        },
        {
          "confirmed": 1,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-4"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-3"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-2"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-1"
        }
      ]
    },
    {
      "date": "2020-01-28",
      "list": [
      
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-47"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-46"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-45"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-44"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-43"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-42"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-41"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-40"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-39"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-38"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-37"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-36"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-35"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-34"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-33"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-32"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-31"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-30"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-29"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-28"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-27"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-26"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-25"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-24"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-23"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-22"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-21"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-20"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-19"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-18"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-17"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-16"
        },
        {
          "confirmed": 1,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-15"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-14"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-13"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-12"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-11"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-10"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-9"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-8"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-7"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-6"
        },
        {
          "confirmed": 2,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-5"
        },
        {
          "confirmed": 1,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-4"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-3"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-2"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-1"
        }
      ]
    },
    {
      "date": "2020-01-29",
      "list": [
        
       
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-47"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-46"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-45"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-44"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-43"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-42"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-41"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-40"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-39"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-38"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-37"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-36"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-35"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-34"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-33"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-32"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-31"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-30"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-29"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-28"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-27"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-26"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-25"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-24"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-23"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-22"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-21"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-20"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-19"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-18"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-17"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-16"
        },
        {
          "confirmed": 1,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-15"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-14"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-13"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-12"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-11"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-10"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-9"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-8"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-7"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-6"
        },
        {
          "confirmed": 2,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-5"
        },
        {
          "confirmed": 1,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-4"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-3"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-2"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-1"
        }
      ]
    },
    {
      "date": "2020-01-30",
      "list": [
        
       
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-47"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-46"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-45"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-44"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-43"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-42"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-41"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-40"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-39"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-38"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-37"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-36"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-35"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-34"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-33"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-32"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-31"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-30"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-29"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-28"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-27"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-26"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-25"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-24"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-23"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-22"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-21"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-20"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-19"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-18"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-17"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-16"
        },
        {
          "confirmed": 1,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-15"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-14"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-13"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-12"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-11"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-10"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-9"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-8"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-7"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-6"
        },
        {
          "confirmed": 2,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-5"
        },
        {
          "confirmed": 1,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-4"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-3"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-2"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-1"
        }
      ]
    },
    {
      "date": "2020-01-31",
      "list": [
       
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-47"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-46"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-45"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-44"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-43"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-42"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-41"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-40"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-39"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-38"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-37"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-36"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-35"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-34"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-33"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-32"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-31"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-30"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-29"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-28"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-27"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-26"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-25"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-24"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-23"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-22"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-21"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-20"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-19"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-18"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-17"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-16"
        },
        {
          "confirmed": 2,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-15"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-14"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-13"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-12"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-11"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-10"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-9"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-8"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-7"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-6"
        },
        {
          "confirmed": 2,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-5"
        },
        {
          "confirmed": 1,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-4"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-3"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-2"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-1"
        }
      ]
    },
    {
      "date": "2020-02-01",
      "list": [
        
       
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-47"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-46"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-45"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-44"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-43"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-42"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-41"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-40"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-39"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-38"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-37"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-36"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-35"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-34"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-33"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-32"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-31"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-30"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-29"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-28"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-27"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-26"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-25"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-24"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-23"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-22"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-21"
        },
        {
          "confirmed": 1,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-20"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-19"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-18"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-17"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-16"
        },
        {
          "confirmed": 2,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-15"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-14"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-13"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-12"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-11"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-10"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-9"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-8"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-7"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-6"
        },
        {
          "confirmed": 3,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-5"
        },
        {
          "confirmed": 1,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-4"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-3"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-2"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-1"
        }
      ]
    },
    {
      "date": "2020-02-02",
      "list": [
        
       
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-47"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-46"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-45"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-44"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-43"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-42"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-41"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-40"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-39"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-38"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-37"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-36"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-35"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-34"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-33"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-32"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-31"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-30"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-29"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-28"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-27"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-26"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-25"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-24"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-23"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-22"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-21"
        },
        {
          "confirmed": 1,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-20"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-19"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-18"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-17"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-16"
        },
        {
          "confirmed": 2,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-15"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-14"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-13"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-12"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-11"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-10"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-9"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-8"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-7"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-6"
        },
        {
          "confirmed": 3,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-5"
        },
        {
          "confirmed": 1,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-4"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-3"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-2"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-1"
        }
      ]
    },
    {
      "date": "2020-02-03",
      "list": [
        
        
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-47"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-46"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-45"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-44"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-43"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-42"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-41"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-40"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-39"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-38"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-37"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-36"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-35"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-34"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-33"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-32"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-31"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-30"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-29"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-28"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-27"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-26"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-25"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-24"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-23"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-22"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-21"
        },
        {
          "confirmed": 1,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-20"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-19"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-18"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-17"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-16"
        },
        {
          "confirmed": 2,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-15"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-14"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-13"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-12"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-11"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-10"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-9"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-8"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-7"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-6"
        },
        {
          "confirmed": 6,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-5"
        },
        {
          "confirmed": 1,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-4"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-3"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-2"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-1"
        }
      ]
    },
    {
      "date": "2020-02-04",
      "list": [
        
       
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-47"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-46"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-45"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-44"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-43"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-42"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-41"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-40"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-39"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-38"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-37"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-36"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-35"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-34"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-33"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-32"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-31"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-30"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-29"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-28"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-27"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-26"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-25"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-24"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-23"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-22"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-21"
        },
        {
          "confirmed": 1,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-20"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-19"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-18"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-17"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-16"
        },
        {
          "confirmed": 2,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-15"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-14"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-13"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-12"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-11"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-10"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-9"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-8"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-7"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-6"
        },
        {
          "confirmed": 6,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-5"
        },
        {
          "confirmed": 1,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-4"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-3"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-2"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-1"
        }
      ]
    },
    {
      "date": "2020-02-05",
      "list": [
        
       
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-47"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-46"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-45"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-44"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-43"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-42"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-41"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-40"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-39"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-38"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-37"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-36"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-35"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-34"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-33"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-32"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-31"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-30"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-29"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-28"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-27"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-26"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-25"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-24"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-23"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-22"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-21"
        },
        {
          "confirmed": 1,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-20"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-19"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-18"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-17"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-16"
        },
        {
          "confirmed": 2,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-15"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-14"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-13"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-12"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-11"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-10"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-9"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-8"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-7"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-6"
        },
        {
          "confirmed": 6,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-5"
        },
        {
          "confirmed": 1,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-4"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-3"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-2"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-1"
        }
      ]
    },
    {
      "date": "2020-02-06",
      "list": [
        
       
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-47"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-46"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-45"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-44"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-43"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-42"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-41"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-40"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-39"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-38"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-37"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-36"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-35"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-34"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-33"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-32"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-31"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-30"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-29"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-28"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-27"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-26"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-25"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-24"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-23"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-22"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-21"
        },
        {
          "confirmed": 1,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-20"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-19"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-18"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-17"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-16"
        },
        {
          "confirmed": 2,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-15"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-14"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-13"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-12"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-11"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-10"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-9"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-8"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-7"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-6"
        },
        {
          "confirmed": 6,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-5"
        },
        {
          "confirmed": 1,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-4"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-3"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-2"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-1"
        }
      ]
    },
    {
      "date": "2020-02-07",
      "list": [
        
        
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-47"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-46"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-45"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-44"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-43"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-42"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-41"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-40"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-39"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-38"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-37"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-36"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-35"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-34"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-33"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-32"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-31"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-30"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-29"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-28"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-27"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-26"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-25"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-24"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-23"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-22"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-21"
        },
        {
          "confirmed": 1,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-20"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-19"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-18"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-17"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-16"
        },
        {
          "confirmed": 2,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-15"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-14"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-13"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-12"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-11"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-10"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-9"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-8"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-7"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-6"
        },
        {
          "confirmed": 6,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-5"
        },
        {
          "confirmed": 1,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-4"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-3"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-2"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-1"
        }
      ]
    },
    {
      "date": "2020-02-08",
      "list": [
        
       
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-47"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-46"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-45"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-44"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-43"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-42"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-41"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-40"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-39"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-38"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-37"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-36"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-35"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-34"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-33"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-32"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-31"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-30"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-29"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-28"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-27"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-26"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-25"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-24"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-23"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-22"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-21"
        },
        {
          "confirmed": 1,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-20"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-19"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-18"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-17"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-16"
        },
        {
          "confirmed": 2,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-15"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-14"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-13"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-12"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-11"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-10"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-9"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-8"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-7"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-6"
        },
        {
          "confirmed": 6,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-5"
        },
        {
          "confirmed": 1,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-4"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-3"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-2"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-1"
        }
      ]
    },
    {
      "date": "2020-02-09",
      "list": [
       
       
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-47"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-46"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-45"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-44"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-43"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-42"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-41"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-40"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-39"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-38"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-37"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-36"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-35"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-34"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-33"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-32"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-31"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-30"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-29"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-28"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-27"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-26"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-25"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-24"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-23"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-22"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-21"
        },
        {
          "confirmed": 1,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-20"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-19"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-18"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-17"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-16"
        },
        {
          "confirmed": 2,
          "deaths": 0,
          "recovered": 2,
          "id": "KE-15"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-14"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-13"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-12"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-11"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-10"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-9"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-8"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-7"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-6"
        },
        {
          "confirmed": 6,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-5"
        },
        {
          "confirmed": 1,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-4"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-3"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-2"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-1"
        }
      ]
    },
    {
      "date": "2020-02-10",
      "list": [
        
       
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-47"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-46"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-45"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-44"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-43"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-42"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-41"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-40"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-39"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-38"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-37"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-36"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-35"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-34"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-33"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-32"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-31"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-30"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-29"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-28"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-27"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-26"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-25"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-24"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-23"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-22"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-21"
        },
        {
          "confirmed": 1,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-20"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-19"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-18"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-17"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-16"
        },
        {
          "confirmed": 2,
          "deaths": 0,
          "recovered": 2,
          "id": "KE-15"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-14"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-13"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-12"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-11"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-10"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-9"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-8"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-7"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-6"
        },
        {
          "confirmed": 6,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-5"
        },
        {
          "confirmed": 1,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-4"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-3"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-2"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-1"
        }
      ]
    },
    {
      "date": "2020-02-11",
      "list": [
        
       
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-47"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-46"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-45"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-44"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-43"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-42"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-41"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-40"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-39"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-38"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-37"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-36"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-35"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-34"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-33"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-32"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-31"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-30"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-29"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-28"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-27"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-26"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-25"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-24"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-23"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-22"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-21"
        },
        {
          "confirmed": 1,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-20"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-19"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-18"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-17"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-16"
        },
        {
          "confirmed": 2,
          "deaths": 0,
          "recovered": 2,
          "id": "KE-15"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-14"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-13"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-12"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-11"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-10"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-9"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-8"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-7"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-6"
        },
        {
          "confirmed": 7,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-5"
        },
        {
          "confirmed": 1,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-4"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-3"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-2"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-1"
        }
      ]
    },
    {
      "date": "2020-02-12",
      "list": [
        
       
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-47"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-46"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-45"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-44"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-43"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-42"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-41"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-40"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-39"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-38"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-37"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-36"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-35"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-34"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-33"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-32"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-31"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-30"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-29"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-28"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-27"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-26"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-25"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-24"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-23"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-22"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-21"
        },
        {
          "confirmed": 1,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-20"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-19"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-18"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-17"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-16"
        },
        {
          "confirmed": 2,
          "deaths": 0,
          "recovered": 2,
          "id": "KE-15"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-14"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-13"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-12"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-11"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-10"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-9"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-8"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-7"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-6"
        },
        {
          "confirmed": 7,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-5"
        },
        {
          "confirmed": 1,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-4"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-3"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-2"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-1"
        }
      ]
    },
    {
      "date": "2020-02-13",
      "list": [
       
       
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-47"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-46"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-45"
        },
        {
          "confirmed": 1,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-44"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-43"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-42"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-41"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-40"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-39"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-38"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-37"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-36"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-35"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-34"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-33"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-32"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-31"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-30"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-29"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-28"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-27"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-26"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-25"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-24"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-23"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-22"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-21"
        },
        {
          "confirmed": 1,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-20"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-19"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-18"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-17"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-16"
        },
        {
          "confirmed": 2,
          "deaths": 0,
          "recovered": 2,
          "id": "KE-15"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-14"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-13"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-12"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-11"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-10"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-9"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-8"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-7"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-6"
        },
        {
          "confirmed": 8,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-5"
        },
        {
          "confirmed": 1,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-4"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-3"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-2"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-1"
        }
      ]
    },
    {
      "date": "2020-02-14",
      "list": [
        
       
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-47"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-46"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-45"
        },
        {
          "confirmed": 1,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-44"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-43"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-42"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-41"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-40"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-39"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-38"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-37"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-36"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-35"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-34"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-33"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-32"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-31"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-30"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-29"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-28"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-27"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-26"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-25"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-24"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-23"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-22"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-21"
        },
        {
          "confirmed": 1,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-20"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-19"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-18"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-17"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-16"
        },
        {
          "confirmed": 2,
          "deaths": 0,
          "recovered": 2,
          "id": "KE-15"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-14"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-13"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-12"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-11"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-10"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-9"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-8"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-7"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-6"
        },
        {
          "confirmed": 8,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-5"
        },
        {
          "confirmed": 1,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-4"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-3"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-2"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-1"
        }
      ]
    },
    {
      "date": "2020-02-15",
      "list": [
        
       
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-47"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-46"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-45"
        },
        {
          "confirmed": 1,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-44"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-43"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-42"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-41"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-40"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-39"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-38"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-37"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-36"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-35"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-34"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-33"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-32"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-31"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-30"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-29"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-28"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-27"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-26"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-25"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-24"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-23"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-22"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-21"
        },
        {
          "confirmed": 1,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-20"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-19"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-18"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-17"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-16"
        },
        {
          "confirmed": 2,
          "deaths": 0,
          "recovered": 2,
          "id": "KE-15"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-14"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-13"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-12"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-11"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-10"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-9"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-8"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-7"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-6"
        },
        {
          "confirmed": 8,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-5"
        },
        {
          "confirmed": 1,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-4"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-3"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-2"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-1"
        }
      ]
    },
    {
      "date": "2020-02-16",
      "list": [
        
       
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-47"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-46"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-45"
        },
        {
          "confirmed": 1,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-44"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-43"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-42"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-41"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-40"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-39"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-38"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-37"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-36"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-35"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-34"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-33"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-32"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-31"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-30"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-29"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-28"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-27"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-26"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-25"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-24"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-23"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-22"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-21"
        },
        {
          "confirmed": 1,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-20"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-19"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-18"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-17"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-16"
        },
        {
          "confirmed": 2,
          "deaths": 0,
          "recovered": 2,
          "id": "KE-15"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-14"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-13"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-12"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-11"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-10"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-9"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-8"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-7"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-6"
        },
        {
          "confirmed": 8,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-5"
        },
        {
          "confirmed": 1,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-4"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-3"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-2"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-1"
        }
      ]
    },
    {
      "date": "2020-02-17",
      "list": [
        
       
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-47"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-46"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-45"
        },
        {
          "confirmed": 1,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-44"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-43"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-42"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-41"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-40"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-39"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-38"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-37"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-36"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-35"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-34"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-33"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-32"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-31"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-30"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-29"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-28"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-27"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-26"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-25"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-24"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-23"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-22"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-21"
        },
        {
          "confirmed": 1,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-20"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-19"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-18"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-17"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-16"
        },
        {
          "confirmed": 2,
          "deaths": 0,
          "recovered": 2,
          "id": "KE-15"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-14"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-13"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-12"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-11"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-10"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-9"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-8"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-7"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-6"
        },
        {
          "confirmed": 8,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-5"
        },
        {
          "confirmed": 1,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-4"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-3"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-2"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-1"
        }
      ]
    },
    {
      "date": "2020-02-18",
      "list": [
        
       
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-47"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-46"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-45"
        },
        {
          "confirmed": 1,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-44"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-43"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-42"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-41"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-40"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-39"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-38"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-37"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-36"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-35"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-34"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-33"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-32"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-31"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-30"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-29"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-28"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-27"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-26"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-25"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-24"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-23"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-22"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-21"
        },
        {
          "confirmed": 1,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-20"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-19"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-18"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-17"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-16"
        },
        {
          "confirmed": 2,
          "deaths": 0,
          "recovered": 2,
          "id": "KE-15"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-14"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-13"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-12"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-11"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-10"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-9"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-8"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-7"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-6"
        },
        {
          "confirmed": 8,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-5"
        },
        {
          "confirmed": 1,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-4"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-3"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-2"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-1"
        }
      ]
    },
    {
      "date": "2020-02-19",
      "list": [
        
        
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-47"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-46"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-45"
        },
        {
          "confirmed": 1,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-44"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-43"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-42"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-41"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-40"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-39"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-38"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-37"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-36"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-35"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-34"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-33"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-32"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-31"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-30"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-29"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-28"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-27"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-26"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-25"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-24"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-23"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-22"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-21"
        },
        {
          "confirmed": 1,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-20"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-19"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-18"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-17"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-16"
        },
        {
          "confirmed": 2,
          "deaths": 0,
          "recovered": 2,
          "id": "KE-15"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-14"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-13"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-12"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-11"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-10"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-9"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-8"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-7"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-6"
        },
        {
          "confirmed": 8,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-5"
        },
        {
          "confirmed": 1,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-4"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-3"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-2"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-1"
        }
      ]
    },
    {
      "date": "2020-02-20",
      "list": [
        
        
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-47"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-46"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-45"
        },
        {
          "confirmed": 1,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-44"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-43"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-42"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-41"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-40"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-39"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-38"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-37"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-36"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-35"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-34"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-33"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-32"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-31"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-30"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-29"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-28"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-27"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-26"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-25"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-24"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-23"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-22"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-21"
        },
        {
          "confirmed": 1,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-20"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-19"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-18"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-17"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-16"
        },
        {
          "confirmed": 2,
          "deaths": 0,
          "recovered": 2,
          "id": "KE-15"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-14"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-13"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-12"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-11"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-10"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-9"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-8"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-7"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-6"
        },
        {
          "confirmed": 8,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-5"
        },
        {
          "confirmed": 1,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-4"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-3"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-2"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-1"
        }
      ]
    },
    {
      "date": "2020-02-21",
      "list": [
        
      
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-47"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-46"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-45"
        },
        {
          "confirmed": 3,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-44"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-43"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-42"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-41"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-40"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-39"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-38"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-37"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-36"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-35"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-34"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-33"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-32"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-31"
        },
        {
          "confirmed": 11,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-30"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-29"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-28"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-27"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-26"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-25"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-24"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-23"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-22"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-21"
        },
        {
          "confirmed": 1,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-20"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-19"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-18"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-17"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-16"
        },
        {
          "confirmed": 2,
          "deaths": 0,
          "recovered": 2,
          "id": "KE-15"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-14"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-13"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-12"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-11"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-10"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-9"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-8"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-7"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-6"
        },
        {
          "confirmed": 15,
          "deaths": 0,
          "recovered": 2,
          "id": "KE-5"
        },
        {
          "confirmed": 1,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-4"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-3"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-2"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-1"
        }
      ]
    },
    {
      "date": "2020-02-22",
      "list": [
        
       
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-47"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-46"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-45"
        },
        {
          "confirmed": 3,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-44"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-43"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-42"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-41"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-40"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-39"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-38"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-37"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-36"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-35"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-34"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-33"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-32"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-31"
        },
        {
          "confirmed": 11,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-30"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-29"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-28"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-27"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-26"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-25"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-24"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-23"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-22"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-21"
        },
        {
          "confirmed": 1,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-20"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-19"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-18"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-17"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-16"
        },
        {
          "confirmed": 2,
          "deaths": 0,
          "recovered": 2,
          "id": "KE-15"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-14"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-13"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-12"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-11"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-10"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-9"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-8"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-7"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-6"
        },
        {
          "confirmed": 15,
          "deaths": 0,
          "recovered": 2,
          "id": "KE-5"
        },
        {
          "confirmed": 1,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-4"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-3"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-2"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-1"
        }
      ]
    },
    {
      "date": "2020-02-23",
      "list": [
        
       
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-47"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-46"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-45"
        },
        {
          "confirmed": 3,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-44"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-43"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-42"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-41"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-40"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-39"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-38"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-37"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-36"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-35"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-34"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-33"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-32"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-31"
        },
        {
          "confirmed": 11,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-30"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-29"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-28"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-27"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-26"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-25"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-24"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-23"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-22"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-21"
        },
        {
          "confirmed": 1,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-20"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-19"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-18"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-17"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-16"
        },
        {
          "confirmed": 2,
          "deaths": 0,
          "recovered": 2,
          "id": "KE-15"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-14"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-13"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-12"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-11"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-10"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-9"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-8"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-7"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-6"
        },
        {
          "confirmed": 15,
          "deaths": 0,
          "recovered": 2,
          "id": "KE-5"
        },
        {
          "confirmed": 1,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-4"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-3"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-2"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-1"
        }
      ]
    },
    {
      "date": "2020-02-24",
      "list": [
        
      
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-47"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-46"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-45"
        },
        {
          "confirmed": 1,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-44"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-43"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-42"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-41"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-40"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-39"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-38"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-37"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-36"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-35"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-34"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-33"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-32"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-31"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-30"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-29"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-28"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-27"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-26"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-25"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-24"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-23"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-22"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-21"
        },
        {
          "confirmed": 1,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-20"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-19"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-18"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-17"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-16"
        },
        {
          "confirmed": 2,
          "deaths": 0,
          "recovered": 2,
          "id": "KE-15"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-14"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-13"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-12"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-11"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-10"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-9"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-8"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-7"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-6"
        },
        {
          "confirmed": 10,
          "deaths": 0,
          "recovered": 2,
          "id": "KE-5"
        },
        {
          "confirmed": 1,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-4"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-3"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-2"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-1"
        }
      ]
    },
    {
      "date": "2020-02-25",
      "list": [
        
       
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-47"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-46"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-45"
        },
        {
          "confirmed": 1,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-44"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-43"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-42"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-41"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-40"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-39"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-38"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-37"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-36"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-35"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-34"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-33"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-32"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-31"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-30"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-29"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-28"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-27"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-26"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-25"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-24"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-23"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-22"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-21"
        },
        {
          "confirmed": 1,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-20"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-19"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-18"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-17"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-16"
        },
        {
          "confirmed": 2,
          "deaths": 0,
          "recovered": 2,
          "id": "KE-15"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-14"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-13"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-12"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-11"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-10"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-9"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-8"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-7"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-6"
        },
        {
          "confirmed": 10,
          "deaths": 0,
          "recovered": 2,
          "id": "KE-5"
        },
        {
          "confirmed": 1,
          "deaths": 0,
          "recovered": 1,
          "id": "KE-4"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-3"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-2"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-1"
        }
      ]
    },
    {
      "date": "2020-02-26",
      "list": [
        
       
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-47"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-46"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-45"
        },
        {
          "confirmed": 1,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-44"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-43"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-42"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-41"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-40"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-39"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-38"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-37"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-36"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-35"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-34"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-33"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-32"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-31"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-30"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-29"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-28"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-27"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-26"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-25"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-24"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-23"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-22"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-21"
        },
        {
          "confirmed": 1,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-20"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-19"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-18"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-17"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-16"
        },
        {
          "confirmed": 2,
          "deaths": 0,
          "recovered": 2,
          "id": "KE-15"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-14"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-13"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-12"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-11"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-10"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-9"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-8"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-7"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-6"
        },
        {
          "confirmed": 10,
          "deaths": 0,
          "recovered": 2,
          "id": "KE-5"
        },
        {
          "confirmed": 1,
          "deaths": 0,
          "recovered": 1,
          "id": "KE-4"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-3"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-2"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-1"
        }
      ]
    },
    {
      "date": "2020-02-27",
      "list": [
        
        
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-47"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-46"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-45"
        },
        {
          "confirmed": 1,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-44"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-43"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-42"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-41"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-40"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-39"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-38"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-37"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-36"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-35"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-34"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-33"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-32"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-31"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-30"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-29"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-28"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-27"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-26"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-25"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-24"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-23"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-22"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-21"
        },
        {
          "confirmed": 1,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-20"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-19"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-18"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-17"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-16"
        },
        {
          "confirmed": 2,
          "deaths": 0,
          "recovered": 2,
          "id": "KE-15"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-14"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-13"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-12"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-11"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-10"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-9"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-8"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-7"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-6"
        },
        {
          "confirmed": 11,
          "deaths": 0,
          "recovered": 2,
          "id": "KE-5"
        },
        {
          "confirmed": 1,
          "deaths": 0,
          "recovered": 1,
          "id": "KE-4"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-3"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-2"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-1"
        }
      ]
    },
    {
      "date": "2020-02-28",
      "list": [
        
        
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-47"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-46"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-45"
        },
        {
          "confirmed": 1,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-44"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-43"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-42"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-41"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-40"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-39"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-38"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-37"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-36"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-35"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-34"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-33"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-32"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-31"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-30"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-29"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-28"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-27"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-26"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-25"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-24"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-23"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-22"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-21"
        },
        {
          "confirmed": 1,
          "deaths": 0,
          "recovered": 1,
          "id": "KE-20"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-19"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-18"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-17"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-16"
        },
        {
          "confirmed": 2,
          "deaths": 0,
          "recovered": 2,
          "id": "KE-15"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-14"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-13"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-12"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-11"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-10"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-9"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-8"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-7"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-6"
        },
        {
          "confirmed": 11,
          "deaths": 0,
          "recovered": 2,
          "id": "KE-5"
        },
        {
          "confirmed": 1,
          "deaths": 0,
          "recovered": 1,
          "id": "KE-4"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-3"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-2"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-1"
        }
      ]
    },
    {
      "date": "2020-02-29",
      "list": [
        
       
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-47"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-46"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-45"
        },
        {
          "confirmed": 1,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-44"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-43"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-42"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-41"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-40"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-39"
        },
        {
          "confirmed": 1,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-38"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-37"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-36"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-35"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-34"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-33"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-32"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-31"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-30"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-29"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-28"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-27"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-26"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-25"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-24"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-23"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-22"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-21"
        },
        {
          "confirmed": 1,
          "deaths": 0,
          "recovered": 1,
          "id": "KE-20"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-19"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-18"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-17"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-16"
        },
        {
          "confirmed": 2,
          "deaths": 0,
          "recovered": 2,
          "id": "KE-15"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-14"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-13"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-12"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-11"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-10"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-9"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-8"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-7"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-6"
        },
        {
          "confirmed": 12,
          "deaths": 0,
          "recovered": 2,
          "id": "KE-5"
        },
        {
          "confirmed": 1,
          "deaths": 0,
          "recovered": 1,
          "id": "KE-4"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-3"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-2"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-1"
        }
      ]
    },
    {
      "date": "2020-03-01",
      "list": [
        
       
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-47"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-46"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-45"
        },
        {
          "confirmed": 1,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-44"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-43"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-42"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-41"
        },
        {
          "confirmed": 1,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-40"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-39"
        },
        {
          "confirmed": 1,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-38"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-37"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-36"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-35"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-34"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-33"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-32"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-31"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-30"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-29"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-28"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-27"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-26"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-25"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-24"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-23"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-22"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-21"
        },
        {
          "confirmed": 1,
          "deaths": 0,
          "recovered": 1,
          "id": "KE-20"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-19"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-18"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-17"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-16"
        },
        {
          "confirmed": 3,
          "deaths": 0,
          "recovered": 2,
          "id": "KE-15"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-14"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-13"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-12"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-11"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-10"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-9"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-8"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-7"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-6"
        },
        {
          "confirmed": 12,
          "deaths": 0,
          "recovered": 2,
          "id": "KE-5"
        },
        {
          "confirmed": 1,
          "deaths": 0,
          "recovered": 1,
          "id": "KE-4"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-3"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-2"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-1"
        }
      ]
    },
    {
      "date": "2020-03-02",
      "list": [
        
        
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-47"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-46"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-45"
        },
        {
          "confirmed": 1,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-44"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-43"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-42"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-41"
        },
        {
          "confirmed": 2,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-40"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-39"
        },
        {
          "confirmed": 3,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-38"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-37"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-36"
        },
        {
          "confirmed": 1,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-35"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-34"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-33"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-32"
        },
        {
          "confirmed": 1,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-31"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-30"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-29"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-28"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-27"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-26"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-25"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-24"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-23"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-22"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-21"
        },
        {
          "confirmed": 1,
          "deaths": 0,
          "recovered": 1,
          "id": "KE-20"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-19"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-18"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-17"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-16"
        },
        {
          "confirmed": 4,
          "deaths": 0,
          "recovered": 2,
          "id": "KE-15"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-14"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-13"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-12"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-11"
        },
        {
          "confirmed": 2,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-10"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-9"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-8"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-7"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-6"
        },
        {
          "confirmed": 21,
          "deaths": 0,
          "recovered": 2,
          "id": "KE-5"
        },
        {
          "confirmed": 1,
          "deaths": 0,
          "recovered": 1,
          "id": "KE-4"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-3"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-2"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-1"
        }
      ]
    },
    {
      "date": "2020-03-03",
      "list": [
       
       
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-47"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-46"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-45"
        },
        {
          "confirmed": 1,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-44"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-43"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-42"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-41"
        },
        {
          "confirmed": 2,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-40"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-39"
        },
        {
          "confirmed": 3,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-38"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-37"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-36"
        },
        {
          "confirmed": 2,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-35"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-34"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-33"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-32"
        },
        {
          "confirmed": 2,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-31"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-30"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-29"
        },
        {
          "confirmed": 1,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-28"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-27"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-26"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-25"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-24"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-23"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-22"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-21"
        },
        {
          "confirmed": 2,
          "deaths": 0,
          "recovered": 1,
          "id": "KE-20"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-19"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-18"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-17"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-16"
        },
        {
          "confirmed": 4,
          "deaths": 0,
          "recovered": 2,
          "id": "KE-15"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-14"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-13"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-12"
        },
        {
          "confirmed": 2,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-11"
        },
        {
          "confirmed": 3,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-10"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-9"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-8"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-7"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-6"
        },
        {
          "confirmed": 25,
          "deaths": 0,
          "recovered": 2,
          "id": "KE-5"
        },
        {
          "confirmed": 2,
          "deaths": 0,
          "recovered": 1,
          "id": "KE-4"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-3"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-2"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-1"
        }
      ]
    },
    {
      "date": "2020-03-04",
      "list": [
        
       
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-47"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-46"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-45"
        },
        {
          "confirmed": 1,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-44"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-43"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-42"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-41"
        },
        {
          "confirmed": 2,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-40"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-39"
        },
        {
          "confirmed": 3,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-38"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-37"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-36"
        },
        {
          "confirmed": 11,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-35"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-34"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-33"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-32"
        },
        {
          "confirmed": 2,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-31"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-30"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-29"
        },
        {
          "confirmed": 1,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-28"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-27"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-26"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-25"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-24"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-23"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-22"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-21"
        },
        {
          "confirmed": 2,
          "deaths": 0,
          "recovered": 1,
          "id": "KE-20"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-19"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-18"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-17"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-16"
        },
        {
          "confirmed": 4,
          "deaths": 0,
          "recovered": 2,
          "id": "KE-15"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-14"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-13"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-12"
        },
        {
          "confirmed": 2,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-11"
        },
        {
          "confirmed": 3,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-10"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-9"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-8"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-7"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-6"
        },
        {
          "confirmed": 35,
          "deaths": 1,
          "recovered": 2,
          "id": "KE-5"
        },
        {
          "confirmed": 2,
          "deaths": 0,
          "recovered": 1,
          "id": "KE-4"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-3"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-2"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-1"
        }
      ]
    },
    {
      "date": "2020-03-05",
      "list": [
        
        
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-47"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-46"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-45"
        },
        {
          "confirmed": 4,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-44"
        },
        {
          "confirmed": 1,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-43"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-42"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-41"
        },
        {
          "confirmed": 2,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-40"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-39"
        },
        {
          "confirmed": 3,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-38"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-37"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-36"
        },
        {
          "confirmed": 23,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-35"
        },
        {
          "confirmed": 1,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-34"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-33"
        },
        {
          "confirmed": 2,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-32"
        },
        {
          "confirmed": 2,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-31"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-30"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-29"
        },
        {
          "confirmed": 1,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-28"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-27"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-26"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-25"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-24"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-23"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-22"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-21"
        },
        {
          "confirmed": 2,
          "deaths": 0,
          "recovered": 1,
          "id": "KE-20"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-19"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-18"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-17"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-16"
        },
        {
          "confirmed": 5,
          "deaths": 0,
          "recovered": 2,
          "id": "KE-15"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-14"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-13"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-12"
        },
        {
          "confirmed": 2,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-11"
        },
        {
          "confirmed": 4,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-10"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-9"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-8"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-7"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-6"
        },
        {
          "confirmed": 51,
          "deaths": 1,
          "recovered": 2,
          "id": "KE-5"
        },
        {
          "confirmed": 2,
          "deaths": 0,
          "recovered": 1,
          "id": "KE-4"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-3"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-2"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-1"
        }
      ]
    },
    {
      "date": "2020-03-06",
      "list": [
        
        
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-47"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-46"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-45"
        },
        {
          "confirmed": 5,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-44"
        },
        {
          "confirmed": 1,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-43"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-42"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-41"
        },
        {
          "confirmed": 2,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-40"
        },
        {
          "confirmed": 2,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-39"
        },
        {
          "confirmed": 3,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-38"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-37"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-36"
        },
        {
          "confirmed": 36,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-35"
        },
        {
          "confirmed": 2,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-34"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-33"
        },
        {
          "confirmed": 2,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-32"
        },
        {
          "confirmed": 2,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-31"
        },
        {
          "confirmed": 1,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-30"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-29"
        },
        {
          "confirmed": 2,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-28"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-27"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-26"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-25"
        },
        {
          "confirmed": 1,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-24"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-23"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-22"
        },
        {
          "confirmed": 3,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-21"
        },
        {
          "confirmed": 7,
          "deaths": 0,
          "recovered": 1,
          "id": "KE-20"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-19"
        },
        {
          "confirmed": 1,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-18"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-17"
        },
        {
          "confirmed": 1,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-16"
        },
        {
          "confirmed": 5,
          "deaths": 0,
          "recovered": 2,
          "id": "KE-15"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-14"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-13"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-12"
        },
        {
          "confirmed": 3,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-11"
        },
        {
          "confirmed": 4,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-10"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-9"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-8"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-7"
        },
        {
          "confirmed": 4,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-6"
        },
        {
          "confirmed": 59,
          "deaths": 1,
          "recovered": 2,
          "id": "KE-5"
        },
        {
          "confirmed": 3,
          "deaths": 0,
          "recovered": 1,
          "id": "KE-4"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-3"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-2"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-1"
        }
      ]
    },
    {
      "date": "2020-03-07",
      "list": [
        
        
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-47"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-46"
        },
        {
          "confirmed": 1,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-45"
        },
        {
          "confirmed": 9,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-44"
        },
        {
          "confirmed": 1,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-43"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-42"
        },
        {
          "confirmed": 2,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-41"
        },
        {
          "confirmed": 3,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-40"
        },
        {
          "confirmed": 2,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-39"
        },
        {
          "confirmed": 6,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-38"
        },
        {
          "confirmed": 1,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-37"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-36"
        },
        {
          "confirmed": 76,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-35"
        },
        {
          "confirmed": 2,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-34"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-33"
        },
        {
          "confirmed": 4,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-32"
        },
        {
          "confirmed": 2,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-31"
        },
        {
          "confirmed": 1,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-30"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-29"
        },
        {
          "confirmed": 2,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-28"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-27"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-26"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-25"
        },
        {
          "confirmed": 1,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-24"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-23"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-22"
        },
        {
          "confirmed": 3,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-21"
        },
        {
          "confirmed": 7,
          "deaths": 0,
          "recovered": 1,
          "id": "KE-20"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-19"
        },
        {
          "confirmed": 1,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-18"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-17"
        },
        {
          "confirmed": 1,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-16"
        },
        {
          "confirmed": 6,
          "deaths": 0,
          "recovered": 2,
          "id": "KE-15"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-14"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-13"
        },
        {
          "confirmed": 1,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-12"
        },
        {
          "confirmed": 6,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-11"
        },
        {
          "confirmed": 8,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-10"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-9"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-8"
        },
        {
          "confirmed": 2,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-7"
        },
        {
          "confirmed": 8,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-6"
        },
        {
          "confirmed": 82,
          "deaths": 1,
          "recovered": 2,
          "id": "KE-5"
        },
        {
          "confirmed": 5,
          "deaths": 0,
          "recovered": 1,
          "id": "KE-4"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-3"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-2"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-1"
        }
      ]
    },
    {
      "date": "2020-03-08",
      "list": [
       
        
        {
          "confirmed": 1,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-47"
        },
        {
          "confirmed": 2,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-46"
        },
        {
          "confirmed": 1,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-45"
        },
        {
          "confirmed": 12,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-44"
        },
        {
          "confirmed": 3,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-43"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-42"
        },
        {
          "confirmed": 2,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-41"
        },
        {
          "confirmed": 3,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-40"
        },
        {
          "confirmed": 6,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-39"
        },
        {
          "confirmed": 14,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-38"
        },
        {
          "confirmed": 1,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-37"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-36"
        },
        {
          "confirmed": 106,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-35"
        },
        {
          "confirmed": 4,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-34"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-33"
        },
        {
          "confirmed": 5,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-32"
        },
        {
          "confirmed": 6,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-31"
        },
        {
          "confirmed": 1,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-30"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-29"
        },
        {
          "confirmed": 2,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-28"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-27"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-26"
        },
        {
          "confirmed": 1,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-25"
        },
        {
          "confirmed": 1,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-24"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-23"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-22"
        },
        {
          "confirmed": 5,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-21"
        },
        {
          "confirmed": 24,
          "deaths": 0,
          "recovered": 1,
          "id": "KE-20"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-19"
        },
        {
          "confirmed": 1,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-18"
        },
        {
          "confirmed": 1,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-17"
        },
        {
          "confirmed": 2,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-16"
        },
        {
          "confirmed": 7,
          "deaths": 0,
          "recovered": 2,
          "id": "KE-15"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-14"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-13"
        },
        {
          "confirmed": 1,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-12"
        },
        {
          "confirmed": 5,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-11"
        },
        {
          "confirmed": 11,
          "deaths": 2,
          "recovered": 0,
          "id": "KE-10"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-9"
        },
        {
          "confirmed": 2,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-8"
        },
        {
          "confirmed": 1,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-7"
        },
        {
          "confirmed": 8,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-6"
        },
        {
          "confirmed": 98,
          "deaths": 1,
          "recovered": 2,
          "id": "KE-5"
        },
        {
          "confirmed": 5,
          "deaths": 0,
          "recovered": 1,
          "id": "KE-4"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-3"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-2"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-1"
        }
      ]
    },
    {
      "date": "2020-03-09",
      "list": [
        
        
        {
          "confirmed": 1,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-47"
        },
        {
          "confirmed": 2,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-46"
        },
        {
          "confirmed": 1,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-45"
        },
        {
          "confirmed": 14,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-44"
        },
        {
          "confirmed": 3,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-43"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-42"
        },
        {
          "confirmed": 6,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-41"
        },
        {
          "confirmed": 3,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-40"
        },
        {
          "confirmed": 7,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-39"
        },
        {
          "confirmed": 14,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-38"
        },
        {
          "confirmed": 1,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-37"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-36"
        },
        {
          "confirmed": 142,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-35"
        },
        {
          "confirmed": 4,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-34"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-33"
        },
        {
          "confirmed": 5,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-32"
        },
        {
          "confirmed": 5,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-31"
        },
        {
          "confirmed": 3,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-30"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-29"
        },
        {
          "confirmed": 2,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-28"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-27"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-26"
        },
        {
          "confirmed": 1,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-25"
        },
        {
          "confirmed": 2,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-24"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-23"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-22"
        },
        {
          "confirmed": 5,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-21"
        },
        {
          "confirmed": 24,
          "deaths": 0,
          "recovered": 1,
          "id": "KE-20"
        },
        {
          "confirmed": 1,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-19"
        },
        {
          "confirmed": 4,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-18"
        },
        {
          "confirmed": 1,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-17"
        },
        {
          "confirmed": 3,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-16"
        },
        {
          "confirmed": 7,
          "deaths": 0,
          "recovered": 2,
          "id": "KE-15"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-14"
        },
        {
          "confirmed": 3,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-13"
        },
        {
          "confirmed": 2,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-12"
        },
        {
          "confirmed": 10,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-11"
        },
        {
          "confirmed": 14,
          "deaths": 2,
          "recovered": 0,
          "id": "KE-10"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-9"
        },
        {
          "confirmed": 2,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-8"
        },
        {
          "confirmed": 1,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-7"
        },
        {
          "confirmed": 8,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-6"
        },
        {
          "confirmed": 104,
          "deaths": 1,
          "recovered": 2,
          "id": "KE-5"
        },
        {
          "confirmed": 5,
          "deaths": 0,
          "recovered": 1,
          "id": "KE-4"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-3"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-2"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-1"
        }
      ]
    },
    {
      "date": "2020-03-10",
      "list": [
        
        
        {
          "confirmed": 1,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-47"
        },
        {
          "confirmed": 7,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-46"
        },
        {
          "confirmed": 2,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-45"
        },
        {
          "confirmed": 13,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-44"
        },
        {
          "confirmed": 7,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-43"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-42"
        },
        {
          "confirmed": 7,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-41"
        },
        {
          "confirmed": 3,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-40"
        },
        {
          "confirmed": 12,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-39"
        },
        {
          "confirmed": 15,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-38"
        },
        {
          "confirmed": 2,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-37"
        },
        {
          "confirmed": 3,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-36"
        },
        {
          "confirmed": 173,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-35"
        },
        {
          "confirmed": 4,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-34"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-33"
        },
        {
          "confirmed": 15,
          "deaths": 1,
          "recovered": 0,
          "id": "KE-32"
        },
        {
          "confirmed": 4,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-31"
        },
        {
          "confirmed": 3,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-30"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-29"
        },
        {
          "confirmed": 7,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-28"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-27"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-26"
        },
        {
          "confirmed": 1,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-25"
        },
        {
          "confirmed": 3,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-24"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-23"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-22"
        },
        {
          "confirmed": 8,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-21"
        },
        {
          "confirmed": 92,
          "deaths": 0,
          "recovered": 1,
          "id": "KE-20"
        },
        {
          "confirmed": 1,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-19"
        },
        {
          "confirmed": 6,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-18"
        },
        {
          "confirmed": 1,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-17"
        },
        {
          "confirmed": 6,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-16"
        },
        {
          "confirmed": 12,
          "deaths": 0,
          "recovered": 2,
          "id": "KE-15"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-14"
        },
        {
          "confirmed": 8,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-13"
        },
        {
          "confirmed": 2,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-12"
        },
        {
          "confirmed": 17,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-11"
        },
        {
          "confirmed": 15,
          "deaths": 2,
          "recovered": 0,
          "id": "KE-10"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-9"
        },
        {
          "confirmed": 5,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-8"
        },
        {
          "confirmed": 2,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-7"
        },
        {
          "confirmed": 15,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-6"
        },
        {
          "confirmed": 144,
          "deaths": 2,
          "recovered": 2,
          "id": "KE-5"
        },
        {
          "confirmed": 6,
          "deaths": 0,
          "recovered": 1,
          "id": "KE-4"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-3"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-2"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-1"
        }
      ]
    },
    {
      "date": "2020-03-11",
      "list": [
        
        
        {
          "confirmed": 1,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-47"
        },
        {
          "confirmed": 9,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-46"
        },
        {
          "confirmed": 3,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-45"
        },
        {
          "confirmed": 21,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-44"
        },
        {
          "confirmed": 9,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-43"
        },
        {
          "confirmed": 8,
          "deaths": 1,
          "recovered": 0,
          "id": "KE-42"
        },
        {
          "confirmed": 10,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-41"
        },
        {
          "confirmed": 5,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-40"
        },
        {
          "confirmed": 16,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-39"
        },
        {
          "confirmed": 19,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-38"
        },
        {
          "confirmed": 2,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-37"
        },
        {
          "confirmed": 4,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-36"
        },
        {
          "confirmed": 220,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-35"
        },
        {
          "confirmed": 7,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-34"
        },
        {
          "confirmed": 3,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-33"
        },
        {
          "confirmed": 23,
          "deaths": 1,
          "recovered": 0,
          "id": "KE-32"
        },
        {
          "confirmed": 5,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-31"
        },
        {
          "confirmed": 5,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-30"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-29"
        },
        {
          "confirmed": 7,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-28"
        },
        {
          "confirmed": 1,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-27"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-26"
        },
        {
          "confirmed": 1,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-25"
        },
        {
          "confirmed": 5,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-24"
        },
        {
          "confirmed": 2,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-23"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-22"
        },
        {
          "confirmed": 9,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-21"
        },
        {
          "confirmed": 95,
          "deaths": 0,
          "recovered": 1,
          "id": "KE-20"
        },
        {
          "confirmed": 6,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-19"
        },
        {
          "confirmed": 8,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-18"
        },
        {
          "confirmed": 1,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-17"
        },
        {
          "confirmed": 11,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-16"
        },
        {
          "confirmed": 25,
          "deaths": 0,
          "recovered": 2,
          "id": "KE-15"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-14"
        },
        {
          "confirmed": 13,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-13"
        },
        {
          "confirmed": 2,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-12"
        },
        {
          "confirmed": 23,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-11"
        },
        {
          "confirmed": 28,
          "deaths": 2,
          "recovered": 0,
          "id": "KE-10"
        },
        {
          "confirmed": 1,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-9"
        },
        {
          "confirmed": 10,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-8"
        },
        {
          "confirmed": 3,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-7"
        },
        {
          "confirmed": 34,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-6"
        },
        {
          "confirmed": 177,
          "deaths": 3,
          "recovered": 2,
          "id": "KE-5"
        },
        {
          "confirmed": 9,
          "deaths": 0,
          "recovered": 1,
          "id": "KE-4"
        },
        {
          "confirmed": 1,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-3"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-2"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-1"
        }
      ]
    },
    {
      "date": "2020-03-12",
      "list": [
        
       
        {
          "confirmed": 2,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-47"
        },
        {
          "confirmed": 17,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-46"
        },
        {
          "confirmed": 5,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-45"
        },
        {
          "confirmed": 27,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-44"
        },
        {
          "confirmed": 18,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-43"
        },
        {
          "confirmed": 8,
          "deaths": 1,
          "recovered": 0,
          "id": "KE-42"
        },
        {
          "confirmed": 12,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-41"
        },
        {
          "confirmed": 5,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-40"
        },
        {
          "confirmed": 22,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-39"
        },
        {
          "confirmed": 24,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-38"
        },
        {
          "confirmed": 2,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-37"
        },
        {
          "confirmed": 5,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-36"
        },
        {
          "confirmed": 328,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-35"
        },
        {
          "confirmed": 14,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-34"
        },
        {
          "confirmed": 5,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-33"
        },
        {
          "confirmed": 29,
          "deaths": 1,
          "recovered": 0,
          "id": "KE-32"
        },
        {
          "confirmed": 6,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-31"
        },
        {
          "confirmed": 10,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-30"
        },
        {
          "confirmed": 1,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-29"
        },
        {
          "confirmed": 15,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-28"
        },
        {
          "confirmed": 1,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-27"
        },
        {
          "confirmed": 1,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-26"
        },
        {
          "confirmed": 1,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-25"
        },
        {
          "confirmed": 9,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-24"
        },
        {
          "confirmed": 2,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-23"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-22"
        },
        {
          "confirmed": 12,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-21"
        },
        {
          "confirmed": 108,
          "deaths": 0,
          "recovered": 1,
          "id": "KE-20"
        },
        {
          "confirmed": 19,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-19"
        },
        {
          "confirmed": 10,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-18"
        },
        {
          "confirmed": 1,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-17"
        },
        {
          "confirmed": 13,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-16"
        },
        {
          "confirmed": 32,
          "deaths": 0,
          "recovered": 2,
          "id": "KE-15"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-14"
        },
        {
          "confirmed": 16,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-13"
        },
        {
          "confirmed": 2,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-12"
        },
        {
          "confirmed": 31,
          "deaths": 1,
          "recovered": 0,
          "id": "KE-11"
        },
        {
          "confirmed": 35,
          "deaths": 2,
          "recovered": 0,
          "id": "KE-10"
        },
        {
          "confirmed": 1,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-9"
        },
        {
          "confirmed": 10,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-8"
        },
        {
          "confirmed": 5,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-7"
        },
        {
          "confirmed": 45,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-6"
        },
        {
          "confirmed": 221,
          "deaths": 4,
          "recovered": 6,
          "id": "KE-5"
        },
        {
          "confirmed": 9,
          "deaths": 0,
          "recovered": 1,
          "id": "KE-4"
        },
        {
          "confirmed": 6,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-3"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-2"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-1"
        }
      ]
    },
    {
      "date": "2020-03-13",
      "list": [
        
        
        {
          "confirmed": 2,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-47"
        },
        {
          "confirmed": 30,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-46"
        },
        {
          "confirmed": 9,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-45"
        },
        {
          "confirmed": 43,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-44"
        },
        {
          "confirmed": 26,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-43"
        },
        {
          "confirmed": 8,
          "deaths": 1,
          "recovered": 0,
          "id": "KE-42"
        },
        {
          "confirmed": 13,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-41"
        },
        {
          "confirmed": 14,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-40"
        },
        {
          "confirmed": 41,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-39"
        },
        {
          "confirmed": 30,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-38"
        },
        {
          "confirmed": 2,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-37"
        },
        {
          "confirmed": 13,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-36"
        },
        {
          "confirmed": 421,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-35"
        },
        {
          "confirmed": 17,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-34"
        },
        {
          "confirmed": 10,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-33"
        },
        {
          "confirmed": 29,
          "deaths": 1,
          "recovered": 0,
          "id": "KE-32"
        },
        {
          "confirmed": 6,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-31"
        },
        {
          "confirmed": 13,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-30"
        },
        {
          "confirmed": 1,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-29"
        },
        {
          "confirmed": 17,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-28"
        },
        {
          "confirmed": 1,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-27"
        },
        {
          "confirmed": 1,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-26"
        },
        {
          "confirmed": 2,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-25"
        },
        {
          "confirmed": 14,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-24"
        },
        {
          "confirmed": 16,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-23"
        },
        {
          "confirmed": 1,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-22"
        },
        {
          "confirmed": 18,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-21"
        },
        {
          "confirmed": 123,
          "deaths": 0,
          "recovered": 1,
          "id": "KE-20"
        },
        {
          "confirmed": 36,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-19"
        },
        {
          "confirmed": 14,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-18"
        },
        {
          "confirmed": 5,
          "deaths": 1,
          "recovered": 0,
          "id": "KE-17"
        },
        {
          "confirmed": 13,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-16"
        },
        {
          "confirmed": 46,
          "deaths": 0,
          "recovered": 2,
          "id": "KE-15"
        },
        {
          "confirmed": 1,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-14"
        },
        {
          "confirmed": 17,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-13"
        },
        {
          "confirmed": 2,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-12"
        },
        {
          "confirmed": 42,
          "deaths": 1,
          "recovered": 0,
          "id": "KE-11"
        },
        {
          "confirmed": 50,
          "deaths": 2,
          "recovered": 0,
          "id": "KE-10"
        },
        {
          "confirmed": 4,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-9"
        },
        {
          "confirmed": 10,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-8"
        },
        {
          "confirmed": 11,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-7"
        },
        {
          "confirmed": 49,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-6"
        },
        {
          "confirmed": 282,
          "deaths": 4,
          "recovered": 6,
          "id": "KE-5"
        },
        {
          "confirmed": 9,
          "deaths": 0,
          "recovered": 1,
          "id": "KE-4"
        },
        {
          "confirmed": 6,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-3"
        },
        {
          "confirmed": 5,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-2"
        },
        {
          "confirmed": 1,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-1"
        }
      ]
    },
    {
      "date": "2020-03-14",
      "list": [
        
       
        {
          "confirmed": 5,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-47"
        },
        {
          "confirmed": 41,
          "deaths": 1,
          "recovered": 0,
          "id": "KE-46"
        },
        {
          "confirmed": 10,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-45"
        },
        {
          "confirmed": 57,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-44"
        },
        {
          "confirmed": 32,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-43"
        },
        {
          "confirmed": 9,
          "deaths": 1,
          "recovered": 0,
          "id": "KE-42"
        },
        {
          "confirmed": 19,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-41"
        },
        {
          "confirmed": 20,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-40"
        },
        {
          "confirmed": 47,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-39"
        },
        {
          "confirmed": 32,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-38"
        },
        {
          "confirmed": 4,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-37"
        },
        {
          "confirmed": 26,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-36"
        },
        {
          "confirmed": 525,
          "deaths": 2,
          "recovered": 0,
          "id": "KE-35"
        },
        {
          "confirmed": 21,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-34"
        },
        {
          "confirmed": 10,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-33"
        },
        {
          "confirmed": 69,
          "deaths": 1,
          "recovered": 0,
          "id": "KE-32"
        },
        {
          "confirmed": 7,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-31"
        },
        {
          "confirmed": 14,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-30"
        },
        {
          "confirmed": 1,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-29"
        },
        {
          "confirmed": 24,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-28"
        },
        {
          "confirmed": 5,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-27"
        },
        {
          "confirmed": 6,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-26"
        },
        {
          "confirmed": 4,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-25"
        },
        {
          "confirmed": 21,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-24"
        },
        {
          "confirmed": 25,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-23"
        },
        {
          "confirmed": 3,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-22"
        },
        {
          "confirmed": 26,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-21"
        },
        {
          "confirmed": 138,
          "deaths": 0,
          "recovered": 1,
          "id": "KE-20"
        },
        {
          "confirmed": 77,
          "deaths": 1,
          "recovered": 0,
          "id": "KE-19"
        },
        {
          "confirmed": 14,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-18"
        },
        {
          "confirmed": 8,
          "deaths": 1,
          "recovered": 0,
          "id": "KE-17"
        },
        {
          "confirmed": 16,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-16"
        },
        {
          "confirmed": 64,
          "deaths": 0,
          "recovered": 2,
          "id": "KE-15"
        },
        {
          "confirmed": 2,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-14"
        },
        {
          "confirmed": 17,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-13"
        },
        {
          "confirmed": 4,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-12"
        },
        {
          "confirmed": 66,
          "deaths": 1,
          "recovered": 0,
          "id": "KE-11"
        },
        {
          "confirmed": 76,
          "deaths": 3,
          "recovered": 0,
          "id": "KE-10"
        },
        {
          "confirmed": 6,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-9"
        },
        {
          "confirmed": 10,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-8"
        },
        {
          "confirmed": 22,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-7"
        },
        {
          "confirmed": 101,
          "deaths": 1,
          "recovered": 0,
          "id": "KE-6"
        },
        {
          "confirmed": 340,
          "deaths": 5,
          "recovered": 6,
          "id": "KE-5"
        },
        {
          "confirmed": 12,
          "deaths": 0,
          "recovered": 1,
          "id": "KE-4"
        },
        {
          "confirmed": 12,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-3"
        },
        {
          "confirmed": 6,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-2"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-1"
        }
      ]
    },
    {
      "date": "2020-03-15",
      "list": [
        
        
        {
          "confirmed": 8,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-47"
        },
        {
          "confirmed": 45,
          "deaths": 1,
          "recovered": 0,
          "id": "KE-46"
        },
        {
          "confirmed": 28,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-45"
        },
        {
          "confirmed": 72,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-44"
        },
        {
          "confirmed": 39,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-43"
        },
        {
          "confirmed": 9,
          "deaths": 1,
          "recovered": 0,
          "id": "KE-42"
        },
        {
          "confirmed": 28,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-41"
        },
        {
          "confirmed": 20,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-40"
        },
        {
          "confirmed": 66,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-39"
        },
        {
          "confirmed": 36,
          "deaths": 1,
          "recovered": 0,
          "id": "KE-38"
        },
        {
          "confirmed": 7,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-37"
        },
        {
          "confirmed": 37,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-36"
        },
        {
          "confirmed": 7,
          "deaths": 3,
          "recovered": 0,
          "id": "KE-35"
        },
        {
          "confirmed": 24,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-34"
        },
        {
          "confirmed": 13,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-33"
        },
        {
          "confirmed": 98,
          "deaths": 2,
          "recovered": 0,
          "id": "KE-32"
        },
        {
          "confirmed": 13,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-31"
        },
        {
          "confirmed": 17,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-30"
        },
        {
          "confirmed": 1,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-29"
        },
        {
          "confirmed": 33,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-28"
        },
        {
          "confirmed": 7,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-27"
        },
        {
          "confirmed": 10,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-26"
        },
        {
          "confirmed": 5,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-25"
        },
        {
          "confirmed": 35,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-24"
        },
        {
          "confirmed": 33,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-23"
        },
        {
          "confirmed": 12,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-22"
        },
        {
          "confirmed": 32,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-21"
        },
        {
          "confirmed": 164,
          "deaths": 0,
          "recovered": 1,
          "id": "KE-20"
        },
        {
          "confirmed": 91,
          "deaths": 2,
          "recovered": 0,
          "id": "KE-19"
        },
        {
          "confirmed": 20,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-18"
        },
        {
          "confirmed": 8,
          "deaths": 1,
          "recovered": 0,
          "id": "KE-17"
        },
        {
          "confirmed": 20,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-16"
        },
        {
          "confirmed": 93,
          "deaths": 0,
          "recovered": 2,
          "id": "KE-15"
        },
        {
          "confirmed": 5,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-14"
        },
        {
          "confirmed": 18,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-13"
        },
        {
          "confirmed": 6,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-12"
        },
        {
          "confirmed": 99,
          "deaths": 1,
          "recovered": 0,
          "id": "KE-11"
        },
        {
          "confirmed": 115,
          "deaths": 4,
          "recovered": 0,
          "id": "KE-10"
        },
        {
          "confirmed": 7,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-9"
        },
        {
          "confirmed": 16,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-8"
        },
        {
          "confirmed": 24,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-7"
        },
        {
          "confirmed": 131,
          "deaths": 1,
          "recovered": 0,
          "id": "KE-6"
        },
        {
          "confirmed": 426,
          "deaths": 6,
          "recovered": 6,
          "id": "KE-5"
        },
        {
          "confirmed": 10,
          "deaths": 0,
          "recovered": 1,
          "id": "KE-4"
        },
        {
          "confirmed": 6,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-3"
        },
        {
          "confirmed": 12,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-2"
        },
        {
          "confirmed": 1,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-1"
        }
      ]
    },
    {
      "date": "2020-03-16",
      "list": [
        
        
        {
          "confirmed": 12,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-47"
        },
        {
          "confirmed": 49,
          "deaths": 1,
          "recovered": 0,
          "id": "KE-46"
        },
        {
          "confirmed": 39,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-45"
        },
        {
          "confirmed": 85,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-44"
        },
        {
          "confirmed": 12,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-43"
        },
        {
          "confirmed": 10,
          "deaths": 1,
          "recovered": 0,
          "id": "KE-42"
        },
        {
          "confirmed": 33,
          "deaths": 1,
          "recovered": 0,
          "id": "KE-41"
        },
        {
          "confirmed": 21,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-40"
        },
        {
          "confirmed": 77,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-39"
        },
        {
          "confirmed": 39,
          "deaths": 1,
          "recovered": 0,
          "id": "KE-38"
        },
        {
          "confirmed": 10,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-37"
        },
        {
          "confirmed": 50,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-36"
        },
        {
          "confirmed": 9,
          "deaths": 10,
          "recovered": 0,
          "id": "KE-35"
        },
        {
          "confirmed": 45,
          "deaths": 1,
          "recovered": 0,
          "id": "KE-34"
        },
        {
          "confirmed": 17,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-33"
        },
        {
          "confirmed": 178,
          "deaths": 2,
          "recovered": 1,
          "id": "KE-32"
        },
        {
          "confirmed": 17,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-31"
        },
        {
          "confirmed": 18,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-30"
        },
        {
          "confirmed": 1,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-29"
        },
        {
          "confirmed": 38,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-28"
        },
        {
          "confirmed": 7,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-27"
        },
        {
          "confirmed": 13,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-26"
        },
        {
          "confirmed": 6,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-25"
        },
        {
          "confirmed": 54,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-24"
        },
        {
          "confirmed": 53,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-23"
        },
        {
          "confirmed": 17,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-22"
        },
        {
          "confirmed": 41,
          "deaths": 0,
          "recovered": 3,
          "id": "KE-21"
        },
        {
          "confirmed": 197,
          "deaths": 0,
          "recovered": 1,
          "id": "KE-20"
        },
        {
          "confirmed": 136,
          "deaths": 3,
          "recovered": 0,
          "id": "KE-19"
        },
        {
          "confirmed": 21,
          "deaths": 1,
          "recovered": 1,
          "id": "KE-18"
        },
        {
          "confirmed": 11,
          "deaths": 1,
          "recovered": 0,
          "id": "KE-17"
        },
        {
          "confirmed": 25,
          "deaths": 1,
          "recovered": 0,
          "id": "KE-16"
        },
        {
          "confirmed": 105,
          "deaths": 0,
          "recovered": 2,
          "id": "KE-15"
        },
        {
          "confirmed": 5,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-14"
        },
        {
          "confirmed": 23,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-13"
        },
        {
          "confirmed": 7,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-12"
        },
        {
          "confirmed": 121,
          "deaths": 1,
          "recovered": 0,
          "id": "KE-11"
        },
        {
          "confirmed": 155,
          "deaths": 3,
          "recovered": 0,
          "id": "KE-10"
        },
        {
          "confirmed": 8,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-9"
        },
        {
          "confirmed": 22,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-8"
        },
        {
          "confirmed": 30,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-7"
        },
        {
          "confirmed": 160,
          "deaths": 1,
          "recovered": 0,
          "id": "KE-6"
        },
        {
          "confirmed": 557,
          "deaths": 7,
          "recovered": 6,
          "id": "KE-5"
        },
        {
          "confirmed": 18,
          "deaths": 0,
          "recovered": 1,
          "id": "KE-4"
        },
        {
          "confirmed": 22,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-3"
        },
        {
          "confirmed": 29,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-2"
        },
        {
          "confirmed": 1,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-1"
        }
      ]
    },
    {
      "date": "2020-03-17",
      "list": [
        
       
        {
          "confirmed": 12,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-47"
        },
        {
          "confirmed": 67,
          "deaths": 2,
          "recovered": 0,
          "id": "KE-46"
        },
        {
          "confirmed": 51,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-45"
        },
        {
          "confirmed": 110,
          "deaths": 1,
          "recovered": 0,
          "id": "KE-44"
        },
        {
          "confirmed": 74,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-43"
        },
        {
          "confirmed": 11,
          "deaths": 1,
          "recovered": 0,
          "id": "KE-42"
        },
        {
          "confirmed": 47,
          "deaths": 1,
          "recovered": 0,
          "id": "KE-41"
        },
        {
          "confirmed": 23,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-40"
        },
        {
          "confirmed": 112,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-39"
        },
        {
          "confirmed": 66,
          "deaths": 1,
          "recovered": 0,
          "id": "KE-38"
        },
        {
          "confirmed": 19,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-37"
        },
        {
          "confirmed": 67,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-36"
        },
        {
          "confirmed": 17,
          "deaths": 13,
          "recovered": 0,
          "id": "KE-35"
        },
        {
          "confirmed": 56,
          "deaths": 1,
          "recovered": 0,
          "id": "KE-34"
        },
        {
          "confirmed": 23,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-33"
        },
        {
          "confirmed": 267,
          "deaths": 3,
          "recovered": 1,
          "id": "KE-32"
        },
        {
          "confirmed": 26,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-31"
        },
        {
          "confirmed": 21,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-30"
        },
        {
          "confirmed": 3,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-29"
        },
        {
          "confirmed": 64,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-28"
        },
        {
          "confirmed": 9,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-27"
        },
        {
          "confirmed": 21,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-26"
        },
        {
          "confirmed": 11,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-25"
        },
        {
          "confirmed": 60,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-24"
        },
        {
          "confirmed": 65,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-23"
        },
        {
          "confirmed": 32,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-22"
        },
        {
          "confirmed": 60,
          "deaths": 0,
          "recovered": 3,
          "id": "KE-21"
        },
        {
          "confirmed": 218,
          "deaths": 0,
          "recovered": 1,
          "id": "KE-20"
        },
        {
          "confirmed": 196,
          "deaths": 4,
          "recovered": 0,
          "id": "KE-19"
        },
        {
          "confirmed": 26,
          "deaths": 1,
          "recovered": 1,
          "id": "KE-18"
        },
        {
          "confirmed": 18,
          "deaths": 1,
          "recovered": 0,
          "id": "KE-17"
        },
        {
          "confirmed": 30,
          "deaths": 2,
          "recovered": 0,
          "id": "KE-16"
        },
        {
          "confirmed": 161,
          "deaths": 1,
          "recovered": 2,
          "id": "KE-15"
        },
        {
          "confirmed": 8,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-14"
        },
        {
          "confirmed": 23,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-13"
        },
        {
          "confirmed": 10,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-12"
        },
        {
          "confirmed": 146,
          "deaths": 1,
          "recovered": 0,
          "id": "KE-11"
        },
        {
          "confirmed": 216,
          "deaths": 6,
          "recovered": 0,
          "id": "KE-10"
        },
        {
          "confirmed": 16,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-9"
        },
        {
          "confirmed": 22,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-8"
        },
        {
          "confirmed": 68,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-7"
        },
        {
          "confirmed": 160,
          "deaths": 2,
          "recovered": 0,
          "id": "KE-6"
        },
        {
          "confirmed": 698,
          "deaths": 12,
          "recovered": 6,
          "id": "KE-5"
        },
        {
          "confirmed": 20,
          "deaths": 0,
          "recovered": 1,
          "id": "KE-4"
        },
        {
          "confirmed": 22,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-3"
        },
        {
          "confirmed": 39,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-2"
        },
        {
          "confirmed": 3,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-1"
        }
      ]
    },
    {
      "date": "2020-03-18",
      "list": [
        
        
        {
          "confirmed": 18,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-47"
        },
        {
          "confirmed": 77,
          "deaths": 2,
          "recovered": 0,
          "id": "KE-46"
        },
        {
          "confirmed": 51,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-45"
        },
        {
          "confirmed": 173,
          "deaths": 3,
          "recovered": 0,
          "id": "KE-44"
        },
        {
          "confirmed": 79,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-43"
        },
        {
          "confirmed": 11,
          "deaths": 1,
          "recovered": 0,
          "id": "KE-42"
        },
        {
          "confirmed": 47,
          "deaths": 1,
          "recovered": 0,
          "id": "KE-41"
        },
        {
          "confirmed": 33,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-40"
        },
        {
          "confirmed": 152,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-39"
        },
        {
          "confirmed": 68,
          "deaths": 2,
          "recovered": 0,
          "id": "KE-38"
        },
        {
          "confirmed": 19,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-37"
        },
        {
          "confirmed": 86,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-36"
        },
        {
          "confirmed": 24,
          "deaths": 16,
          "recovered": 0,
          "id": "KE-35"
        },
        {
          "confirmed": 55,
          "deaths": 1,
          "recovered": 0,
          "id": "KE-34"
        },
        {
          "confirmed": 23,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-33"
        },
        {
          "confirmed": 267,
          "deaths": 3,
          "recovered": 0,
          "id": "KE-32"
        },
        {
          "confirmed": 26,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-31"
        },
        {
          "confirmed": 24,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-30"
        },
        {
          "confirmed": 6,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-29"
        },
        {
          "confirmed": 70,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-28"
        },
        {
          "confirmed": 11,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-27"
        },
        {
          "confirmed": 34,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-26"
        },
        {
          "confirmed": 18,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-25"
        },
        {
          "confirmed": 77,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-24"
        },
        {
          "confirmed": 83,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-23"
        },
        {
          "confirmed": 42,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-22"
        },
        {
          "confirmed": 85,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-21"
        },
        {
          "confirmed": 218,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-20"
        },
        {
          "confirmed": 257,
          "deaths": 4,
          "recovered": 0,
          "id": "KE-19"
        },
        {
          "confirmed": 27,
          "deaths": 1,
          "recovered": 0,
          "id": "KE-18"
        },
        {
          "confirmed": 18,
          "deaths": 1,
          "recovered": 0,
          "id": "KE-17"
        },
        {
          "confirmed": 39,
          "deaths": 2,
          "recovered": 0,
          "id": "KE-16"
        },
        {
          "confirmed": 162,
          "deaths": 1,
          "recovered": 0,
          "id": "KE-15"
        },
        {
          "confirmed": 9,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-14"
        },
        {
          "confirmed": 29,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-13"
        },
        {
          "confirmed": 14,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-12"
        },
        {
          "confirmed": 199,
          "deaths": 3,
          "recovered": 0,
          "id": "KE-11"
        },
        {
          "confirmed": 314,
          "deaths": 7,
          "recovered": 0,
          "id": "KE-10"
        },
        {
          "confirmed": 19,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-9"
        },
        {
          "confirmed": 31,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-8"
        },
        {
          "confirmed": 68,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-7"
        },
        {
          "confirmed": 184,
          "deaths": 2,
          "recovered": 0,
          "id": "KE-6"
        },
        {
          "confirmed": 751,
          "deaths": 13,
          "recovered": 0,
          "id": "KE-5"
        },
        {
          "confirmed": 27,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-4"
        },
        {
          "confirmed": 33,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-3"
        },
        {
          "confirmed": 46,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-2"
        },
        {
          "confirmed": 6,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-1"
        }
      ]
    },
    {
      "date": "2020-03-19",
      "list": [
        
       
        {
          "confirmed": 22,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-47"
        },
        {
          "confirmed": 99,
          "deaths": 2,
          "recovered": 0,
          "id": "KE-46"
        },
        {
          "confirmed": 80,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-45"
        },
        {
          "confirmed": 260,
          "deaths": 5,
          "recovered": 0,
          "id": "KE-44"
        },
        {
          "confirmed": 154,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-43"
        },
        {
          "confirmed": 11,
          "deaths": 1,
          "recovered": 0,
          "id": "KE-42"
        },
        {
          "confirmed": 81,
          "deaths": 1,
          "recovered": 0,
          "id": "KE-41"
        },
        {
          "confirmed": 44,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-40"
        },
        {
          "confirmed": 206,
          "deaths": 1,
          "recovered": 0,
          "id": "KE-39"
        },
        {
          "confirmed": 88,
          "deaths": 3,
          "recovered": 0,
          "id": "KE-38"
        },
        {
          "confirmed": 44,
          "deaths": 1,
          "recovered": 0,
          "id": "KE-37"
        },
        {
          "confirmed": 119,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-36"
        },
        {
          "confirmed": 53,
          "deaths": 34,
          "recovered": 0,
          "id": "KE-35"
        },
        {
          "confirmed": 95,
          "deaths": 1,
          "recovered": 0,
          "id": "KE-34"
        },
        {
          "confirmed": 35,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-33"
        },
        {
          "confirmed": 742,
          "deaths": 9,
          "recovered": 0,
          "id": "KE-32"
        },
        {
          "confirmed": 44,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-31"
        },
        {
          "confirmed": 29,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-30"
        },
        {
          "confirmed": 18,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-29"
        },
        {
          "confirmed": 123,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-28"
        },
        {
          "confirmed": 11,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-27"
        },
        {
          "confirmed": 50,
          "deaths": 1,
          "recovered": 0,
          "id": "KE-26"
        },
        {
          "confirmed": 31,
          "deaths": 1,
          "recovered": 0,
          "id": "KE-25"
        },
        {
          "confirmed": 89,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-24"
        },
        {
          "confirmed": 334,
          "deaths": 3,
          "recovered": 0,
          "id": "KE-23"
        },
        {
          "confirmed": 52,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-22"
        },
        {
          "confirmed": 107,
          "deaths": 1,
          "recovered": 0,
          "id": "KE-21"
        },
        {
          "confirmed": 328,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-20"
        },
        {
          "confirmed": 392,
          "deaths": 10,
          "recovered": 0,
          "id": "KE-19"
        },
        {
          "confirmed": 37,
          "deaths": 2,
          "recovered": 0,
          "id": "KE-18"
        },
        {
          "confirmed": 34,
          "deaths": 1,
          "recovered": 0,
          "id": "KE-17"
        },
        {
          "confirmed": 60,
          "deaths": 2,
          "recovered": 0,
          "id": "KE-16"
        },
        {
          "confirmed": 422,
          "deaths": 4,
          "recovered": 0,
          "id": "KE-15"
        },
        {
          "confirmed": 11,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-14"
        },
        {
          "confirmed": 44,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-13"
        },
        {
          "confirmed": 16,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-12"
        },
        {
          "confirmed": 287,
          "deaths": 10,
          "recovered": 0,
          "id": "KE-11"
        },
        {
          "confirmed": 417,
          "deaths": 9,
          "recovered": 0,
          "id": "KE-10"
        },
        {
          "confirmed": 30,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-9"
        },
        {
          "confirmed": 40,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-8"
        },
        {
          "confirmed": 159,
          "deaths": 2,
          "recovered": 0,
          "id": "KE-7"
        },
        {
          "confirmed": 277,
          "deaths": 4,
          "recovered": 0,
          "id": "KE-6"
        },
        {
          "confirmed": 952,
          "deaths": 18,
          "recovered": 0,
          "id": "KE-5"
        },
        {
          "confirmed": 45,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-4"
        },
        {
          "confirmed": 62,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-3"
        },
        {
          "confirmed": 78,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-2"
        },
        {
          "confirmed": 9,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-1"
        }
      ]
    },
    {
      "date": "2020-03-20",
      "list": [
        
        
        {
          "confirmed": 29,
          "deaths": 2,
          "recovered": 0,
          "id": "KE-47"
        },
        {
          "confirmed": 122,
          "deaths": 2,
          "recovered": 0,
          "id": "KE-46"
        },
        {
          "confirmed": 78,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-45"
        },
        {
          "confirmed": 394,
          "deaths": 5,
          "recovered": 0,
          "id": "KE-44"
        },
        {
          "confirmed": 233,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-43"
        },
        {
          "confirmed": 14,
          "deaths": 1,
          "recovered": 0,
          "id": "KE-42"
        },
        {
          "confirmed": 126,
          "deaths": 1,
          "recovered": 0,
          "id": "KE-41"
        },
        {
          "confirmed": 54,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-40"
        },
        {
          "confirmed": 303,
          "deaths": 1,
          "recovered": 0,
          "id": "KE-39"
        },
        {
          "confirmed": 114,
          "deaths": 3,
          "recovered": 0,
          "id": "KE-38"
        },
        {
          "confirmed": 49,
          "deaths": 1,
          "recovered": 0,
          "id": "KE-37"
        },
        {
          "confirmed": 173,
          "deaths": 2,
          "recovered": 0,
          "id": "KE-36"
        },
        {
          "confirmed": 83,
          "deaths": 42,
          "recovered": 0,
          "id": "KE-35"
        },
        {
          "confirmed": 114,
          "deaths": 1,
          "recovered": 0,
          "id": "KE-34"
        },
        {
          "confirmed": 43,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-33"
        },
        {
          "confirmed": 890,
          "deaths": 11,
          "recovered": 0,
          "id": "KE-32"
        },
        {
          "confirmed": 44,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-31"
        },
        {
          "confirmed": 37,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-30"
        },
        {
          "confirmed": 19,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-29"
        },
        {
          "confirmed": 172,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-28"
        },
        {
          "confirmed": 15,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-27"
        },
        {
          "confirmed": 80,
          "deaths": 1,
          "recovered": 0,
          "id": "KE-26"
        },
        {
          "confirmed": 53,
          "deaths": 2,
          "recovered": 0,
          "id": "KE-25"
        },
        {
          "confirmed": 115,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-24"
        },
        {
          "confirmed": 552,
          "deaths": 3,
          "recovered": 0,
          "id": "KE-23"
        },
        {
          "confirmed": 56,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-22"
        },
        {
          "confirmed": 149,
          "deaths": 1,
          "recovered": 0,
          "id": "KE-21"
        },
        {
          "confirmed": 413,
          "deaths": 1,
          "recovered": 0,
          "id": "KE-20"
        },
        {
          "confirmed": 538,
          "deaths": 14,
          "recovered": 0,
          "id": "KE-19"
        },
        {
          "confirmed": 47,
          "deaths": 2,
          "recovered": 0,
          "id": "KE-18"
        },
        {
          "confirmed": 44,
          "deaths": 1,
          "recovered": 0,
          "id": "KE-17"
        },
        {
          "confirmed": 86,
          "deaths": 2,
          "recovered": 0,
          "id": "KE-16"
        },
        {
          "confirmed": 585,
          "deaths": 5,
          "recovered": 0,
          "id": "KE-15"
        },
        {
          "confirmed": 23,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-14"
        },
        {
          "confirmed": 45,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-13"
        },
        {
          "confirmed": 26,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-12"
        },
        {
          "confirmed": 420,
          "deaths": 13,
          "recovered": 0,
          "id": "KE-11"
        },
        {
          "confirmed": 563,
          "deaths": 10,
          "recovered": 0,
          "id": "KE-10"
        },
        {
          "confirmed": 38,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-9"
        },
        {
          "confirmed": 71,
          "deaths": 1,
          "recovered": 0,
          "id": "KE-8"
        },
        {
          "confirmed": 194,
          "deaths": 3,
          "recovered": 0,
          "id": "KE-7"
        },
        {
          "confirmed": 363,
          "deaths": 4,
          "recovered": 0,
          "id": "KE-6"
        },
        {
          "confirmed": 1177,
          "deaths": 23,
          "recovered": 0,
          "id": "KE-5"
        },
        {
          "confirmed": 78,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-4"
        },
        {
          "confirmed": 96,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-3"
        },
        {
          "confirmed": 83,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-2"
        },
        {
          "confirmed": 12,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-1"
        }
      ]
    },
    {
      "date": "2020-03-21",
      "list": [
        
        
        {
          "confirmed": 29,
          "deaths": 2,
          "recovered": 0,
          "id": "KE-47"
        },
        {
          "confirmed": 156,
          "deaths": 2,
          "recovered": 0,
          "id": "KE-46"
        },
        {
          "confirmed": 136,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-45"
        },
        {
          "confirmed": 581,
          "deaths": 5,
          "recovered": 0,
          "id": "KE-44"
        },
        {
          "confirmed": 371,
          "deaths": 1,
          "recovered": 0,
          "id": "KE-43"
        },
        {
          "confirmed": 14,
          "deaths": 1,
          "recovered": 0,
          "id": "KE-42"
        },
        {
          "confirmed": 171,
          "deaths": 3,
          "recovered": 0,
          "id": "KE-41"
        },
        {
          "confirmed": 66,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-40"
        },
        {
          "confirmed": 396,
          "deaths": 2,
          "recovered": 0,
          "id": "KE-39"
        },
        {
          "confirmed": 114,
          "deaths": 5,
          "recovered": 0,
          "id": "KE-38"
        },
        {
          "confirmed": 53,
          "deaths": 1,
          "recovered": 0,
          "id": "KE-37"
        },
        {
          "confirmed": 248,
          "deaths": 3,
          "recovered": 0,
          "id": "KE-36"
        },
        {
          "confirmed": 11,
          "deaths": 60,
          "recovered": 0,
          "id": "KE-35"
        },
        {
          "confirmed": 161,
          "deaths": 2,
          "recovered": 0,
          "id": "KE-34"
        },
        {
          "confirmed": 43,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-33"
        },
        {
          "confirmed": 1327,
          "deaths": 16,
          "recovered": 0,
          "id": "KE-32"
        },
        {
          "confirmed": 55,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-31"
        },
        {
          "confirmed": 38,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-30"
        },
        {
          "confirmed": 28,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-29"
        },
        {
          "confirmed": 253,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-28"
        },
        {
          "confirmed": 21,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-27"
        },
        {
          "confirmed": 140,
          "deaths": 1,
          "recovered": 0,
          "id": "KE-26"
        },
        {
          "confirmed": 74,
          "deaths": 3,
          "recovered": 0,
          "id": "KE-25"
        },
        {
          "confirmed": 138,
          "deaths": 1,
          "recovered": 0,
          "id": "KE-24"
        },
        {
          "confirmed": 788,
          "deaths": 5,
          "recovered": 0,
          "id": "KE-23"
        },
        {
          "confirmed": 70,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-22"
        },
        {
          "confirmed": 193,
          "deaths": 2,
          "recovered": 0,
          "id": "KE-21"
        },
        {
          "confirmed": 525,
          "deaths": 1,
          "recovered": 0,
          "id": "KE-20"
        },
        {
          "confirmed": 585,
          "deaths": 16,
          "recovered": 0,
          "id": "KE-19"
        },
        {
          "confirmed": 87,
          "deaths": 3,
          "recovered": 0,
          "id": "KE-18"
        },
        {
          "confirmed": 57,
          "deaths": 2,
          "recovered": 0,
          "id": "KE-17"
        },
        {
          "confirmed": 128,
          "deaths": 4,
          "recovered": 0,
          "id": "KE-16"
        },
        {
          "confirmed": 753,
          "deaths": 6,
          "recovered": 0,
          "id": "KE-15"
        },
        {
          "confirmed": 36,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-14"
        },
        {
          "confirmed": 68,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-13"
        },
        {
          "confirmed": 37,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-12"
        },
        {
          "confirmed": 507,
          "deaths": 14,
          "recovered": 0,
          "id": "KE-11"
        },
        {
          "confirmed": 659,
          "deaths": 13,
          "recovered": 0,
          "id": "KE-10"
        },
        {
          "confirmed": 45,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-9"
        },
        {
          "confirmed": 98,
          "deaths": 1,
          "recovered": 0,
          "id": "KE-8"
        },
        {
          "confirmed": 194,
          "deaths": 4,
          "recovered": 0,
          "id": "KE-7"
        },
        {
          "confirmed": 390,
          "deaths": 4,
          "recovered": 0,
          "id": "KE-6"
        },
        {
          "confirmed": 1364,
          "deaths": 24,
          "recovered": 0,
          "id": "KE-5"
        },
        {
          "confirmed": 118,
          "deaths": 1,
          "recovered": 0,
          "id": "KE-4"
        },
        {
          "confirmed": 122,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-3"
        },
        {
          "confirmed": 131,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-2"
        },
        {
          "confirmed": 15,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-1"
        }
      ]
    },
    {
      "date": "2020-03-22",
      "list": [
        
       
        {
          "confirmed": 52,
          "deaths": 2,
          "recovered": 0,
          "id": "KE-47"
        },
        {
          "confirmed": 220,
          "deaths": 6,
          "recovered": 0,
          "id": "KE-46"
        },
        {
          "confirmed": 162,
          "deaths": 1,
          "recovered": 0,
          "id": "KE-45"
        },
        {
          "confirmed": 643,
          "deaths": 7,
          "recovered": 0,
          "id": "KE-44"
        },
        {
          "confirmed": 505,
          "deaths": 2,
          "recovered": 0,
          "id": "KE-43"
        },
        {
          "confirmed": 21,
          "deaths": 1,
          "recovered": 0,
          "id": "KE-42"
        },
        {
          "confirmed": 196,
          "deaths": 3,
          "recovered": 0,
          "id": "KE-41"
        },
        {
          "confirmed": 83,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-40"
        },
        {
          "confirmed": 509,
          "deaths": 4,
          "recovered": 0,
          "id": "KE-39"
        },
        {
          "confirmed": 161,
          "deaths": 5,
          "recovered": 0,
          "id": "KE-38"
        },
        {
          "confirmed": 67,
          "deaths": 2,
          "recovered": 0,
          "id": "KE-37"
        },
        {
          "confirmed": 356,
          "deaths": 3,
          "recovered": 0,
          "id": "KE-36"
        },
        {
          "confirmed": 15,
          "deaths": 117,
          "recovered": 0,
          "id": "KE-35"
        },
        {
          "confirmed": 190,
          "deaths": 2,
          "recovered": 0,
          "id": "KE-34"
        },
        {
          "confirmed": 57,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-33"
        },
        {
          "confirmed": 1914,
          "deaths": 20,
          "recovered": 0,
          "id": "KE-32"
        },
        {
          "confirmed": 74,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-31"
        },
        {
          "confirmed": 51,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-30"
        },
        {
          "confirmed": 28,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-29"
        },
        {
          "confirmed": 305,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-28"
        },
        {
          "confirmed": 34,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-27"
        },
        {
          "confirmed": 207,
          "deaths": 1,
          "recovered": 0,
          "id": "KE-26"
        },
        {
          "confirmed": 87,
          "deaths": 3,
          "recovered": 0,
          "id": "KE-25"
        },
        {
          "confirmed": 167,
          "deaths": 1,
          "recovered": 0,
          "id": "KE-24"
        },
        {
          "confirmed": 1035,
          "deaths": 9,
          "recovered": 0,
          "id": "KE-23"
        },
        {
          "confirmed": 89,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-22"
        },
        {
          "confirmed": 244,
          "deaths": 3,
          "recovered": 0,
          "id": "KE-21"
        },
        {
          "confirmed": 646,
          "deaths": 5,
          "recovered": 0,
          "id": "KE-20"
        },
        {
          "confirmed": 837,
          "deaths": 20,
          "recovered": 0,
          "id": "KE-19"
        },
        {
          "confirmed": 103,
          "deaths": 3,
          "recovered": 0,
          "id": "KE-18"
        },
        {
          "confirmed": 65,
          "deaths": 2,
          "recovered": 0,
          "id": "KE-17"
        },
        {
          "confirmed": 204,
          "deaths": 6,
          "recovered": 0,
          "id": "KE-16"
        },
        {
          "confirmed": 1049,
          "deaths": 9,
          "recovered": 0,
          "id": "KE-15"
        },
        {
          "confirmed": 42,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-14"
        },
        {
          "confirmed": 90,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-13"
        },
        {
          "confirmed": 53,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-12"
        },
        {
          "confirmed": 621,
          "deaths": 25,
          "recovered": 0,
          "id": "KE-11"
        },
        {
          "confirmed": 1004,
          "deaths": 13,
          "recovered": 0,
          "id": "KE-10"
        },
        {
          "confirmed": 56,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-9"
        },
        {
          "confirmed": 204,
          "deaths": 2,
          "recovered": 0,
          "id": "KE-8"
        },
        {
          "confirmed": 327,
          "deaths": 8,
          "recovered": 0,
          "id": "KE-7"
        },
        {
          "confirmed": 591,
          "deaths": 6,
          "recovered": 0,
          "id": "KE-6"
        },
        {
          "confirmed": 1646,
          "deaths": 30,
          "recovered": 0,
          "id": "KE-5"
        },
        {
          "confirmed": 152,
          "deaths": 2,
          "recovered": 0,
          "id": "KE-4"
        },
        {
          "confirmed": 165,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-3"
        },
        {
          "confirmed": 157,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-2"
        },
        {
          "confirmed": 20,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-1"
        }
      ]
    },
    {
      "date": "2020-03-23",
      "list": [
        
        
        {
          "confirmed": 75,
          "deaths": 5,
          "recovered": 0,
          "id": "KE-47"
        },
        {
          "confirmed": 254,
          "deaths": 6,
          "recovered": 0,
          "id": "KE-46"
        },
        {
          "confirmed": 257,
          "deaths": 1,
          "recovered": 0,
          "id": "KE-45"
        },
        {
          "confirmed": 758,
          "deaths": 9,
          "recovered": 0,
          "id": "KE-44"
        },
        {
          "confirmed": 614,
          "deaths": 2,
          "recovered": 0,
          "id": "KE-43"
        },
        {
          "confirmed": 28,
          "deaths": 1,
          "recovered": 0,
          "id": "KE-42"
        },
        {
          "confirmed": 298,
          "deaths": 5,
          "recovered": 0,
          "id": "KE-41"
        },
        {
          "confirmed": 106,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-40"
        },
        {
          "confirmed": 698,
          "deaths": 6,
          "recovered": 0,
          "id": "KE-39"
        },
        {
          "confirmed": 191,
          "deaths": 5,
          "recovered": 0,
          "id": "KE-38"
        },
        {
          "confirmed": 81,
          "deaths": 2,
          "recovered": 0,
          "id": "KE-37"
        },
        {
          "confirmed": 443,
          "deaths": 6,
          "recovered": 0,
          "id": "KE-36"
        },
        {
          "confirmed": 20,
          "deaths": 158,
          "recovered": 0,
          "id": "KE-35"
        },
        {
          "confirmed": 245,
          "deaths": 4,
          "recovered": 0,
          "id": "KE-34"
        },
        {
          "confirmed": 83,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-33"
        },
        {
          "confirmed": 2844,
          "deaths": 27,
          "recovered": 0,
          "id": "KE-32"
        },
        {
          "confirmed": 101,
          "deaths": 1,
          "recovered": 0,
          "id": "KE-31"
        },
        {
          "confirmed": 51,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-30"
        },
        {
          "confirmed": 30,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-29"
        },
        {
          "confirmed": 353,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-28"
        },
        {
          "confirmed": 34,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-27"
        },
        {
          "confirmed": 249,
          "deaths": 1,
          "recovered": 0,
          "id": "KE-26"
        },
        {
          "confirmed": 187,
          "deaths": 4,
          "recovered": 0,
          "id": "KE-25"
        },
        {
          "confirmed": 234,
          "deaths": 1,
          "recovered": 0,
          "id": "KE-24"
        },
        {
          "confirmed": 1329,
          "deaths": 15,
          "recovered": 0,
          "id": "KE-23"
        },
        {
          "confirmed": 107,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-22"
        },
        {
          "confirmed": 290,
          "deaths": 3,
          "recovered": 0,
          "id": "KE-21"
        },
        {
          "confirmed": 777,
          "deaths": 9,
          "recovered": 0,
          "id": "KE-20"
        },
        {
          "confirmed": 1172,
          "deaths": 35,
          "recovered": 0,
          "id": "KE-19"
        },
        {
          "confirmed": 123,
          "deaths": 4,
          "recovered": 0,
          "id": "KE-18"
        },
        {
          "confirmed": 84,
          "deaths": 2,
          "recovered": 0,
          "id": "KE-17"
        },
        {
          "confirmed": 270,
          "deaths": 7,
          "recovered": 0,
          "id": "KE-16"
        },
        {
          "confirmed": 1285,
          "deaths": 12,
          "recovered": 0,
          "id": "KE-15"
        },
        {
          "confirmed": 68,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-14"
        },
        {
          "confirmed": 105,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-13"
        },
        {
          "confirmed": 56,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-12"
        },
        {
          "confirmed": 772,
          "deaths": 25,
          "recovered": 0,
          "id": "KE-11"
        },
        {
          "confirmed": 1227,
          "deaths": 18,
          "recovered": 0,
          "id": "KE-10"
        },
        {
          "confirmed": 68,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-9"
        },
        {
          "confirmed": 120,
          "deaths": 2,
          "recovered": 0,
          "id": "KE-8"
        },
        {
          "confirmed": 415,
          "deaths": 10,
          "recovered": 0,
          "id": "KE-7"
        },
        {
          "confirmed": 704,
          "deaths": 7,
          "recovered": 0,
          "id": "KE-6"
        },
        {
          "confirmed": 2108,
          "deaths": 39,
          "recovered": 0,
          "id": "KE-5"
        },
        {
          "confirmed": 235,
          "deaths": 2,
          "recovered": 0,
          "id": "KE-4"
        },
        {
          "confirmed": 192,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-3"
        },
        {
          "confirmed": 196,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-2"
        },
        {
          "confirmed": 30,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-1"
        }
      ]
    },
    {
      "date": "2020-03-24",
      "list": [
        
        
        {
          "confirmed": 95,
          "deaths": 7,
          "recovered": 0,
          "id": "KE-47"
        },
        {
          "confirmed": 293,
          "deaths": 9,
          "recovered": 0,
          "id": "KE-46"
        },
        {
          "confirmed": 298,
          "deaths": 1,
          "recovered": 0,
          "id": "KE-45"
        },
        {
          "confirmed": 955,
          "deaths": 12,
          "recovered": 0,
          "id": "KE-44"
        },
        {
          "confirmed": 772,
          "deaths": 2,
          "recovered": 0,
          "id": "KE-43"
        },
        {
          "confirmed": 30,
          "deaths": 1,
          "recovered": 0,
          "id": "KE-42"
        },
        {
          "confirmed": 342,
          "deaths": 5,
          "recovered": 0,
          "id": "KE-41"
        },
        {
          "confirmed": 124,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-40"
        },
        {
          "confirmed": 946,
          "deaths": 8,
          "recovered": 0,
          "id": "KE-39"
        },
        {
          "confirmed": 210,
          "deaths": 8,
          "recovered": 0,
          "id": "KE-38"
        },
        {
          "confirmed": 106,
          "deaths": 3,
          "recovered": 0,
          "id": "KE-37"
        },
        {
          "confirmed": 567,
          "deaths": 8,
          "recovered": 0,
          "id": "KE-36"
        },
        {
          "confirmed": 25,
          "deaths": 210,
          "recovered": 0,
          "id": "KE-35"
        },
        {
          "confirmed": 278,
          "deaths": 4,
          "recovered": 0,
          "id": "KE-34"
        },
        {
          "confirmed": 100,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-33"
        },
        {
          "confirmed": 3675,
          "deaths": 44,
          "recovered": 0,
          "id": "KE-32"
        },
        {
          "confirmed": 101,
          "deaths": 1,
          "recovered": 0,
          "id": "KE-31"
        },
        {
          "confirmed": 66,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-30"
        },
        {
          "confirmed": 36,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-29"
        },
        {
          "confirmed": 495,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-28"
        },
        {
          "confirmed": 51,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-27"
        },
        {
          "confirmed": 320,
          "deaths": 1,
          "recovered": 0,
          "id": "KE-26"
        },
        {
          "confirmed": 257,
          "deaths": 7,
          "recovered": 0,
          "id": "KE-25"
        },
        {
          "confirmed": 261,
          "deaths": 1,
          "recovered": 0,
          "id": "KE-24"
        },
        {
          "confirmed": 1793,
          "deaths": 24,
          "recovered": 0,
          "id": "KE-23"
        },
        {
          "confirmed": 118,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-22"
        },
        {
          "confirmed": 349,
          "deaths": 4,
          "recovered": 0,
          "id": "KE-21"
        },
        {
          "confirmed": 1159,
          "deaths": 11,
          "recovered": 0,
          "id": "KE-20"
        },
        {
          "confirmed": 1388,
          "deaths": 46,
          "recovered": 0,
          "id": "KE-19"
        },
        {
          "confirmed": 162,
          "deaths": 4,
          "recovered": 0,
          "id": "KE-18"
        },
        {
          "confirmed": 100,
          "deaths": 2,
          "recovered": 0,
          "id": "KE-17"
        },
        {
          "confirmed": 368,
          "deaths": 12,
          "recovered": 0,
          "id": "KE-16"
        },
        {
          "confirmed": 1537,
          "deaths": 16,
          "recovered": 0,
          "id": "KE-15"
        },
        {
          "confirmed": 81,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-14"
        },
        {
          "confirmed": 124,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-13"
        },
        {
          "confirmed": 90,
          "deaths": 1,
          "recovered": 0,
          "id": "KE-12"
        },
        {
          "confirmed": 1026,
          "deaths": 32,
          "recovered": 0,
          "id": "KE-11"
        },
        {
          "confirmed": 1412,
          "deaths": 18,
          "recovered": 0,
          "id": "KE-10"
        },
        {
          "confirmed": 104,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-9"
        },
        {
          "confirmed": 141,
          "deaths": 2,
          "recovered": 0,
          "id": "KE-8"
        },
        {
          "confirmed": 618,
          "deaths": 12,
          "recovered": 0,
          "id": "KE-7"
        },
        {
          "confirmed": 723,
          "deaths": 8,
          "recovered": 0,
          "id": "KE-6"
        },
        {
          "confirmed": 2538,
          "deaths": 50,
          "recovered": 0,
          "id": "KE-5"
        },
        {
          "confirmed": 326,
          "deaths": 5,
          "recovered": 0,
          "id": "KE-4"
        },
        {
          "confirmed": 219,
          "deaths": 2,
          "recovered": 0,
          "id": "KE-3"
        },
        {
          "confirmed": 242,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-2"
        },
        {
          "confirmed": 34,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-1"
        }
      ]
    },
    {
      "date": "2020-03-25",
      "list": [
        
       
        {
          "confirmed": 125,
          "deaths": 8,
          "recovered": 0,
          "id": "KE-47"
        },
        {
          "confirmed": 396,
          "deaths": 9,
          "recovered": 0,
          "id": "KE-46"
        },
        {
          "confirmed": 340,
          "deaths": 1,
          "recovered": 0,
          "id": "KE-45"
        },
        {
          "confirmed": 1229,
          "deaths": 15,
          "recovered": 0,
          "id": "KE-44"
        },
        {
          "confirmed": 916,
          "deaths": 3,
          "recovered": 0,
          "id": "KE-43"
        },
        {
          "confirmed": 41,
          "deaths": 1,
          "recovered": 0,
          "id": "KE-42"
        },
        {
          "confirmed": 424,
          "deaths": 7,
          "recovered": 0,
          "id": "KE-41"
        },
        {
          "confirmed": 132,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-40"
        },
        {
          "confirmed": 1260,
          "deaths": 15,
          "recovered": 0,
          "id": "KE-39"
        },
        {
          "confirmed": 266,
          "deaths": 10,
          "recovered": 0,
          "id": "KE-38"
        },
        {
          "confirmed": 164,
          "deaths": 5,
          "recovered": 0,
          "id": "KE-37"
        },
        {
          "confirmed": 704,
          "deaths": 11,
          "recovered": 0,
          "id": "KE-36"
        },
        {
          "confirmed": 30,
          "deaths": 285,
          "recovered": 0,
          "id": "KE-35"
        },
        {
          "confirmed": 323,
          "deaths": 6,
          "recovered": 0,
          "id": "KE-34"
        },
        {
          "confirmed": 113,
          "deaths": 1,
          "recovered": 0,
          "id": "KE-33"
        },
        {
          "confirmed": 4402,
          "deaths": 62,
          "recovered": 0,
          "id": "KE-32"
        },
        {
          "confirmed": 108,
          "deaths": 1,
          "recovered": 0,
          "id": "KE-31"
        },
        {
          "confirmed": 71,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-30"
        },
        {
          "confirmed": 45,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-29"
        },
        {
          "confirmed": 590,
          "deaths": 2,
          "recovered": 0,
          "id": "KE-28"
        },
        {
          "confirmed": 65,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-27"
        },
        {
          "confirmed": 377,
          "deaths": 3,
          "recovered": 0,
          "id": "KE-26"
        },
        {
          "confirmed": 354,
          "deaths": 8,
          "recovered": 0,
          "id": "KE-25"
        },
        {
          "confirmed": 286,
          "deaths": 1,
          "recovered": 0,
          "id": "KE-24"
        },
        {
          "confirmed": 2296,
          "deaths": 43,
          "recovered": 0,
          "id": "KE-23"
        },
        {
          "confirmed": 142,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-22"
        },
        {
          "confirmed": 425,
          "deaths": 4,
          "recovered": 0,
          "id": "KE-21"
        },
        {
          "confirmed": 1838,
          "deaths": 15,
          "recovered": 0,
          "id": "KE-20"
        },
        {
          "confirmed": 1795,
          "deaths": 65,
          "recovered": 0,
          "id": "KE-19"
        },
        {
          "confirmed": 197,
          "deaths": 5,
          "recovered": 0,
          "id": "KE-18"
        },
        {
          "confirmed": 134,
          "deaths": 3,
          "recovered": 0,
          "id": "KE-17"
        },
        {
          "confirmed": 477,
          "deaths": 14,
          "recovered": 0,
          "id": "KE-16"
        },
        {
          "confirmed": 1865,
          "deaths": 19,
          "recovered": 0,
          "id": "KE-15"
        },
        {
          "confirmed": 91,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-14"
        },
        {
          "confirmed": 146,
          "deaths": 1,
          "recovered": 0,
          "id": "KE-13"
        },
        {
          "confirmed": 91,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-12"
        },
        {
          "confirmed": 1247,
          "deaths": 40,
          "recovered": 0,
          "id": "KE-11"
        },
        {
          "confirmed": 1682,
          "deaths": 23,
          "recovered": 0,
          "id": "KE-10"
        },
        {
          "confirmed": 119,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-9"
        },
        {
          "confirmed": 187,
          "deaths": 2,
          "recovered": 0,
          "id": "KE-8"
        },
        {
          "confirmed": 875,
          "deaths": 19,
          "recovered": 0,
          "id": "KE-7"
        },
        {
          "confirmed": 1021,
          "deaths": 16,
          "recovered": 0,
          "id": "KE-6"
        },
        {
          "confirmed": 2998,
          "deaths": 65,
          "recovered": 0,
          "id": "KE-5"
        },
        {
          "confirmed": 401,
          "deaths": 6,
          "recovered": 0,
          "id": "KE-4"
        },
        {
          "confirmed": 280,
          "deaths": 2,
          "recovered": 0,
          "id": "KE-3"
        },
        {
          "confirmed": 381,
          "deaths": 1,
          "recovered": 0,
          "id": "KE-2"
        },
        {
          "confirmed": 41,
          "deaths": 1,
          "recovered": 0,
          "id": "KE-1"
        }
      ]
    },
    {
      "date": "2020-03-26",
      "list": [
        
       
        {
          "confirmed": 158,
          "deaths": 9,
          "recovered": 0,
          "id": "KE-47"
        },
        {
          "confirmed": 466,
          "deaths": 10,
          "recovered": 0,
          "id": "KE-46"
        },
        {
          "confirmed": 396,
          "deaths": 1,
          "recovered": 0,
          "id": "KE-45"
        },
        {
          "confirmed": 1563,
          "deaths": 21,
          "recovered": 0,
          "id": "KE-44"
        },
        {
          "confirmed": 1097,
          "deaths": 3,
          "recovered": 0,
          "id": "KE-43"
        },
        {
          "confirmed": 46,
          "deaths": 1,
          "recovered": 0,
          "id": "KE-42"
        },
        {
          "confirmed": 424,
          "deaths": 9,
          "recovered": 0,
          "id": "KE-41"
        },
        {
          "confirmed": 165,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-40"
        },
        {
          "confirmed": 1795,
          "deaths": 18,
          "recovered": 0,
          "id": "KE-39"
        },
        {
          "confirmed": 316,
          "deaths": 11,
          "recovered": 0,
          "id": "KE-38"
        },
        {
          "confirmed": 248,
          "deaths": 7,
          "recovered": 0,
          "id": "KE-37"
        },
        {
          "confirmed": 86,
          "deaths": 15,
          "recovered": 0,
          "id": "KE-36"
        },
        {
          "confirmed": 37,
          "deaths": 385,
          "recovered": 0,
          "id": "KE-35"
        },
        {
          "confirmed": 420,
          "deaths": 10,
          "recovered": 0,
          "id": "KE-34"
        },
        {
          "confirmed": 113,
          "deaths": 1,
          "recovered": 0,
          "id": "KE-33"
        },
        {
          "confirmed": 6876,
          "deaths": 81,
          "recovered": 0,
          "id": "KE-32"
        },
        {
          "confirmed": 137,
          "deaths": 1,
          "recovered": 0,
          "id": "KE-31"
        },
        {
          "confirmed": 74,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-30"
        },
        {
          "confirmed": 51,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-29"
        },
        {
          "confirmed": 738,
          "deaths": 3,
          "recovered": 0,
          "id": "KE-28"
        },
        {
          "confirmed": 90,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-27"
        },
        {
          "confirmed": 485,
          "deaths": 6,
          "recovered": 0,
          "id": "KE-26"
        },
        {
          "confirmed": 520,
          "deaths": 9,
          "recovered": 0,
          "id": "KE-25"
        },
        {
          "confirmed": 344,
          "deaths": 2,
          "recovered": 0,
          "id": "KE-24"
        },
        {
          "confirmed": 2845,
          "deaths": 61,
          "recovered": 0,
          "id": "KE-23"
        },
        {
          "confirmed": 155,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-22"
        },
        {
          "confirmed": 583,
          "deaths": 4,
          "recovered": 0,
          "id": "KE-21"
        },
        {
          "confirmed": 2417,
          "deaths": 25,
          "recovered": 0,
          "id": "KE-20"
        },
        {
          "confirmed": 2304,
          "deaths": 83,
          "recovered": 0,
          "id": "KE-19"
        },
        {
          "confirmed": 247,
          "deaths": 5,
          "recovered": 0,
          "id": "KE-18"
        },
        {
          "confirmed": 172,
          "deaths": 3,
          "recovered": 0,
          "id": "KE-17"
        },
        {
          "confirmed": 645,
          "deaths": 17,
          "recovered": 0,
          "id": "KE-16"
        },
        {
          "confirmed": 2538,
          "deaths": 26,
          "recovered": 0,
          "id": "KE-15"
        },
        {
          "confirmed": 146,
          "deaths": 3,
          "recovered": 0,
          "id": "KE-14"
        },
        {
          "confirmed": 179,
          "deaths": 1,
          "recovered": 0,
          "id": "KE-13"
        },
        {
          "confirmed": 95,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-12"
        },
        {
          "confirmed": 1525,
          "deaths": 48,
          "recovered": 0,
          "id": "KE-11"
        },
        {
          "confirmed": 2357,
          "deaths": 29,
          "recovered": 0,
          "id": "KE-10"
        },
        {
          "confirmed": 130,
          "deaths": 1,
          "recovered": 0,
          "id": "KE-9"
        },
        {
          "confirmed": 231,
          "deaths": 3,
          "recovered": 0,
          "id": "KE-8"
        },
        {
          "confirmed": 1012,
          "deaths": 21,
          "recovered": 0,
          "id": "KE-7"
        },
        {
          "confirmed": 1430,
          "deaths": 19,
          "recovered": 0,
          "id": "KE-6"
        },
        {
          "confirmed": 3899,
          "deaths": 81,
          "recovered": 0,
          "id": "KE-5"
        },
        {
          "confirmed": 508,
          "deaths": 8,
          "recovered": 0,
          "id": "KE-4"
        },
        {
          "confirmed": 335,
          "deaths": 2,
          "recovered": 0,
          "id": "KE-3"
        },
        {
          "confirmed": 517,
          "deaths": 1,
          "recovered": 0,
          "id": "KE-2"
        },
        {
          "confirmed": 56,
          "deaths": 1,
          "recovered": 0,
          "id": "KE-1"
        }
      ]
    },
    {
      "date": "2020-03-27",
      "list": [
        
        
        {
          "confirmed": 184,
          "deaths": 10,
          "recovered": 0,
          "id": "KE-47"
        },
        {
          "confirmed": 607,
          "deaths": 10,
          "recovered": 0,
          "id": "KE-46"
        },
        {
          "confirmed": 472,
          "deaths": 1,
          "recovered": 0,
          "id": "KE-45"
        },
        {
          "confirmed": 1937,
          "deaths": 26,
          "recovered": 0,
          "id": "KE-44"
        },
        {
          "confirmed": 1318,
          "deaths": 6,
          "recovered": 0,
          "id": "KE-43"
        },
        {
          "confirmed": 58,
          "deaths": 1,
          "recovered": 0,
          "id": "KE-42"
        },
        {
          "confirmed": 542,
          "deaths": 13,
          "recovered": 0,
          "id": "KE-41"
        },
        {
          "confirmed": 203,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-40"
        },
        {
          "confirmed": 2345,
          "deaths": 22,
          "recovered": 0,
          "id": "KE-39"
        },
        {
          "confirmed": 416,
          "deaths": 12,
          "recovered": 0,
          "id": "KE-38"
        },
        {
          "confirmed": 322,
          "deaths": 8,
          "recovered": 0,
          "id": "KE-37"
        },
        {
          "confirmed": 1137,
          "deaths": 19,
          "recovered": 0,
          "id": "KE-36"
        },
        {
          "confirmed": 44,
          "deaths": 527,
          "recovered": 0,
          "id": "KE-35"
        },
        {
          "confirmed": 536,
          "deaths": 10,
          "recovered": 0,
          "id": "KE-34"
        },
        {
          "confirmed": 136,
          "deaths": 1,
          "recovered": 0,
          "id": "KE-33"
        },
        {
          "confirmed": 8825,
          "deaths": 108,
          "recovered": 0,
          "id": "KE-32"
        },
        {
          "confirmed": 158,
          "deaths": 1,
          "recovered": 0,
          "id": "KE-31"
        },
        {
          "confirmed": 82,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-30"
        },
        {
          "confirmed": 68,
          "deaths": 1,
          "recovered": 0,
          "id": "KE-29"
        },
        {
          "confirmed": 887,
          "deaths": 4,
          "recovered": 0,
          "id": "KE-28"
        },
        {
          "confirmed": 109,
          "deaths": 1,
          "recovered": 0,
          "id": "KE-27"
        },
        {
          "confirmed": 579,
          "deaths": 8,
          "recovered": 0,
          "id": "KE-26"
        },
        {
          "confirmed": 666,
          "deaths": 9,
          "recovered": 0,
          "id": "KE-25"
        },
        {
          "confirmed": 396,
          "deaths": 4,
          "recovered": 0,
          "id": "KE-24"
        },
        {
          "confirmed": 3634,
          "deaths": 92,
          "recovered": 0,
          "id": "KE-23"
        },
        {
          "confirmed": 168,
          "deaths": 1,
          "recovered": 0,
          "id": "KE-22"
        },
        {
          "confirmed": 775,
          "deaths": 5,
          "recovered": 0,
          "id": "KE-21"
        },
        {
          "confirmed": 3240,
          "deaths": 35,
          "recovered": 0,
          "id": "KE-20"
        },
        {
          "confirmed": 2744,
          "deaths": 119,
          "recovered": 0,
          "id": "KE-19"
        },
        {
          "confirmed": 301,
          "deaths": 7,
          "recovered": 0,
          "id": "KE-18"
        },
        {
          "confirmed": 206,
          "deaths": 4,
          "recovered": 0,
          "id": "KE-17"
        },
        {
          "confirmed": 979,
          "deaths": 25,
          "recovered": 0,
          "id": "KE-16"
        },
        {
          "confirmed": 3024,
          "deaths": 34,
          "recovered": 0,
          "id": "KE-15"
        },
        {
          "confirmed": 205,
          "deaths": 3,
          "recovered": 0,
          "id": "KE-14"
        },
        {
          "confirmed": 235,
          "deaths": 3,
          "recovered": 0,
          "id": "KE-13"
        },
        {
          "confirmed": 106,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-12"
        },
        {
          "confirmed": 2000,
          "deaths": 64,
          "recovered": 0,
          "id": "KE-11"
        },
        {
          "confirmed": 2900,
          "deaths": 35,
          "recovered": 0,
          "id": "KE-10"
        },
        {
          "confirmed": 163,
          "deaths": 2,
          "recovered": 0,
          "id": "KE-9"
        },
        {
          "confirmed": 271,
          "deaths": 3,
          "recovered": 0,
          "id": "KE-8"
        },
        {
          "confirmed": 1291,
          "deaths": 27,
          "recovered": 0,
          "id": "KE-7"
        },
        {
          "confirmed": 1433,
          "deaths": 27,
          "recovered": 0,
          "id": "KE-6"
        },
        {
          "confirmed": 4657,
          "deaths": 94,
          "recovered": 0,
          "id": "KE-5"
        },
        {
          "confirmed": 665,
          "deaths": 13,
          "recovered": 0,
          "id": "KE-4"
        },
        {
          "confirmed": 381,
          "deaths": 3,
          "recovered": 0,
          "id": "KE-3"
        },
        {
          "confirmed": 587,
          "deaths": 4,
          "recovered": 0,
          "id": "KE-2"
        },
        {
          "confirmed": 58,
          "deaths": 1,
          "recovered": 0,
          "id": "KE-1"
        }
      ]
    },
    {
      "date": "2020-03-28",
      "list": [
       
        
        {
          "confirmed": 211,
          "deaths": 12,
          "recovered": 0,
          "id": "KE-47"
        },
        {
          "confirmed": 740,
          "deaths": 13,
          "recovered": 0,
          "id": "KE-46"
        },
        {
          "confirmed": 602,
          "deaths": 1,
          "recovered": 0,
          "id": "KE-45"
        },
        {
          "confirmed": 2455,
          "deaths": 30,
          "recovered": 0,
          "id": "KE-44"
        },
        {
          "confirmed": 1511,
          "deaths": 7,
          "recovered": 0,
          "id": "KE-43"
        },
        {
          "confirmed": 68,
          "deaths": 1,
          "recovered": 0,
          "id": "KE-42"
        },
        {
          "confirmed": 660,
          "deaths": 15,
          "recovered": 0,
          "id": "KE-41"
        },
        {
          "confirmed": 239,
          "deaths": 2,
          "recovered": 0,
          "id": "KE-40"
        },
        {
          "confirmed": 2845,
          "deaths": 34,
          "recovered": 0,
          "id": "KE-39"
        },
        {
          "confirmed": 479,
          "deaths": 13,
          "recovered": 0,
          "id": "KE-38"
        },
        {
          "confirmed": 377,
          "deaths": 15,
          "recovered": 0,
          "id": "KE-37"
        },
        {
          "confirmed": 1406,
          "deaths": 25,
          "recovered": 0,
          "id": "KE-36"
        },
        {
          "confirmed": 5,
          "deaths": 728,
          "recovered": 0,
          "id": "KE-35"
        },
        {
          "confirmed": 626,
          "deaths": 10,
          "recovered": 0,
          "id": "KE-34"
        },
        {
          "confirmed": 208,
          "deaths": 1,
          "recovered": 0,
          "id": "KE-33"
        },
        {
          "confirmed": 11124,
          "deaths": 140,
          "recovered": 0,
          "id": "KE-32"
        },
        {
          "confirmed": 187,
          "deaths": 2,
          "recovered": 0,
          "id": "KE-31"
        },
        {
          "confirmed": 96,
          "deaths": 2,
          "recovered": 0,
          "id": "KE-30"
        },
        {
          "confirmed": 94,
          "deaths": 1,
          "recovered": 0,
          "id": "KE-29"
        },
        {
          "confirmed": 1020,
          "deaths": 5,
          "recovered": 0,
          "id": "KE-28"
        },
        {
          "confirmed": 129,
          "deaths": 1,
          "recovered": 0,
          "id": "KE-27"
        },
        {
          "confirmed": 663,
          "deaths": 13,
          "recovered": 0,
          "id": "KE-26"
        },
        {
          "confirmed": 836,
          "deaths": 10,
          "recovered": 0,
          "id": "KE-25"
        },
        {
          "confirmed": 441,
          "deaths": 5,
          "recovered": 0,
          "id": "KE-24"
        },
        {
          "confirmed": 4650,
          "deaths": 111,
          "recovered": 0,
          "id": "KE-23"
        },
        {
          "confirmed": 211,
          "deaths": 1,
          "recovered": 0,
          "id": "KE-22"
        },
        {
          "confirmed": 995,
          "deaths": 5,
          "recovered": 0,
          "id": "KE-21"
        },
        {
          "confirmed": 4257,
          "deaths": 44,
          "recovered": 0,
          "id": "KE-20"
        },
        {
          "confirmed": 3315,
          "deaths": 137,
          "recovered": 0,
          "id": "KE-19"
        },
        {
          "confirmed": 380,
          "deaths": 9,
          "recovered": 0,
          "id": "KE-18"
        },
        {
          "confirmed": 266,
          "deaths": 4,
          "recovered": 0,
          "id": "KE-17"
        },
        {
          "confirmed": 1233,
          "deaths": 31,
          "recovered": 0,
          "id": "KE-16"
        },
        {
          "confirmed": 3491,
          "deaths": 47,
          "recovered": 0,
          "id": "KE-15"
        },
        {
          "confirmed": 234,
          "deaths": 4,
          "recovered": 0,
          "id": "KE-14"
        },
        {
          "confirmed": 298,
          "deaths": 3,
          "recovered": 0,
          "id": "KE-13"
        },
        {
          "confirmed": 149,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-12"
        },
        {
          "confirmed": 2366,
          "deaths": 69,
          "recovered": 0,
          "id": "KE-11"
        },
        {
          "confirmed": 3763,
          "deaths": 54,
          "recovered": 0,
          "id": "KE-10"
        },
        {
          "confirmed": 214,
          "deaths": 5,
          "recovered": 0,
          "id": "KE-9"
        },
        {
          "confirmed": 304,
          "deaths": 4,
          "recovered": 0,
          "id": "KE-8"
        },
        {
          "confirmed": 1524,
          "deaths": 33,
          "recovered": 0,
          "id": "KE-7"
        },
        {
          "confirmed": 1740,
          "deaths": 31,
          "recovered": 0,
          "id": "KE-6"
        },
        {
          "confirmed": 5095,
          "deaths": 110,
          "recovered": 0,
          "id": "KE-5"
        },
        {
          "confirmed": 773,
          "deaths": 15,
          "recovered": 0,
          "id": "KE-4"
        },
        {
          "confirmed": 409,
          "deaths": 5,
          "recovered": 0,
          "id": "KE-3"
        },
        {
          "confirmed": 694,
          "deaths": 4,
          "recovered": 0,
          "id": "KE-2"
        },
        {
          "confirmed": 85,
          "deaths": 2,
          "recovered": 0,
          "id": "KE-1"
        }
      ]
    },
    {
      "date": "2020-03-29",
      "list": [
       
        
        {
          "confirmed": 235,
          "deaths": 12,
          "recovered": 0,
          "id": "KE-47"
        },
        {
          "confirmed": 890,
          "deaths": 20,
          "recovered": 0,
          "id": "KE-46"
        },
        {
          "confirmed": 720,
          "deaths": 2,
          "recovered": 0,
          "id": "KE-45"
        },
        {
          "confirmed": 2792,
          "deaths": 37,
          "recovered": 0,
          "id": "KE-44"
        },
        {
          "confirmed": 1720,
          "deaths": 8,
          "recovered": 0,
          "id": "KE-43"
        },
        {
          "confirmed": 90,
          "deaths": 1,
          "recovered": 0,
          "id": "KE-42"
        },
        {
          "confirmed": 774,
          "deaths": 16,
          "recovered": 0,
          "id": "KE-41"
        },
        {
          "confirmed": 294,
          "deaths": 3,
          "recovered": 0,
          "id": "KE-40"
        },
        {
          "confirmed": 3432,
          "deaths": 41,
          "recovered": 0,
          "id": "KE-39"
        },
        {
          "confirmed": 548,
          "deaths": 13,
          "recovered": 0,
          "id": "KE-38"
        },
        {
          "confirmed": 429,
          "deaths": 16,
          "recovered": 0,
          "id": "KE-37"
        },
        {
          "confirmed": 1653,
          "deaths": 29,
          "recovered": 0,
          "id": "KE-36"
        },
        {
          "confirmed": 59,
          "deaths": 965,
          "recovered": 0,
          "id": "KE-35"
        },
        {
          "confirmed": 920,
          "deaths": 15,
          "recovered": 0,
          "id": "KE-34"
        },
        {
          "confirmed": 237,
          "deaths": 2,
          "recovered": 0,
          "id": "KE-33"
        },
        {
          "confirmed": 13386,
          "deaths": 161,
          "recovered": 0,
          "id": "KE-32"
        },
        {
          "confirmed": 214,
          "deaths": 2,
          "recovered": 0,
          "id": "KE-31"
        },
        {
          "confirmed": 108,
          "deaths": 2,
          "recovered": 0,
          "id": "KE-30"
        },
        {
          "confirmed": 98,
          "deaths": 1,
          "recovered": 0,
          "id": "KE-29"
        },
        {
          "confirmed": 1191,
          "deaths": 7,
          "recovered": 0,
          "id": "KE-28"
        },
        {
          "confirmed": 154,
          "deaths": 1,
          "recovered": 0,
          "id": "KE-27"
        },
        {
          "confirmed": 759,
          "deaths": 14,
          "recovered": 0,
          "id": "KE-26"
        },
        {
          "confirmed": 915,
          "deaths": 13,
          "recovered": 0,
          "id": "KE-25"
        },
        {
          "confirmed": 503,
          "deaths": 9,
          "recovered": 0,
          "id": "KE-24"
        },
        {
          "confirmed": 5488,
          "deaths": 132,
          "recovered": 0,
          "id": "KE-23"
        },
        {
          "confirmed": 253,
          "deaths": 3,
          "recovered": 0,
          "id": "KE-22"
        },
        {
          "confirmed": 1239,
          "deaths": 10,
          "recovered": 0,
          "id": "KE-21"
        },
        {
          "confirmed": 4955,
          "deaths": 48,
          "recovered": 0,
          "id": "KE-20"
        },
        {
          "confirmed": 3540,
          "deaths": 151,
          "recovered": 0,
          "id": "KE-19"
        },
        {
          "confirmed": 438,
          "deaths": 9,
          "recovered": 0,
          "id": "KE-18"
        },
        {
          "confirmed": 330,
          "deaths": 7,
          "recovered": 0,
          "id": "KE-17"
        },
        {
          "confirmed": 1513,
          "deaths": 32,
          "recovered": 0,
          "id": "KE-16"
        },
        {
          "confirmed": 4596,
          "deaths": 66,
          "recovered": 0,
          "id": "KE-15"
        },
        {
          "confirmed": 281,
          "deaths": 5,
          "recovered": 0,
          "id": "KE-14"
        },
        {
          "confirmed": 336,
          "deaths": 4,
          "recovered": 0,
          "id": "KE-13"
        },
        {
          "confirmed": 149,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-12"
        },
        {
          "confirmed": 2651,
          "deaths": 80,
          "recovered": 0,
          "id": "KE-11"
        },
        {
          "confirmed": 4246,
          "deaths": 56,
          "recovered": 0,
          "id": "KE-10"
        },
        {
          "confirmed": 232,
          "deaths": 6,
          "recovered": 0,
          "id": "KE-9"
        },
        {
          "confirmed": 342,
          "deaths": 5,
          "recovered": 0,
          "id": "KE-8"
        },
        {
          "confirmed": 1993,
          "deaths": 34,
          "recovered": 0,
          "id": "KE-7"
        },
        {
          "confirmed": 2307,
          "deaths": 47,
          "recovered": 0,
          "id": "KE-6"
        },
        {
          "confirmed": 5852,
          "deaths": 124,
          "recovered": 0,
          "id": "KE-5"
        },
        {
          "confirmed": 919,
          "deaths": 17,
          "recovered": 0,
          "id": "KE-4"
        },
        {
          "confirmed": 426,
          "deaths": 6,
          "recovered": 0,
          "id": "KE-3"
        },
        {
          "confirmed": 825,
          "deaths": 10,
          "recovered": 0,
          "id": "KE-2"
        },
        {
          "confirmed": 102,
          "deaths": 2,
          "recovered": 0,
          "id": "KE-1"
        }
      ]
    },
    {
      "date": "2020-03-30",
      "list": [
        
        
        {
          "confirmed": 256,
          "deaths": 12,
          "recovered": 0,
          "id": "KE-47"
        },
        {
          "confirmed": 1020,
          "deaths": 15,
          "recovered": 0,
          "id": "KE-46"
        },
        {
          "confirmed": 798,
          "deaths": 4,
          "recovered": 0,
          "id": "KE-45"
        },
        {
          "confirmed": 3147,
          "deaths": 45,
          "recovered": 0,
          "id": "KE-44"
        },
        {
          "confirmed": 1917,
          "deaths": 14,
          "recovered": 0,
          "id": "KE-43"
        },
        {
          "confirmed": 101,
          "deaths": 1,
          "recovered": 0,
          "id": "KE-42"
        },
        {
          "confirmed": 925,
          "deaths": 18,
          "recovered": 0,
          "id": "KE-41"
        },
        {
          "confirmed": 408,
          "deaths": 4,
          "recovered": 0,
          "id": "KE-40"
        },
        {
          "confirmed": 4155,
          "deaths": 50,
          "recovered": 0,
          "id": "KE-39"
        },
        {
          "confirmed": 606,
          "deaths": 16,
          "recovered": 0,
          "id": "KE-38"
        },
        {
          "confirmed": 481,
          "deaths": 16,
          "recovered": 0,
          "id": "KE-37"
        },
        {
          "confirmed": 1933,
          "deaths": 40,
          "recovered": 0,
          "id": "KE-36"
        },
        {
          "confirmed": 66,
          "deaths": 1218,
          "recovered": 0,
          "id": "KE-35"
        },
        {
          "confirmed": 1012,
          "deaths": 15,
          "recovered": 0,
          "id": "KE-34"
        },
        {
          "confirmed": 237,
          "deaths": 2,
          "recovered": 0,
          "id": "KE-33"
        },
        {
          "confirmed": 16636,
          "deaths": 198,
          "recovered": 0,
          "id": "KE-32"
        },
        {
          "confirmed": 314,
          "deaths": 3,
          "recovered": 0,
          "id": "KE-31"
        },
        {
          "confirmed": 145,
          "deaths": 2,
          "recovered": 0,
          "id": "KE-30"
        },
        {
          "confirmed": 109,
          "deaths": 2,
          "recovered": 0,
          "id": "KE-29"
        },
        {
          "confirmed": 1313,
          "deaths": 7,
          "recovered": 0,
          "id": "KE-28"
        },
        {
          "confirmed": 171,
          "deaths": 5,
          "recovered": 0,
          "id": "KE-27"
        },
        {
          "confirmed": 847,
          "deaths": 16,
          "recovered": 0,
          "id": "KE-26"
        },
        {
          "confirmed": 1051,
          "deaths": 13,
          "recovered": 0,
          "id": "KE-25"
        },
        {
          "confirmed": 576,
          "deaths": 10,
          "recovered": 0,
          "id": "KE-24"
        },
        {
          "confirmed": 6498,
          "deaths": 184,
          "recovered": 0,
          "id": "KE-23"
        },
        {
          "confirmed": 275,
          "deaths": 3,
          "recovered": 0,
          "id": "KE-22"
        },
        {
          "confirmed": 1413,
          "deaths": 15,
          "recovered": 0,
          "id": "KE-21"
        },
        {
          "confirmed": 5752,
          "deaths": 56,
          "recovered": 0,
          "id": "KE-20"
        },
        {
          "confirmed": 4025,
          "deaths": 185,
          "recovered": 0,
          "id": "KE-19"
        },
        {
          "confirmed": 479,
          "deaths": 11,
          "recovered": 0,
          "id": "KE-18"
        },
        {
          "confirmed": 372,
          "deaths": 8,
          "recovered": 0,
          "id": "KE-17"
        },
        {
          "confirmed": 1786,
          "deaths": 35,
          "recovered": 0,
          "id": "KE-16"
        },
        {
          "confirmed": 5056,
          "deaths": 73,
          "recovered": 0,
          "id": "KE-15"
        },
        {
          "confirmed": 340,
          "deaths": 6,
          "recovered": 0,
          "id": "KE-14"
        },
        {
          "confirmed": 424,
          "deaths": 6,
          "recovered": 0,
          "id": "KE-13"
        },
        {
          "confirmed": 175,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-12"
        },
        {
          "confirmed": 2808,
          "deaths": 87,
          "recovered": 0,
          "id": "KE-11"
        },
        {
          "confirmed": 5473,
          "deaths": 63,
          "recovered": 0,
          "id": "KE-10"
        },
        {
          "confirmed": 264,
          "deaths": 6,
          "recovered": 0,
          "id": "KE-9"
        },
        {
          "confirmed": 401,
          "deaths": 9,
          "recovered": 0,
          "id": "KE-8"
        },
        {
          "confirmed": 2571,
          "deaths": 36,
          "recovered": 0,
          "id": "KE-7"
        },
        {
          "confirmed": 2311,
          "deaths": 47,
          "recovered": 0,
          "id": "KE-6"
        },
        {
          "confirmed": 7138,
          "deaths": 146,
          "recovered": 0,
          "id": "KE-5"
        },
        {
          "confirmed": 1157,
          "deaths": 20,
          "recovered": 0,
          "id": "KE-4"
        },
        {
          "confirmed": 473,
          "deaths": 7,
          "recovered": 0,
          "id": "KE-3"
        },
        {
          "confirmed": 899,
          "deaths": 10,
          "recovered": 0,
          "id": "KE-2"
        },
        {
          "confirmed": 114,
          "deaths": 3,
          "recovered": 0,
          "id": "KE-1"
        }
      ]
    },
    {
      "date": "2020-03-31",
      "list": [
        
        
        {
          "confirmed": 293,
          "deaths": 13,
          "recovered": 0,
          "id": "KE-47"
        },
        {
          "confirmed": 1249,
          "deaths": 27,
          "recovered": 0,
          "id": "KE-46"
        },
        {
          "confirmed": 888,
          "deaths": 5,
          "recovered": 0,
          "id": "KE-45"
        },
        {
          "confirmed": 3809,
          "deaths": 54,
          "recovered": 0,
          "id": "KE-44"
        },
        {
          "confirmed": 2391,
          "deaths": 23,
          "recovered": 0,
          "id": "KE-43"
        },
        {
          "confirmed": 108,
          "deaths": 1,
          "recovered": 0,
          "id": "KE-42"
        },
        {
          "confirmed": 1083,
          "deaths": 22,
          "recovered": 0,
          "id": "KE-41"
        },
        {
          "confirmed": 488,
          "deaths": 8,
          "recovered": 0,
          "id": "KE-40"
        },
        {
          "confirmed": 4963,
          "deaths": 63,
          "recovered": 0,
          "id": "KE-39"
        },
        {
          "confirmed": 690,
          "deaths": 18,
          "recovered": 0,
          "id": "KE-38"
        },
        {
          "confirmed": 568,
          "deaths": 23,
          "recovered": 0,
          "id": "KE-37"
        },
        {
          "confirmed": 2199,
          "deaths": 55,
          "recovered": 0,
          "id": "KE-36"
        },
        {
          "confirmed": 75,
          "deaths": 1550,
          "recovered": 0,
          "id": "KE-35"
        },
        {
          "confirmed": 1114,
          "deaths": 26,
          "recovered": 0,
          "id": "KE-34"
        },
        {
          "confirmed": 315,
          "deaths": 4,
          "recovered": 0,
          "id": "KE-33"
        },
        {
          "confirmed": 18696,
          "deaths": 267,
          "recovered": 0,
          "id": "KE-32"
        },
        {
          "confirmed": 357,
          "deaths": 3,
          "recovered": 0,
          "id": "KE-31"
        },
        {
          "confirmed": 172,
          "deaths": 3,
          "recovered": 0,
          "id": "KE-30"
        },
        {
          "confirmed": 122,
          "deaths": 3,
          "recovered": 0,
          "id": "KE-29"
        },
        {
          "confirmed": 1535,
          "deaths": 12,
          "recovered": 0,
          "id": "KE-28"
        },
        {
          "confirmed": 198,
          "deaths": 5,
          "recovered": 0,
          "id": "KE-27"
        },
        {
          "confirmed": 937,
          "deaths": 20,
          "recovered": 0,
          "id": "KE-26"
        },
        {
          "confirmed": 1357,
          "deaths": 15,
          "recovered": 0,
          "id": "KE-25"
        },
        {
          "confirmed": 629,
          "deaths": 12,
          "recovered": 0,
          "id": "KE-24"
        },
        {
          "confirmed": 7615,
          "deaths": 259,
          "recovered": 0,
          "id": "KE-23"
        },
        {
          "confirmed": 303,
          "deaths": 5,
          "recovered": 0,
          "id": "KE-22"
        },
        {
          "confirmed": 1660,
          "deaths": 18,
          "recovered": 0,
          "id": "KE-21"
        },
        {
          "confirmed": 6620,
          "deaths": 89,
          "recovered": 0,
          "id": "KE-20"
        },
        {
          "confirmed": 5237,
          "deaths": 239,
          "recovered": 0,
          "id": "KE-19"
        },
        {
          "confirmed": 628,
          "deaths": 11,
          "recovered": 0,
          "id": "KE-18"
        },
        {
          "confirmed": 434,
          "deaths": 9,
          "recovered": 0,
          "id": "KE-17"
        },
        {
          "confirmed": 2158,
          "deaths": 49,
          "recovered": 0,
          "id": "KE-16"
        },
        {
          "confirmed": 5994,
          "deaths": 99,
          "recovered": 0,
          "id": "KE-15"
        },
        {
          "confirmed": 515,
          "deaths": 8,
          "recovered": 0,
          "id": "KE-14"
        },
        {
          "confirmed": 497,
          "deaths": 7,
          "recovered": 0,
          "id": "KE-13"
        },
        {
          "confirmed": 204,
          "deaths": 0,
          "recovered": 0,
          "id": "KE-12"
        },
        {
          "confirmed": 3929,
          "deaths": 111,
          "recovered": 0,
          "id": "KE-11"
        },
        {
          "confirmed": 6741,
          "deaths": 85,
          "recovered": 0,
          "id": "KE-10"
        },
        {
          "confirmed": 319,
          "deaths": 10,
          "recovered": 0,
          "id": "KE-9"
        },
        {
          "confirmed": 495,
          "deaths": 9,
          "recovered": 0,
          "id": "KE-8"
        },
        {
          "confirmed": 3128,
          "deaths": 69,
          "recovered": 0,
          "id": "KE-7"
        },
        {
          "confirmed": 2966,
          "deaths": 69,
          "recovered": 0,
          "id": "KE-6"
        },
        {
          "confirmed": 8210,
          "deaths": 173,
          "recovered": 0,
          "id": "KE-5"
        },
        {
          "confirmed": 1289,
          "deaths": 24,
          "recovered": 0,
          "id": "KE-4"
        },
        {
          "confirmed": 523,
          "deaths": 8,
          "recovered": 0,
          "id": "KE-3"
        },
        {
          "confirmed": 987,
          "deaths": 23,
          "recovered": 0,
          "id": "KE-2"
        },
        {
          "confirmed": 119,
          "deaths": 3,
          "recovered": 0,
          "id": "KE-1"
        }
      ]
    },
    {
      "date": "2020-04-01",
      "list": [
        
       
        {
          "confirmed": 321,
          "deaths": 16,
          "recovered": 0,
          "id": "KE-47"
        },
        {
          "confirmed": 1483,
          "deaths": 34,
          "recovered": 0,
          "id": "KE-46"
        },
        {
          "confirmed": 888,
          "deaths": 5,
          "recovered": 0,
          "id": "KE-45"
        },
        {
          "confirmed": 4355,
          "deaths": 66,
          "recovered": 0,
          "id": "KE-44"
        },
        {
          "confirmed": 2933,
          "deaths": 24,
          "recovered": 0,
          "id": "KE-43"
        },
        {
          "confirmed": 129,
          "deaths": 2,
          "recovered": 0,
          "id": "KE-42"
        },
        {
          "confirmed": 1293,
          "deaths": 26,
          "recovered": 0,
          "id": "KE-41"
        },
        {
          "confirmed": 566,
          "deaths": 10,
          "recovered": 0,
          "id": "KE-40"
        },
        {
          "confirmed": 6009,
          "deaths": 74,
          "recovered": 0,
          "id": "KE-39"
        },
        {
          "confirmed": 736,
          "deaths": 19,
          "recovered": 0,
          "id": "KE-38"
        },
        {
          "confirmed": 721,
          "deaths": 30,
          "recovered": 0,
          "id": "KE-37"
        },
        {
          "confirmed": 2547,
          "deaths": 65,
          "recovered": 0,
          "id": "KE-36"
        },
        {
          "confirmed": 83,
          "deaths": 1941,
          "recovered": 0,
          "id": "KE-35"
        },
        {
          "confirmed": 1279,
          "deaths": 31,
          "recovered": 0,
          "id": "KE-34"
        },
        {
          "confirmed": 340,
          "deaths": 5,
          "recovered": 0,
          "id": "KE-33"
        },
        {
          "confirmed": 22255,
          "deaths": 355,
          "recovered": 0,
          "id": "KE-32"
        },
        {
          "confirmed": 367,
          "deaths": 3,
          "recovered": 0,
          "id": "KE-31"
        },
        {
          "confirmed": 210,
          "deaths": 4,
          "recovered": 0,
          "id": "KE-30"
        },
        {
          "confirmed": 142,
          "deaths": 3,
          "recovered": 0,
          "id": "KE-29"
        },
        {
          "confirmed": 1675,
          "deaths": 14,
          "recovered": 0,
          "id": "KE-28"
        },
        {
          "confirmed": 208,
          "deaths": 6,
          "recovered": 0,
          "id": "KE-27"
        },
        {
          "confirmed": 1073,
          "deaths": 22,
          "recovered": 0,
          "id": "KE-26"
        },
        {
          "confirmed": 1613,
          "deaths": 18,
          "recovered": 0,
          "id": "KE-25"
        },
        {
          "confirmed": 689,
          "deaths": 17,
          "recovered": 0,
          "id": "KE-24"
        },
        {
          "confirmed": 9315,
          "deaths": 335,
          "recovered": 0,
          "id": "KE-23"
        },
        {
          "confirmed": 303,
          "deaths": 5,
          "recovered": 0,
          "id": "KE-22"
        },
        {
          "confirmed": 1986,
          "deaths": 31,
          "recovered": 0,
          "id": "KE-21"
        },
        {
          "confirmed": 7738,
          "deaths": 122,
          "recovered": 0,
          "id": "KE-20"
        },
        {
          "confirmed": 6424,
          "deaths": 273,
          "recovered": 0,
          "id": "KE-19"
        },
        {
          "confirmed": 632,
          "deaths": 18,
          "recovered": 0,
          "id": "KE-18"
        },
        {
          "confirmed": 485,
          "deaths": 10,
          "recovered": 0,
          "id": "KE-17"
        },
        {
          "confirmed": 2564,
          "deaths": 65,
          "recovered": 0,
          "id": "KE-16"
        },
        {
          "confirmed": 6980,
          "deaths": 141,
          "recovered": 0,
          "id": "KE-15"
        },
        {
          "confirmed": 566,
          "deaths": 9,
          "recovered": 0,
          "id": "KE-14"
        },
        {
          "confirmed": 547,
          "deaths": 9,
          "recovered": 0,
          "id": "KE-13"
        },
        {
          "confirmed": 224,
          "deaths": 1,
          "recovered": 0,
          "id": "KE-12"
        },
        {
          "confirmed": 4638,
          "deaths": 139,
          "recovered": 0,
          "id": "KE-11"
        },
        {
          "confirmed": 6956,
          "deaths": 87,
          "recovered": 0,
          "id": "KE-10"
        },
        {
          "confirmed": 368,
          "deaths": 11,
          "recovered": 0,
          "id": "KE-9"
        },
        {
          "confirmed": 586,
          "deaths": 9,
          "recovered": 0,
          "id": "KE-8"
        },
        {
          "confirmed": 3557,
          "deaths": 85,
          "recovered": 0,
          "id": "KE-7"
        },
        {
          "confirmed": 2982,
          "deaths": 69,
          "recovered": 0,
          "id": "KE-6"
        },
        {
          "confirmed": 9399,
          "deaths": 199,
          "recovered": 0,
          "id": "KE-5"
        },
        {
          "confirmed": 1530,
          "deaths": 29,
          "recovered": 0,
          "id": "KE-4"
        },
        {
          "confirmed": 584,
          "deaths": 10,
          "recovered": 0,
          "id": "KE-3"
        },
        {
          "confirmed": 1060,
          "deaths": 27,
          "recovered": 0,
          "id": "KE-2"
        },
        {
          "confirmed": 132,
          "deaths": 3,
          "recovered": 0,
          "id": "KE-1"
        }
      ]
    },
    {
      "date": "2020-04-02",
      "list": [
       
        
        {
          "confirmed": 338,
          "deaths": 17,
          "recovered": 0,
          "id": "KE-47"
        },
        {
          "confirmed": 1706,
          "deaths": 41,
          "recovered": 0,
          "id": "KE-46"
        },
        {
          "confirmed": 1092,
          "deaths": 7,
          "recovered": 0,
          "id": "KE-45"
        },
        {
          "confirmed": 5069,
          "deaths": 77,
          "recovered": 0,
          "id": "KE-44"
        },
        {
          "confirmed": 3013,
          "deaths": 36,
          "recovered": 0,
          "id": "KE-43"
        },
        {
          "confirmed": 165,
          "deaths": 2,
          "recovered": 0,
          "id": "KE-42"
        },
        {
          "confirmed": 1554,
          "deaths": 31,
          "recovered": 0,
          "id": "KE-41"
        },
        {
          "confirmed": 645,
          "deaths": 12,
          "recovered": 0,
          "id": "KE-40"
        },
        {
          "confirmed": 7268,
          "deaths": 90,
          "recovered": 0,
          "id": "KE-39"
        },
        {
          "confirmed": 826,
          "deaths": 21,
          "recovered": 0,
          "id": "KE-38"
        },
        {
          "confirmed": 881,
          "deaths": 34,
          "recovered": 0,
          "id": "KE-37"
        },
        {
          "confirmed": 2901,
          "deaths": 81,
          "recovered": 0,
          "id": "KE-36"
        },
        {
          "confirmed": 92,
          "deaths": 2373,
          "recovered": 0,
          "id": "KE-35"
        },
        {
          "confirmed": 1463,
          "deaths": 38,
          "recovered": 0,
          "id": "KE-34"
        },
        {
          "confirmed": 388,
          "deaths": 6,
          "recovered": 0,
          "id": "KE-33"
        },
        {
          "confirmed": 25590,
          "deaths": 537,
          "recovered": 0,
          "id": "KE-32"
        },
        {
          "confirmed": 316,
          "deaths": 3,
          "recovered": 0,
          "id": "KE-31"
        },
        {
          "confirmed": 246,
          "deaths": 5,
          "recovered": 0,
          "id": "KE-30"
        },
        {
          "confirmed": 159,
          "deaths": 3,
          "recovered": 0,
          "id": "KE-29"
        },
        {
          "confirmed": 1977,
          "deaths": 21,
          "recovered": 0,
          "id": "KE-28"
        },
        {
          "confirmed": 241,
          "deaths": 6,
          "recovered": 0,
          "id": "KE-27"
        },
        {
          "confirmed": 1177,
          "deaths": 26,
          "recovered": 0,
          "id": "KE-26"
        },
        {
          "confirmed": 1857,
          "deaths": 22,
          "recovered": 0,
          "id": "KE-25"
        },
        {
          "confirmed": 742,
          "deaths": 18,
          "recovered": 0,
          "id": "KE-24"
        },
        {
          "confirmed": 10791,
          "deaths": 417,
          "recovered": 0,
          "id": "KE-23"
        },
        {
          "confirmed": 376,
          "deaths": 7,
          "recovered": 0,
          "id": "KE-22"
        },
        {
          "confirmed": 2331,
          "deaths": 36,
          "recovered": 0,
          "id": "KE-21"
        },
        {
          "confirmed": 8966,
          "deaths": 154,
          "recovered": 0,
          "id": "KE-20"
        },
        {
          "confirmed": 9149,
          "deaths": 310,
          "recovered": 0,
          "id": "KE-19"
        },
        {
          "confirmed": 770,
          "deaths": 31,
          "recovered": 0,
          "id": "KE-18"
        },
        {
          "confirmed": 553,
          "deaths": 12,
          "recovered": 0,
          "id": "KE-17"
        },
        {
          "confirmed": 3038,
          "deaths": 78,
          "recovered": 0,
          "id": "KE-16"
        },
        {
          "confirmed": 7695,
          "deaths": 163,
          "recovered": 0,
          "id": "KE-15"
        },
        {
          "confirmed": 776,
          "deaths": 9,
          "recovered": 0,
          "id": "KE-14"
        },
        {
          "confirmed": 614,
          "deaths": 11,
          "recovered": 0,
          "id": "KE-13"
        },
        {
          "confirmed": 256,
          "deaths": 1,
          "recovered": 0,
          "id": "KE-12"
        },
        {
          "confirmed": 5348,
          "deaths": 163,
          "recovered": 0,
          "id": "KE-11"
        },
        {
          "confirmed": 9008,
          "deaths": 164,
          "recovered": 0,
          "id": "KE-10"
        },
        {
          "confirmed": 393,
          "deaths": 12,
          "recovered": 0,
          "id": "KE-9"
        },
        {
          "confirmed": 653,
          "deaths": 12,
          "recovered": 0,
          "id": "KE-8"
        },
        {
          "confirmed": 3824,
          "deaths": 112,
          "recovered": 0,
          "id": "KE-7"
        },
        {
          "confirmed": 3342,
          "deaths": 80,
          "recovered": 0,
          "id": "KE-6"
        },
        {
          "confirmed": 10773,
          "deaths": 238,
          "recovered": 0,
          "id": "KE-5"
        },
        {
          "confirmed": 1715,
          "deaths": 32,
          "recovered": 0,
          "id": "KE-4"
        },
        {
          "confirmed": 643,
          "deaths": 12,
          "recovered": 0,
          "id": "KE-3"
        },
        {
          "confirmed": 1233,
          "deaths": 32,
          "recovered": 0,
          "id": "KE-2"
        },
        {
          "confirmed": 143,
          "deaths": 3,
          "recovered": 0,
          "id": "KE-1"
        }
      ]
    },
    {
      "date": "2020-04-03",
      "list": [
        
       
        {
          "confirmed": 389,
          "deaths": 17,
          "recovered": 0,
          "id": "KE-47"
        },
        {
          "confirmed": 2012,
          "deaths": 46,
          "recovered": 0,
          "id": "KE-46"
        },
        {
          "confirmed": 1255,
          "deaths": 7,
          "recovered": 0,
          "id": "KE-45"
        },
        {
          "confirmed": 5734,
          "deaths": 100,
          "recovered": 0,
          "id": "KE-44"
        },
        {
          "confirmed": 3067,
          "deaths": 41,
          "recovered": 0,
          "id": "KE-43"
        },
        {
          "confirmed": 187,
          "deaths": 2,
          "recovered": 0,
          "id": "KE-42"
        },
        {
          "confirmed": 1700,
          "deaths": 34,
          "recovered": 0,
          "id": "KE-41"
        },
        {
          "confirmed": 711,
          "deaths": 14,
          "recovered": 0,
          "id": "KE-40"
        },
        {
          "confirmed": 8570,
          "deaths": 102,
          "recovered": 0,
          "id": "KE-39"
        },
        {
          "confirmed": 899,
          "deaths": 22,
          "recovered": 0,
          "id": "KE-38"
        },
        {
          "confirmed": 990,
          "deaths": 38,
          "recovered": 0,
          "id": "KE-37"
        },
        {
          "confirmed": 3312,
          "deaths": 91,
          "recovered": 0,
          "id": "KE-36"
        },
        {
          "confirmed": 10,
          "deaths": 2935,
          "recovered": 0,
          "id": "KE-35"
        },
        {
          "confirmed": 1514,
          "deaths": 43,
          "recovered": 0,
          "id": "KE-34"
        },
        {
          "confirmed": 534,
          "deaths": 10,
          "recovered": 0,
          "id": "KE-33"
        },
        {
          "confirmed": 29895,
          "deaths": 646,
          "recovered": 0,
          "id": "KE-32"
        },
        {
          "confirmed": 479,
          "deaths": 5,
          "recovered": 0,
          "id": "KE-31"
        },
        {
          "confirmed": 279,
          "deaths": 6,
          "recovered": 0,
          "id": "KE-30"
        },
        {
          "confirmed": 173,
          "deaths": 3,
          "recovered": 0,
          "id": "KE-29"
        },
        {
          "confirmed": 2251,
          "deaths": 27,
          "recovered": 0,
          "id": "KE-28"
        },
        {
          "confirmed": 243,
          "deaths": 5,
          "recovered": 0,
          "id": "KE-27"
        },
        {
          "confirmed": 1358,
          "deaths": 29,
          "recovered": 0,
          "id": "KE-26"
        },
        {
          "confirmed": 1864,
          "deaths": 25,
          "recovered": 0,
          "id": "KE-25"
        },
        {
          "confirmed": 788,
          "deaths": 22,
          "recovered": 0,
          "id": "KE-24"
        },
        {
          "confirmed": 12744,
          "deaths": 479,
          "recovered": 0,
          "id": "KE-23"
        },
        {
          "confirmed": 432,
          "deaths": 9,
          "recovered": 0,
          "id": "KE-22"
        },
        {
          "confirmed": 2758,
          "deaths": 43,
          "recovered": 0,
          "id": "KE-21"
        },
        {
          "confirmed": 10402,
          "deaths": 192,
          "recovered": 0,
          "id": "KE-20"
        },
        {
          "confirmed": 10297,
          "deaths": 370,
          "recovered": 0,
          "id": "KE-19"
        },
        {
          "confirmed": 770,
          "deaths": 34,
          "recovered": 0,
          "id": "KE-18"
        },
        {
          "confirmed": 629,
          "deaths": 18,
          "recovered": 0,
          "id": "KE-17"
        },
        {
          "confirmed": 3437,
          "deaths": 102,
          "recovered": 0,
          "id": "KE-16"
        },
        {
          "confirmed": 8904,
          "deaths": 210,
          "recovered": 0,
          "id": "KE-15"
        },
        {
          "confirmed": 891,
          "deaths": 9,
          "recovered": 0,
          "id": "KE-14"
        },
        {
          "confirmed": 699,
          "deaths": 11,
          "recovered": 0,
          "id": "KE-13"
        },
        {
          "confirmed": 319,
          "deaths": 3,
          "recovered": 0,
          "id": "KE-12"
        },
        {
          "confirmed": 5831,
          "deaths": 184,
          "recovered": 0,
          "id": "KE-11"
        },
        {
          "confirmed": 10268,
          "deaths": 170,
          "recovered": 0,
          "id": "KE-10"
        },
        {
          "confirmed": 450,
          "deaths": 14,
          "recovered": 0,
          "id": "KE-9"
        },
        {
          "confirmed": 757,
          "deaths": 15,
          "recovered": 0,
          "id": "KE-8"
        },
        {
          "confirmed": 4914,
          "deaths": 131,
          "recovered": 0,
          "id": "KE-7"
        },
        {
          "confirmed": 3742,
          "deaths": 97,
          "recovered": 0,
          "id": "KE-6"
        },
        {
          "confirmed": 12004,
          "deaths": 265,
          "recovered": 0,
          "id": "KE-5"
        },
        {
          "confirmed": 1937,
          "deaths": 41,
          "recovered": 0,
          "id": "KE-4"
        },
        {
          "confirmed": 704,
          "deaths": 12,
          "recovered": 0,
          "id": "KE-3"
        },
        {
          "confirmed": 1495,
          "deaths": 38,
          "recovered": 0,
          "id": "KE-2"
        },
        {
          "confirmed": 157,
          "deaths": 3,
          "recovered": 0,
          "id": "KE-1"
        }
      ]
    },
    {
      "date": "2020-04-04",
      "list": [
        
        
        {
          "confirmed": 461,
          "deaths": 20,
          "recovered": 0,
          "id": "KE-47"
        },
        {
          "confirmed": 2407,
          "deaths": 52,
          "recovered": 0,
          "id": "KE-46"
        },
        {
          "confirmed": 1435,
          "deaths": 8,
          "recovered": 0,
          "id": "KE-45"
        },
        {
          "confirmed": 6567,
          "deaths": 116,
          "recovered": 0,
          "id": "KE-44"
        },
        {
          "confirmed": 3322,
          "deaths": 50,
          "recovered": 0,
          "id": "KE-43"
        },
        {
          "confirmed": 212,
          "deaths": 2,
          "recovered": 0,
          "id": "KE-42"
        },
        {
          "confirmed": 1917,
          "deaths": 40,
          "recovered": 0,
          "id": "KE-41"
        },
        {
          "confirmed": 806,
          "deaths": 17,
          "recovered": 0,
          "id": "KE-40"
        },
        {
          "confirmed": 10444,
          "deaths": 136,
          "recovered": 0,
          "id": "KE-39"
        },
        {
          "confirmed": 899,
          "deaths": 22,
          "recovered": 0,
          "id": "KE-38"
        },
        {
          "confirmed": 1161,
          "deaths": 42,
          "recovered": 0,
          "id": "KE-37"
        },
        {
          "confirmed": 3739,
          "deaths": 102,
          "recovered": 0,
          "id": "KE-36"
        },
        {
          "confirmed": 11,
          "deaths": 3565,
          "recovered": 0,
          "id": "KE-35"
        },
        {
          "confirmed": 1742,
          "deaths": 46,
          "recovered": 0,
          "id": "KE-34"
        },
        {
          "confirmed": 534,
          "deaths": 10,
          "recovered": 0,
          "id": "KE-33"
        },
        {
          "confirmed": 34124,
          "deaths": 846,
          "recovered": 0,
          "id": "KE-32"
        },
        {
          "confirmed": 540,
          "deaths": 7,
          "recovered": 0,
          "id": "KE-31"
        },
        {
          "confirmed": 321,
          "deaths": 6,
          "recovered": 0,
          "id": "KE-30"
        },
        {
          "confirmed": 186,
          "deaths": 3,
          "recovered": 0,
          "id": "KE-29"
        },
        {
          "confirmed": 2486,
          "deaths": 34,
          "recovered": 0,
          "id": "KE-28"
        },
        {
          "confirmed": 265,
          "deaths": 6,
          "recovered": 0,
          "id": "KE-27"
        },
        {
          "confirmed": 1455,
          "deaths": 35,
          "recovered": 0,
          "id": "KE-26"
        },
        {
          "confirmed": 2310,
          "deaths": 33,
          "recovered": 0,
          "id": "KE-25"
        },
        {
          "confirmed": 865,
          "deaths": 24,
          "recovered": 0,
          "id": "KE-24"
        },
        {
          "confirmed": 14225,
          "deaths": 540,
          "recovered": 0,
          "id": "KE-23"
        },
        {
          "confirmed": 456,
          "deaths": 10,
          "recovered": 0,
          "id": "KE-22"
        },
        {
          "confirmed": 3125,
          "deaths": 54,
          "recovered": 0,
          "id": "KE-21"
        },
        {
          "confirmed": 11736,
          "deaths": 216,
          "recovered": 0,
          "id": "KE-20"
        },
        {
          "confirmed": 12496,
          "deaths": 409,
          "recovered": 0,
          "id": "KE-19"
        },
        {
          "confirmed": 917,
          "deaths": 40,
          "recovered": 0,
          "id": "KE-18"
        },
        {
          "confirmed": 698,
          "deaths": 21,
          "recovered": 0,
          "id": "KE-17"
        },
        {
          "confirmed": 3953,
          "deaths": 116,
          "recovered": 0,
          "id": "KE-16"
        },
        {
          "confirmed": 10357,
          "deaths": 244,
          "recovered": 0,
          "id": "KE-15"
        },
        {
          "confirmed": 1022,
          "deaths": 10,
          "recovered": 0,
          "id": "KE-14"
        },
        {
          "confirmed": 787,
          "deaths": 14,
          "recovered": 0,
          "id": "KE-13"
        },
        {
          "confirmed": 351,
          "deaths": 3,
          "recovered": 0,
          "id": "KE-12"
        },
        {
          "confirmed": 6160,
          "deaths": 201,
          "recovered": 0,
          "id": "KE-11"
        },
        {
          "confirmed": 11537,
          "deaths": 195,
          "recovered": 0,
          "id": "KE-10"
        },
        {
          "confirmed": 593,
          "deaths": 14,
          "recovered": 0,
          "id": "KE-9"
        },
        {
          "confirmed": 902,
          "deaths": 21,
          "recovered": 0,
          "id": "KE-8"
        },
        {
          "confirmed": 5276,
          "deaths": 165,
          "recovered": 0,
          "id": "KE-7"
        },
        {
          "confirmed": 4188,
          "deaths": 111,
          "recovered": 0,
          "id": "KE-6"
        },
        {
          "confirmed": 12837,
          "deaths": 289,
          "recovered": 0,
          "id": "KE-5"
        },
        {
          "confirmed": 2187,
          "deaths": 52,
          "recovered": 0,
          "id": "KE-4"
        },
        {
          "confirmed": 743,
          "deaths": 14,
          "recovered": 0,
          "id": "KE-3"
        },
        {
          "confirmed": 1614,
          "deaths": 44,
          "recovered": 0,
          "id": "KE-2"
        },
        {
          "confirmed": 171,
          "deaths": 5,
          "recovered": 0,
          "id": "KE-1"
        }
      ]
    },
    {
      "date": "2020-04-05",
      "list": [
       
       
        {
          "confirmed": 512,
          "deaths": 22,
          "recovered": 0,
          "id": "KE-47"
        },
        {
          "confirmed": 2640,
          "deaths": 52,
          "recovered": 0,
          "id": "KE-46"
        },
        {
          "confirmed": 1608,
          "deaths": 8,
          "recovered": 0,
          "id": "KE-45"
        },
        {
          "confirmed": 7209,
          "deaths": 136,
          "recovered": 0,
          "id": "KE-44"
        },
        {
          "confirmed": 3633,
          "deaths": 53,
          "recovered": 0,
          "id": "KE-43"
        },
        {
          "confirmed": 240,
          "deaths": 2,
          "recovered": 0,
          "id": "KE-42"
        },
        {
          "confirmed": 2049,
          "deaths": 44,
          "recovered": 0,
          "id": "KE-41"
        },
        {
          "confirmed": 922,
          "deaths": 25,
          "recovered": 0,
          "id": "KE-40"
        },
        {
          "confirmed": 11589,
          "deaths": 151,
          "recovered": 0,
          "id": "KE-39"
        },
        {
          "confirmed": 1068,
          "deaths": 27,
          "recovered": 0,
          "id": "KE-38"
        },
        {
          "confirmed": 1254,
          "deaths": 46,
          "recovered": 0,
          "id": "KE-37"
        },
        {
          "confirmed": 4043,
          "deaths": 119,
          "recovered": 0,
          "id": "KE-36"
        },
        {
          "confirmed": 123,
          "deaths": 4159,
          "recovered": 0,
          "id": "KE-35"
        },
        {
          "confirmed": 1855,
          "deaths": 46,
          "recovered": 0,
          "id": "KE-34"
        },
        {
          "confirmed": 670,
          "deaths": 12,
          "recovered": 0,
          "id": "KE-33"
        },
        {
          "confirmed": 505,
          "deaths": 917,
          "recovered": 0,
          "id": "KE-32"
        },
        {
          "confirmed": 621,
          "deaths": 9,
          "recovered": 0,
          "id": "KE-31"
        },
        {
          "confirmed": 364,
          "deaths": 8,
          "recovered": 0,
          "id": "KE-30"
        },
        {
          "confirmed": 207,
          "deaths": 3,
          "recovered": 0,
          "id": "KE-29"
        },
        {
          "confirmed": 2649,
          "deaths": 38,
          "recovered": 0,
          "id": "KE-28"
        },
        {
          "confirmed": 286,
          "deaths": 6,
          "recovered": 0,
          "id": "KE-27"
        },
        {
          "confirmed": 1638,
          "deaths": 43,
          "recovered": 0,
          "id": "KE-26"
        },
        {
          "confirmed": 2347,
          "deaths": 44,
          "recovered": 0,
          "id": "KE-25"
        },
        {
          "confirmed": 935,
          "deaths": 29,
          "recovered": 0,
          "id": "KE-24"
        },
        {
          "confirmed": 15718,
          "deaths": 617,
          "recovered": 0,
          "id": "KE-23"
        },
        {
          "confirmed": 470,
          "deaths": 10,
          "recovered": 0,
          "id": "KE-22"
        },
        {
          "confirmed": 3617,
          "deaths": 67,
          "recovered": 0,
          "id": "KE-21"
        },
        {
          "confirmed": 12500,
          "deaths": 231,
          "recovered": 0,
          "id": "KE-20"
        },
        {
          "confirmed": 13010,
          "deaths": 477,
          "recovered": 0,
          "id": "KE-19"
        },
        {
          "confirmed": 955,
          "deaths": 45,
          "recovered": 0,
          "id": "KE-18"
        },
        {
          "confirmed": 751,
          "deaths": 22,
          "recovered": 0,
          "id": "KE-17"
        },
        {
          "confirmed": 4411,
          "deaths": 127,
          "recovered": 0,
          "id": "KE-16"
        },
        {
          "confirmed": 11259,
          "deaths": 274,
          "recovered": 0,
          "id": "KE-15"
        },
        {
          "confirmed": 1078,
          "deaths": 10,
          "recovered": 0,
          "id": "KE-14"
        },
        {
          "confirmed": 869,
          "deaths": 18,
          "recovered": 0,
          "id": "KE-13"
        },
        {
          "confirmed": 371,
          "deaths": 4,
          "recovered": 0,
          "id": "KE-12"
        },
        {
          "confirmed": 6647,
          "deaths": 211,
          "recovered": 0,
          "id": "KE-11"
        },
        {
          "confirmed": 12350,
          "deaths": 221,
          "recovered": 0,
          "id": "KE-10"
        },
        {
          "confirmed": 673,
          "deaths": 14,
          "recovered": 0,
          "id": "KE-9"
        },
        {
          "confirmed": 1002,
          "deaths": 22,
          "recovered": 0,
          "id": "KE-8"
        },
        {
          "confirmed": 5675,
          "deaths": 189,
          "recovered": 0,
          "id": "KE-7"
        },
        {
          "confirmed": 4950,
          "deaths": 140,
          "recovered": 0,
          "id": "KE-6"
        },
        {
          "confirmed": 15034,
          "deaths": 348,
          "recovered": 0,
          "id": "KE-5"
        },
        {
          "confirmed": 2486,
          "deaths": 64,
          "recovered": 0,
          "id": "KE-4"
        },
        {
          "confirmed": 837,
          "deaths": 16,
          "recovered": 0,
          "id": "KE-3"
        },
        {
          "confirmed": 1765,
          "deaths": 45,
          "recovered": 0,
          "id": "KE-2"
        },
        {
          "confirmed": 185,
          "deaths": 6,
          "recovered": 0,
          "id": "KE-1"
        }
      ]
    },
    {
      "date": "2020-04-06",
      "list": [
        
        
        {
          "confirmed": 543,
          "deaths": 23,
          "recovered": 0,
          "id": "KE-47"
        },
        {
          "confirmed": 2878,
          "deaths": 66,
          "recovered": 0,
          "id": "KE-46"
        },
        {
          "confirmed": 1685,
          "deaths": 13,
          "recovered": 0,
          "id": "KE-45"
        },
        {
          "confirmed": 8043,
          "deaths": 150,
          "recovered": 0,
          "id": "KE-44"
        },
        {
          "confirmed": 3802,
          "deaths": 65,
          "recovered": 0,
          "id": "KE-43"
        },
        {
          "confirmed": 288,
          "deaths": 4,
          "recovered": 0,
          "id": "KE-42"
        },
        {
          "confirmed": 2232,
          "deaths": 48,
          "recovered": 0,
          "id": "KE-41"
        },
        {
          "confirmed": 1082,
          "deaths": 27,
          "recovered": 0,
          "id": "KE-40"
        },
        {
          "confirmed": 13127,
          "deaths": 179,
          "recovered": 0,
          "id": "KE-39"
        },
        {
          "confirmed": 1068,
          "deaths": 27,
          "recovered": 0,
          "id": "KE-38"
        },
        {
          "confirmed": 1329,
          "deaths": 51,
          "recovered": 0,
          "id": "KE-37"
        },
        {
          "confirmed": 4453,
          "deaths": 142,
          "recovered": 0,
          "id": "KE-36"
        },
        {
          "confirmed": 13,
          "deaths": 4698,
          "recovered": 0,
          "id": "KE-35"
        },
        {
          "confirmed": 1953,
          "deaths": 46,
          "recovered": 0,
          "id": "KE-34"
        },
        {
          "confirmed": 757,
          "deaths": 12,
          "recovered": 0,
          "id": "KE-33"
        },
        {
          "confirmed": 41090,
          "deaths": 1003,
          "recovered": 0,
          "id": "KE-32"
        },
        {
          "confirmed": 715,
          "deaths": 9,
          "recovered": 0,
          "id": "KE-31"
        },
        {
          "confirmed": 417,
          "deaths": 9,
          "recovered": 0,
          "id": "KE-30"
        },
        {
          "confirmed": 225,
          "deaths": 3,
          "recovered": 0,
          "id": "KE-29"
        },
        {
          "confirmed": 2962,
          "deaths": 45,
          "recovered": 0,
          "id": "KE-28"
        },
        {
          "confirmed": 299,
          "deaths": 6,
          "recovered": 0,
          "id": "KE-27"
        },
        {
          "confirmed": 1738,
          "deaths": 51,
          "recovered": 0,
          "id": "KE-26"
        },
        {
          "confirmed": 2736,
          "deaths": 47,
          "recovered": 0,
          "id": "KE-25"
        },
        {
          "confirmed": 986,
          "deaths": 30,
          "recovered": 0,
          "id": "KE-24"
        },
        {
          "confirmed": 17221,
          "deaths": 727,
          "recovered": 0,
          "id": "KE-23"
        },
        {
          "confirmed": 499,
          "deaths": 10,
          "recovered": 0,
          "id": "KE-22"
        },
        {
          "confirmed": 4045,
          "deaths": 91,
          "recovered": 0,
          "id": "KE-21"
        },
        {
          "confirmed": 13837,
          "deaths": 260,
          "recovered": 0,
          "id": "KE-20"
        },
        {
          "confirmed": 14867,
          "deaths": 512,
          "recovered": 0,
          "id": "KE-19"
        },
        {
          "confirmed": 955,
          "deaths": 45,
          "recovered": 0,
          "id": "KE-18"
        },
        {
          "confirmed": 849,
          "deaths": 25,
          "recovered": 0,
          "id": "KE-17"
        },
        {
          "confirmed": 4956,
          "deaths": 143,
          "recovered": 0,
          "id": "KE-16"
        },
        {
          "confirmed": 12262,
          "deaths": 307,
          "recovered": 0,
          "id": "KE-15"
        },
        {
          "confirmed": 1101,
          "deaths": 10,
          "recovered": 0,
          "id": "KE-14"
        },
        {
          "confirmed": 946,
          "deaths": 25,
          "recovered": 0,
          "id": "KE-13"
        },
        {
          "confirmed": 387,
          "deaths": 5,
          "recovered": 0,
          "id": "KE-12"
        },
        {
          "confirmed": 7314,
          "deaths": 229,
          "recovered": 0,
          "id": "KE-11"
        },
        {
          "confirmed": 13324,
          "deaths": 236,
          "recovered": 0,
          "id": "KE-10"
        },
        {
          "confirmed": 783,
          "deaths": 15,
          "recovered": 0,
          "id": "KE-9"
        },
        {
          "confirmed": 1097,
          "deaths": 24,
          "recovered": 0,
          "id": "KE-8"
        },
        {
          "confirmed": 6906,
          "deaths": 206,
          "recovered": 0,
          "id": "KE-7"
        },
        {
          "confirmed": 5183,
          "deaths": 150,
          "recovered": 0,
          "id": "KE-6"
        },
        {
          "confirmed": 16019,
          "deaths": 380,
          "recovered": 0,
          "id": "KE-5"
        },
        {
          "confirmed": 2732,
          "deaths": 65,
          "recovered": 0,
          "id": "KE-4"
        },
        {
          "confirmed": 875,
          "deaths": 16,
          "recovered": 0,
          "id": "KE-3"
        },
        {
          "confirmed": 1952,
          "deaths": 49,
          "recovered": 0,
          "id": "KE-2"
        },
        {
          "confirmed": 190,
          "deaths": 6,
          "recovered": 0,
          "id": "KE-1"
        }
      ]
    },
    {
      "date": "2020-04-07",
      "list": [
        
        
        {
          "confirmed": 575,
          "deaths": 23,
          "recovered": 0,
          "id": "KE-47"
        },
        {
          "confirmed": 3335,
          "deaths": 66,
          "recovered": 0,
          "id": "KE-46"
        },
        {
          "confirmed": 1746,
          "deaths": 13,
          "recovered": 0,
          "id": "KE-45"
        },
        {
          "confirmed": 8925,
          "deaths": 160,
          "recovered": 0,
          "id": "KE-44"
        },
        {
          "confirmed": 4139,
          "deaths": 72,
          "recovered": 0,
          "id": "KE-43"
        },
        {
          "confirmed": 320,
          "deaths": 6,
          "recovered": 0,
          "id": "KE-42"
        },
        {
          "confirmed": 2417,
          "deaths": 51,
          "recovered": 0,
          "id": "KE-41"
        },
        {
          "confirmed": 1229,
          "deaths": 30,
          "recovered": 0,
          "id": "KE-40"
        },
        {
          "confirmed": 14853,
          "deaths": 247,
          "recovered": 0,
          "id": "KE-39"
        },
        {
          "confirmed": 1132,
          "deaths": 29,
          "recovered": 0,
          "id": "KE-38"
        },
        {
          "confirmed": 1474,
          "deaths": 67,
          "recovered": 0,
          "id": "KE-37"
        },
        {
          "confirmed": 4782,
          "deaths": 167,
          "recovered": 0,
          "id": "KE-36"
        },
        {
          "confirmed": 13,
          "deaths": 54,
          "recovered": 0,
          "id": "KE-35"
        },
        {
          "confirmed": 2124,
          "deaths": 72,
          "recovered": 0,
          "id": "KE-34"
        },
        {
          "confirmed": 876,
          "deaths": 13,
          "recovered": 0,
          "id": "KE-33"
        },
        {
          "confirmed": 44416,
          "deaths": 1232,
          "recovered": 0,
          "id": "KE-32"
        },
        {
          "confirmed": 715,
          "deaths": 9,
          "recovered": 0,
          "id": "KE-31"
        },
        {
          "confirmed": 447,
          "deaths": 10,
          "recovered": 0,
          "id": "KE-30"
        },
        {
          "confirmed": 237,
          "deaths": 4,
          "recovered": 0,
          "id": "KE-29"
        },
        {
          "confirmed": 3299,
          "deaths": 53,
          "recovered": 0,
          "id": "KE-28"
        },
        {
          "confirmed": 319,
          "deaths": 6,
          "recovered": 0,
          "id": "KE-27"
        },
        {
          "confirmed": 1915,
          "deaths": 60,
          "recovered": 0,
          "id": "KE-26"
        },
        {
          "confirmed": 3130,
          "deaths": 65,
          "recovered": 0,
          "id": "KE-25"
        },
        {
          "confirmed": 1069,
          "deaths": 34,
          "recovered": 0,
          "id": "KE-24"
        },
        {
          "confirmed": 18970,
          "deaths": 845,
          "recovered": 0,
          "id": "KE-23"
        },
        {
          "confirmed": 519,
          "deaths": 12,
          "recovered": 0,
          "id": "KE-22"
        },
        {
          "confirmed": 4371,
          "deaths": 103,
          "recovered": 0,
          "id": "KE-21"
        },
        {
          "confirmed": 15202,
          "deaths": 356,
          "recovered": 0,
          "id": "KE-20"
        },
        {
          "confirmed": 16284,
          "deaths": 582,
          "recovered": 0,
          "id": "KE-19"
        },
        {
          "confirmed": 1149,
          "deaths": 65,
          "recovered": 0,
          "id": "KE-18"
        },
        {
          "confirmed": 912,
          "deaths": 29,
          "recovered": 0,
          "id": "KE-17"
        },
        {
          "confirmed": 5510,
          "deaths": 173,
          "recovered": 0,
          "id": "KE-16"
        },
        {
          "confirmed": 12271,
          "deaths": 308,
          "recovered": 0,
          "id": "KE-15"
        },
        {
          "confirmed": 1170,
          "deaths": 13,
          "recovered": 0,
          "id": "KE-14"
        },
        {
          "confirmed": 1046,
          "deaths": 25,
          "recovered": 0,
          "id": "KE-13"
        },
        {
          "confirmed": 410,
          "deaths": 5,
          "recovered": 0,
          "id": "KE-12"
        },
        {
          "confirmed": 8822,
          "deaths": 329,
          "recovered": 0,
          "id": "KE-11"
        },
        {
          "confirmed": 14545,
          "deaths": 283,
          "recovered": 0,
          "id": "KE-10"
        },
        {
          "confirmed": 928,
          "deaths": 16,
          "recovered": 0,
          "id": "KE-9"
        },
        {
          "confirmed": 1211,
          "deaths": 22,
          "recovered": 0,
          "id": "KE-8"
        },
        {
          "confirmed": 7781,
          "deaths": 277,
          "recovered": 0,
          "id": "KE-7"
        },
        {
          "confirmed": 5429,
          "deaths": 179,
          "recovered": 0,
          "id": "KE-6"
        },
        {
          "confirmed": 17351,
          "deaths": 432,
          "recovered": 0,
          "id": "KE-5"
        },
        {
          "confirmed": 2870,
          "deaths": 73,
          "recovered": 0,
          "id": "KE-4"
        },
        {
          "confirmed": 946,
          "deaths": 18,
          "recovered": 0,
          "id": "KE-3"
        },
        {
          "confirmed": 2169,
          "deaths": 64,
          "recovered": 0,
          "id": "KE-2"
        },
        {
          "confirmed": 213,
          "deaths": 6,
          "recovered": 0,
          "id": "KE-1"
        }
      ]
    },
    {
      "date": "2020-04-08",
      "list": [
        
       
        {
          "confirmed": 605,
          "deaths": 23,
          "recovered": 0,
          "id": "KE-47"
        },
        {
          "confirmed": 3645,
          "deaths": 66,
          "recovered": 0,
          "id": "KE-46"
        },
        {
          "confirmed": 1855,
          "deaths": 13,
          "recovered": 0,
          "id": "KE-45"
        },
        {
          "confirmed": 9777,
          "deaths": 189,
          "recovered": 0,
          "id": "KE-44"
        },
        {
          "confirmed": 4363,
          "deaths": 80,
          "recovered": 0,
          "id": "KE-43"
        },
        {
          "confirmed": 393,
          "deaths": 6,
          "recovered": 0,
          "id": "KE-42"
        },
        {
          "confirmed": 2417,
          "deaths": 51,
          "recovered": 0,
          "id": "KE-41"
        },
        {
          "confirmed": 1450,
          "deaths": 35,
          "recovered": 0,
          "id": "KE-40"
        },
        {
          "confirmed": 16631,
          "deaths": 318,
          "recovered": 0,
          "id": "KE-39"
        },
        {
          "confirmed": 1181,
          "deaths": 33,
          "recovered": 0,
          "id": "KE-38"
        },
        {
          "confirmed": 1526,
          "deaths": 79,
          "recovered": 0,
          "id": "KE-37"
        },
        {
          "confirmed": 5148,
          "deaths": 193,
          "recovered": 0,
          "id": "KE-36"
        },
        {
          "confirmed": 15,
          "deaths": 6268,
          "recovered": 0,
          "id": "KE-35"
        },
        {
          "confirmed": 2259,
          "deaths": 72,
          "recovered": 0,
          "id": "KE-34"
        },
        {
          "confirmed": 902,
          "deaths": 13,
          "recovered": 0,
          "id": "KE-33"
        },
        {
          "confirmed": 47437,
          "deaths": 1504,
          "recovered": 0,
          "id": "KE-32"
        },
        {
          "confirmed": 747,
          "deaths": 13,
          "recovered": 0,
          "id": "KE-31"
        },
        {
          "confirmed": 519,
          "deaths": 12,
          "recovered": 0,
          "id": "KE-30"
        },
        {
          "confirmed": 251,
          "deaths": 4,
          "recovered": 0,
          "id": "KE-29"
        },
        {
          "confirmed": 3499,
          "deaths": 66,
          "recovered": 0,
          "id": "KE-28"
        },
        {
          "confirmed": 332,
          "deaths": 6,
          "recovered": 0,
          "id": "KE-27"
        },
        {
          "confirmed": 2003,
          "deaths": 67,
          "recovered": 0,
          "id": "KE-26"
        },
        {
          "confirmed": 3209,
          "deaths": 86,
          "recovered": 0,
          "id": "KE-25"
        },
        {
          "confirmed": 1154,
          "deaths": 39,
          "recovered": 0,
          "id": "KE-24"
        },
        {
          "confirmed": 20346,
          "deaths": 959,
          "recovered": 0,
          "id": "KE-23"
        },
        {
          "confirmed": 537,
          "deaths": 14,
          "recovered": 0,
          "id": "KE-22"
        },
        {
          "confirmed": 5529,
          "deaths": 124,
          "recovered": 0,
          "id": "KE-21"
        },
        {
          "confirmed": 16790,
          "deaths": 433,
          "recovered": 0,
          "id": "KE-20"
        },
        {
          "confirmed": 17030,
          "deaths": 652,
          "recovered": 0,
          "id": "KE-19"
        },
        {
          "confirmed": 1149,
          "deaths": 65,
          "recovered": 0,
          "id": "KE-18"
        },
        {
          "confirmed": 1046,
          "deaths": 34,
          "recovered": 0,
          "id": "KE-17"
        },
        {
          "confirmed": 5943,
          "deaths": 203,
          "recovered": 0,
          "id": "KE-16"
        },
        {
          "confirmed": 15078,
          "deaths": 462,
          "recovered": 0,
          "id": "KE-15"
        },
        {
          "confirmed": 1210,
          "deaths": 15,
          "recovered": 0,
          "id": "KE-14"
        },
        {
          "confirmed": 1145,
          "deaths": 27,
          "recovered": 0,
          "id": "KE-13"
        },
        {
          "confirmed": 410,
          "deaths": 5,
          "recovered": 0,
          "id": "KE-12"
        },
        {
          "confirmed": 9901,
          "deaths": 362,
          "recovered": 0,
          "id": "KE-11"
        },
        {
          "confirmed": 15456,
          "deaths": 309,
          "recovered": 0,
          "id": "KE-10"
        },
        {
          "confirmed": 1116,
          "deaths": 19,
          "recovered": 0,
          "id": "KE-9"
        },
        {
          "confirmed": 1440,
          "deaths": 27,
          "recovered": 0,
          "id": "KE-8"
        },
        {
          "confirmed": 7781,
          "deaths": 326,
          "recovered": 0,
          "id": "KE-7"
        },
        {
          "confirmed": 5655,
          "deaths": 193,
          "recovered": 0,
          "id": "KE-6"
        },
        {
          "confirmed": 18897,
          "deaths": 495,
          "recovered": 0,
          "id": "KE-5"
        },
        {
          "confirmed": 3036,
          "deaths": 80,
          "recovered": 0,
          "id": "KE-4"
        },
        {
          "confirmed": 1000,
          "deaths": 18,
          "recovered": 0,
          "id": "KE-3"
        },
        {
          "confirmed": 2328,
          "deaths": 66,
          "recovered": 0,
          "id": "KE-2"
        },
        {
          "confirmed": 226,
          "deaths": 7,
          "recovered": 0,
          "id": "KE-1"
        }
      ]
    },
    {
      "date": "2020-04-09",
      "list": [
        
        
        {
          "confirmed": 628,
          "deaths": 23,
          "recovered": 0,
          "id": "KE-47"
        },
        {
          "confirmed": 4042,
          "deaths": 109,
          "recovered": 0,
          "id": "KE-46"
        },
        {
          "confirmed": 1856,
          "deaths": 13,
          "recovered": 0,
          "id": "KE-45"
        },
        {
          "confirmed": 11208,
          "deaths": 210,
          "recovered": 0,
          "id": "KE-44"
        },
        {
          "confirmed": 4634,
          "deaths": 94,
          "recovered": 0,
          "id": "KE-43"
        },
        {
          "confirmed": 447,
          "deaths": 6,
          "recovered": 0,
          "id": "KE-42"
        },
        {
          "confirmed": 2793,
          "deaths": 67,
          "recovered": 0,
          "id": "KE-41"
        },
        {
          "confirmed": 1727,
          "deaths": 43,
          "recovered": 0,
          "id": "KE-40"
        },
        {
          "confirmed": 18300,
          "deaths": 345,
          "recovered": 0,
          "id": "KE-39"
        },
        {
          "confirmed": 1321,
          "deaths": 44,
          "recovered": 0,
          "id": "KE-38"
        },
        {
          "confirmed": 1686,
          "deaths": 80,
          "recovered": 0,
          "id": "KE-37"
        },
        {
          "confirmed": 5512,
          "deaths": 213,
          "recovered": 0,
          "id": "KE-36"
        },
        {
          "confirmed": 16,
          "deaths": 7067,
          "recovered": 0,
          "id": "KE-35"
        },
        {
          "confirmed": 2456,
          "deaths": 81,
          "recovered": 0,
          "id": "KE-34"
        },
        {
          "confirmed": 865,
          "deaths": 16,
          "recovered": 0,
          "id": "KE-33"
        },
        {
          "confirmed": 51027,
          "deaths": 1709,
          "recovered": 0,
          "id": "KE-32"
        },
        {
          "confirmed": 819,
          "deaths": 21,
          "recovered": 0,
          "id": "KE-31"
        },
        {
          "confirmed": 568,
          "deaths": 14,
          "recovered": 0,
          "id": "KE-30"
        },
        {
          "confirmed": 269,
          "deaths": 5,
          "recovered": 0,
          "id": "KE-29"
        },
        {
          "confirmed": 3736,
          "deaths": 76,
          "recovered": 0,
          "id": "KE-28"
        },
        {
          "confirmed": 354,
          "deaths": 6,
          "recovered": 0,
          "id": "KE-27"
        },
        {
          "confirmed": 2260,
          "deaths": 76,
          "recovered": 0,
          "id": "KE-26"
        },
        {
          "confirmed": 3432,
          "deaths": 93,
          "recovered": 0,
          "id": "KE-25"
        },
        {
          "confirmed": 1240,
          "deaths": 50,
          "recovered": 0,
          "id": "KE-24"
        },
        {
          "confirmed": 21504,
          "deaths": 1076,
          "recovered": 0,
          "id": "KE-23"
        },
        {
          "confirmed": 560,
          "deaths": 16,
          "recovered": 0,
          "id": "KE-22"
        },
        {
          "confirmed": 6185,
          "deaths": 138,
          "recovered": 0,
          "id": "KE-21"
        },
        {
          "confirmed": 18941,
          "deaths": 503,
          "recovered": 0,
          "id": "KE-20"
        },
        {
          "confirmed": 18283,
          "deaths": 702,
          "recovered": 0,
          "id": "KE-19"
        },
        {
          "confirmed": 1341,
          "deaths": 73,
          "recovered": 0,
          "id": "KE-18"
        },
        {
          "confirmed": 1116,
          "deaths": 42,
          "recovered": 0,
          "id": "KE-17"
        },
        {
          "confirmed": 6351,
          "deaths": 245,
          "recovered": 0,
          "id": "KE-16"
        },
        {
          "confirmed": 15079,
          "deaths": 462,
          "recovered": 0,
          "id": "KE-15"
        },
        {
          "confirmed": 1232,
          "deaths": 18,
          "recovered": 0,
          "id": "KE-14"
        },
        {
          "confirmed": 1270,
          "deaths": 29,
          "recovered": 0,
          "id": "KE-13"
        },
        {
          "confirmed": 442,
          "deaths": 6,
          "recovered": 0,
          "id": "KE-12"
        },
        {
          "confirmed": 10566,
          "deaths": 379,
          "recovered": 0,
          "id": "KE-11"
        },
        {
          "confirmed": 16364,
          "deaths": 354,
          "recovered": 0,
          "id": "KE-10"
        },
        {
          "confirmed": 1209,
          "deaths": 23,
          "recovered": 0,
          "id": "KE-9"
        },
        {
          "confirmed": 1523,
          "deaths": 32,
          "recovered": 0,
          "id": "KE-8"
        },
        {
          "confirmed": 9784,
          "deaths": 380,
          "recovered": 0,
          "id": "KE-7"
        },
        {
          "confirmed": 5655,
          "deaths": 193,
          "recovered": 0,
          "id": "KE-6"
        },
        {
          "confirmed": 19710,
          "deaths": 544,
          "recovered": 0,
          "id": "KE-5"
        },
        {
          "confirmed": 3018,
          "deaths": 89,
          "recovered": 0,
          "id": "KE-4"
        },
        {
          "confirmed": 1119,
          "deaths": 21,
          "recovered": 0,
          "id": "KE-3"
        },
        {
          "confirmed": 2703,
          "deaths": 70,
          "recovered": 0,
          "id": "KE-2"
        },
        {
          "confirmed": 235,
          "deaths": 7,
          "recovered": 0,
          "id": "KE-1"
        }
      ]
    },
    {
      "date": "2020-04-10",
      "list": [
        
        
        {
          "confirmed": 679,
          "deaths": 24,
          "recovered": 0,
          "id": "KE-47"
        },
        {
          "confirmed": 4509,
          "deaths": 121,
          "recovered": 0,
          "id": "KE-46"
        },
        {
          "confirmed": 2103,
          "deaths": 17,
          "recovered": 0,
          "id": "KE-45"
        },
        {
          "confirmed": 12105,
          "deaths": 238,
          "recovered": 0,
          "id": "KE-44"
        },
        {
          "confirmed": 4891,
          "deaths": 98,
          "recovered": 0,
          "id": "KE-43"
        },
        {
          "confirmed": 536,
          "deaths": 6,
          "recovered": 0,
          "id": "KE-42"
        },
        {
          "confirmed": 3067,
          "deaths": 72,
          "recovered": 0,
          "id": "KE-41"
        },
        {
          "confirmed": 1727,
          "deaths": 43,
          "recovered": 0,
          "id": "KE-40"
        },
        {
          "confirmed": 20051,
          "deaths": 418,
          "recovered": 0,
          "id": "KE-39"
        },
        {
          "confirmed": 1322,
          "deaths": 44,
          "recovered": 0,
          "id": "KE-38"
        },
        {
          "confirmed": 1794,
          "deaths": 88,
          "recovered": 0,
          "id": "KE-37"
        },
        {
          "confirmed": 5878,
          "deaths": 231,
          "recovered": 0,
          "id": "KE-36"
        },
        {
          "confirmed": 17,
          "deaths": 7867,
          "recovered": 0,
          "id": "KE-35"
        },
        {
          "confirmed": 2722,
          "deaths": 90,
          "recovered": 0,
          "id": "KE-34"
        },
        {
          "confirmed": 1081,
          "deaths": 17,
          "recovered": 0,
          "id": "KE-33"
        },
        {
          "confirmed": 54588,
          "deaths": 1932,
          "recovered": 0,
          "id": "KE-32"
        },
        {
          "confirmed": 819,
          "deaths": 21,
          "recovered": 0,
          "id": "KE-31"
        },
        {
          "confirmed": 635,
          "deaths": 15,
          "recovered": 0,
          "id": "KE-30"
        },
        {
          "confirmed": 278,
          "deaths": 6,
          "recovered": 0,
          "id": "KE-29"
        },
        {
          "confirmed": 3965,
          "deaths": 83,
          "recovered": 0,
          "id": "KE-28"
        },
        {
          "confirmed": 365,
          "deaths": 6,
          "recovered": 0,
          "id": "KE-27"
        },
        {
          "confirmed": 2469,
          "deaths": 82,
          "recovered": 0,
          "id": "KE-26"
        },
        {
          "confirmed": 3897,
          "deaths": 99,
          "recovered": 0,
          "id": "KE-25"
        },
        {
          "confirmed": 1336,
          "deaths": 57,
          "recovered": 0,
          "id": "KE-24"
        },
        {
          "confirmed": 22434,
          "deaths": 1276,
          "recovered": 0,
          "id": "KE-23"
        },
        {
          "confirmed": 586,
          "deaths": 17,
          "recovered": 0,
          "id": "KE-22"
        },
        {
          "confirmed": 6968,
          "deaths": 171,
          "recovered": 0,
          "id": "KE-21"
        },
        {
          "confirmed": 20974,
          "deaths": 599,
          "recovered": 0,
          "id": "KE-20"
        },
        {
          "confirmed": 19253,
          "deaths": 755,
          "recovered": 0,
          "id": "KE-19"
        },
        {
          "confirmed": 1693,
          "deaths": 90,
          "recovered": 0,
          "id": "KE-18"
        },
        {
          "confirmed": 1117,
          "deaths": 42,
          "recovered": 0,
          "id": "KE-17"
        },
        {
          "confirmed": 6907,
          "deaths": 300,
          "recovered": 0,
          "id": "KE-16"
        },
        {
          "confirmed": 17887,
          "deaths": 597,
          "recovered": 0,
          "id": "KE-15"
        },
        {
          "confirmed": 1354,
          "deaths": 24,
          "recovered": 0,
          "id": "KE-14"
        },
        {
          "confirmed": 1388,
          "deaths": 31,
          "recovered": 0,
          "id": "KE-13"
        },
        {
          "confirmed": 442,
          "deaths": 6,
          "recovered": 0,
          "id": "KE-12"
        },
        {
          "confirmed": 11485,
          "deaths": 416,
          "recovered": 0,
          "id": "KE-11"
        },
        {
          "confirmed": 17531,
          "deaths": 390,
          "recovered": 0,
          "id": "KE-10"
        },
        {
          "confirmed": 1326,
          "deaths": 32,
          "recovered": 0,
          "id": "KE-9"
        },
        {
          "confirmed": 1660,
          "deaths": 38,
          "recovered": 0,
          "id": "KE-8"
        },
        {
          "confirmed": 10538,
          "deaths": 448,
          "recovered": 0,
          "id": "KE-7"
        },
        {
          "confirmed": 6202,
          "deaths": 226,
          "recovered": 0,
          "id": "KE-6"
        },
        {
          "confirmed": 21081,
          "deaths": 583,
          "recovered": 0,
          "id": "KE-5"
        },
        {
          "confirmed": 3112,
          "deaths": 97,
          "recovered": 0,
          "id": "KE-4"
        },
        {
          "confirmed": 1171,
          "deaths": 21,
          "recovered": 0,
          "id": "KE-3"
        },
        {
          "confirmed": 2947,
          "deaths": 80,
          "recovered": 0,
          "id": "KE-2"
        },
        {
          "confirmed": 246,
          "deaths": 7,
          "recovered": 0,
          "id": "KE-1"
        }
      ]
    },
    {
      "date": "2020-04-11",
      "list": [
        
      
        {
          "confirmed": 711,
          "deaths": 25,
          "recovered": 0,
          "id": "KE-47"
        },
        {
          "confirmed": 5077,
          "deaths": 130,
          "recovered": 0,
          "id": "KE-46"
        },
        {
          "confirmed": 2207,
          "deaths": 18,
          "recovered": 0,
          "id": "KE-45"
        },
        {
          "confirmed": 13023,
          "deaths": 266,
          "recovered": 0,
          "id": "KE-44"
        },
        {
          "confirmed": 5132,
          "deaths": 106,
          "recovered": 0,
          "id": "KE-43"
        },
        {
          "confirmed": 626,
          "deaths": 6,
          "recovered": 0,
          "id": "KE-42"
        },
        {
          "confirmed": 3211,
          "deaths": 80,
          "recovered": 0,
          "id": "KE-41"
        },
        {
          "confirmed": 2349,
          "deaths": 56,
          "recovered": 0,
          "id": "KE-40"
        },
        {
          "confirmed": 21719,
          "deaths": 503,
          "recovered": 0,
          "id": "KE-39"
        },
        {
          "confirmed": 1371,
          "deaths": 48,
          "recovered": 0,
          "id": "KE-38"
        },
        {
          "confirmed": 1868,
          "deaths": 94,
          "recovered": 0,
          "id": "KE-37"
        },
        {
          "confirmed": 6250,
          "deaths": 247,
          "recovered": 0,
          "id": "KE-36"
        },
        {
          "confirmed": 18,
          "deaths": 8627,
          "recovered": 0,
          "id": "KE-35"
        },
        {
          "confirmed": 2702,
          "deaths": 102,
          "recovered": 0,
          "id": "KE-34"
        },
        {
          "confirmed": 1091,
          "deaths": 19,
          "recovered": 0,
          "id": "KE-33"
        },
        {
          "confirmed": 58151,
          "deaths": 2183,
          "recovered": 0,
          "id": "KE-32"
        },
        {
          "confirmed": 885,
          "deaths": 22,
          "recovered": 0,
          "id": "KE-31"
        },
        {
          "confirmed": 699,
          "deaths": 17,
          "recovered": 0,
          "id": "KE-30"
        },
        {
          "confirmed": 293,
          "deaths": 7,
          "recovered": 0,
          "id": "KE-29"
        },
        {
          "confirmed": 4354,
          "deaths": 89,
          "recovered": 0,
          "id": "KE-28"
        },
        {
          "confirmed": 377,
          "deaths": 6,
          "recovered": 0,
          "id": "KE-27"
        },
        {
          "confirmed": 2642,
          "deaths": 93,
          "recovered": 0,
          "id": "KE-26"
        },
        {
          "confirmed": 4108,
          "deaths": 116,
          "recovered": 0,
          "id": "KE-25"
        },
        {
          "confirmed": 1427,
          "deaths": 64,
          "recovered": 0,
          "id": "KE-24"
        },
        {
          "confirmed": 23605,
          "deaths": 1384,
          "recovered": 0,
          "id": "KE-23"
        },
        {
          "confirmed": 616,
          "deaths": 19,
          "recovered": 0,
          "id": "KE-22"
        },
        {
          "confirmed": 7694,
          "deaths": 206,
          "recovered": 0,
          "id": "KE-21"
        },
        {
          "confirmed": 22860,
          "deaths": 686,
          "recovered": 0,
          "id": "KE-20"
        },
        {
          "confirmed": 20014,
          "deaths": 806,
          "recovered": 0,
          "id": "KE-19"
        },
        {
          "confirmed": 1693,
          "deaths": 90,
          "recovered": 0,
          "id": "KE-18"
        },
        {
          "confirmed": 1275,
          "deaths": 55,
          "recovered": 0,
          "id": "KE-17"
        },
        {
          "confirmed": 7435,
          "deaths": 330,
          "recovered": 0,
          "id": "KE-16"
        },
        {
          "confirmed": 19180,
          "deaths": 677,
          "recovered": 0,
          "id": "KE-15"
        },
        {
          "confirmed": 1396,
          "deaths": 25,
          "recovered": 0,
          "id": "KE-14"
        },
        {
          "confirmed": 1510,
          "deaths": 34,
          "recovered": 0,
          "id": "KE-13"
        },
        {
          "confirmed": 465,
          "deaths": 8,
          "recovered": 0,
          "id": "KE-12"
        },
        {
          "confirmed": 12159,
          "deaths": 429,
          "recovered": 0,
          "id": "KE-11"
        },
        {
          "confirmed": 18494,
          "deaths": 438,
          "recovered": 0,
          "id": "KE-10"
        },
        {
          "confirmed": 1479,
          "deaths": 33,
          "recovered": 0,
          "id": "KE-9"
        },
        {
          "confirmed": 1778,
          "deaths": 47,
          "recovered": 0,
          "id": "KE-8"
        },
        {
          "confirmed": 11510,
          "deaths": 494,
          "recovered": 0,
          "id": "KE-7"
        },
        {
          "confirmed": 6513,
          "deaths": 250,
          "recovered": 0,
          "id": "KE-6"
        },
        {
          "confirmed": 21706,
          "deaths": 605,
          "recovered": 0,
          "id": "KE-5"
        },
        {
          "confirmed": 3393,
          "deaths": 108,
          "recovered": 0,
          "id": "KE-4"
        },
        {
          "confirmed": 1228,
          "deaths": 25,
          "recovered": 0,
          "id": "KE-3"
        },
        {
          "confirmed": 3217,
          "deaths": 92,
          "recovered": 0,
          "id": "KE-2"
        },
        {
          "confirmed": 257,
          "deaths": 8,
          "recovered": 0,
          "id": "KE-1"
        }
      ]
    },
    {
      "date": "2020-04-12",
      "list": [
       
        
        {
          "confirmed": 727,
          "deaths": 27,
          "recovered": 15,
          "id": "KE-47"
        },
        {
          "confirmed": 5274,
          "deaths": 141,
          "recovered": 0,
          "id": "KE-46"
        },
        {
          "confirmed": 2207,
          "deaths": 18,
          "recovered": 0,
          "id": "KE-45"
        },
        {
          "confirmed": 13509,
          "deaths": 274,
          "recovered": 1617,
          "id": "KE-44"
        },
        {
          "confirmed": 5132,
          "deaths": 106,
          "recovered": 1386,
          "id": "KE-43"
        },
        {
          "confirmed": 730,
          "deaths": 6,
          "recovered": 189,
          "id": "KE-42"
        },
        {
          "confirmed": 3211,
          "deaths": 80,
          "recovered": 0,
          "id": "KE-41"
        },
        {
          "confirmed": 2665,
          "deaths": 63,
          "recovered": 35,
          "id": "KE-40"
        },
        {
          "confirmed": 22938,
          "deaths": 557,
          "recovered": 0,
          "id": "KE-39"
        },
        {
          "confirmed": 1447,
          "deaths": 51,
          "recovered": 0,
          "id": "KE-38"
        },
        {
          "confirmed": 1970,
          "deaths": 96,
          "recovered": 865,
          "id": "KE-37"
        },
        {
          "confirmed": 6602,
          "deaths": 253,
          "recovered": 0,
          "id": "KE-36"
        },
        {
          "confirmed": 18,
          "deaths": 9,
          "recovered": 14590,
          "id": "KE-35"
        },
        {
          "confirmed": 2836,
          "deaths": 112,
          "recovered": 0,
          "id": "KE-34"
        },
        {
          "confirmed": 1174,
          "deaths": 20,
          "recovered": 235,
          "id": "KE-33"
        },
        {
          "confirmed": 61850,
          "deaths": 2350,
          "recovered": 0,
          "id": "KE-32"
        },
        {
          "confirmed": 929,
          "deaths": 23,
          "recovered": 236,
          "id": "KE-31"
        },
        {
          "confirmed": 791,
          "deaths": 17,
          "recovered": 0,
          "id": "KE-30"
        },
        {
          "confirmed": 308,
          "deaths": 8,
          "recovered": 119,
          "id": "KE-29"
        },
        {
          "confirmed": 4570,
          "deaths": 89,
          "recovered": 0,
          "id": "KE-28"
        },
        {
          "confirmed": 387,
          "deaths": 6,
          "recovered": 169,
          "id": "KE-27"
        },
        {
          "confirmed": 2781,
          "deaths": 96,
          "recovered": 0,
          "id": "KE-26"
        },
        {
          "confirmed": 4469,
          "deaths": 125,
          "recovered": 0,
          "id": "KE-25"
        },
        {
          "confirmed": 1616,
          "deaths": 70,
          "recovered": 793,
          "id": "KE-24"
        },
        {
          "confirmed": 23605,
          "deaths": 1384,
          "recovered": 433,
          "id": "KE-23"
        },
        {
          "confirmed": 633,
          "deaths": 19,
          "recovered": 256,
          "id": "KE-22"
        },
        {
          "confirmed": 8225,
          "deaths": 236,
          "recovered": 431,
          "id": "KE-21"
        },
        {
          "confirmed": 22860,
          "deaths": 686,
          "recovered": 0,
          "id": "KE-20"
        },
        {
          "confirmed": 20595,
          "deaths": 840,
          "recovered": 0,
          "id": "KE-19"
        },
        {
          "confirmed": 1840,
          "deaths": 94,
          "recovered": 464,
          "id": "KE-18"
        },
        {
          "confirmed": 1323,
          "deaths": 56,
          "recovered": 0,
          "id": "KE-17"
        },
        {
          "confirmed": 7928,
          "deaths": 343,
          "recovered": 0,
          "id": "KE-16"
        },
        {
          "confirmed": 19180,
          "deaths": 677,
          "recovered": 0,
          "id": "KE-15"
        },
        {
          "confirmed": 1407,
          "deaths": 27,
          "recovered": 0,
          "id": "KE-14"
        },
        {
          "confirmed": 1510,
          "deaths": 34,
          "recovered": 585,
          "id": "KE-13"
        },
        {
          "confirmed": 486,
          "deaths": 8,
          "recovered": 300,
          "id": "KE-12"
        },
        {
          "confirmed": 12452,
          "deaths": 433,
          "recovered": 0,
          "id": "KE-11"
        },
        {
          "confirmed": 19347,
          "deaths": 452,
          "recovered": 0,
          "id": "KE-10"
        },
        {
          "confirmed": 1479,
          "deaths": 33,
          "recovered": 191,
          "id": "KE-9"
        },
        {
          "confirmed": 1875,
          "deaths": 50,
          "recovered": 447,
          "id": "KE-8"
        },
        {
          "confirmed": 11510,
          "deaths": 494,
          "recovered": 0,
          "id": "KE-7"
        },
        {
          "confirmed": 6897,
          "deaths": 275,
          "recovered": 0,
          "id": "KE-6"
        },
        {
          "confirmed": 22439,
          "deaths": 635,
          "recovered": 0,
          "id": "KE-5"
        },
        {
          "confirmed": 3542,
          "deaths": 115,
          "recovered": 0,
          "id": "KE-4"
        },
        {
          "confirmed": 1280,
          "deaths": 27,
          "recovered": 340,
          "id": "KE-3"
        },
        {
          "confirmed": 3450,
          "deaths": 93,
          "recovered": 0,
          "id": "KE-2"
        },
        {
          "confirmed": 257,
          "deaths": 8,
          "recovered": 63,
          "id": "KE-1"
        }
      ]
    }
  ]