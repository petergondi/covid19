var covid_us_total_timeline=[
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "date": "2020-02-05"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "date": "2020-02-06"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "date": "2020-02-07"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "date": "2020-02-08"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "date": "2020-02-09"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "date": "2020-02-10"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "date": "2020-02-11"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "date": "2020-02-12"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "date": "2020-02-13"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "date": "2020-02-14"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "date": "2020-02-15"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "date": "2020-02-16"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "date": "2020-02-17"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "date": "2020-02-18"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "date": "2020-02-19"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "date": "2020-02-20"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "date": "2020-02-21"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "date": "2020-02-22"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "date": "2020-02-23"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "date": "2020-02-24"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "date": "2020-02-25"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "date": "2020-02-26"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "date": "2020-02-27"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "date": "2020-02-28"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "date": "2020-02-29"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "date": "2020-03-01"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "date": "2020-03-02"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "date": "2020-03-03"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "date": "2020-03-04"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "date": "2020-03-05"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "date": "2020-03-06"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "date": "2020-03-07"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "date": "2020-03-08"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "date": "2020-03-09"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "date": "2020-03-10"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "date": "2020-03-11"
        },
        {
          "confirmed": 0,
          "deaths": 0,
          "recovered": 0,
          "date": "2020-03-12"
        },
        {
          "confirmed": 1,
          "deaths": 0,
          "recovered": 0,
          "date": "2020-03-13"
        },
        {
          "confirmed": 1,
          "deaths": 0,
          "recovered": 0,
          "date": "2020-03-14"
        },
        {
          "confirmed": 3,
          "deaths": 0,
          "recovered": 0,
          "date": "2020-03-15"
        },
        {
          "confirmed": 3,
          "deaths": 0,
          "recovered": 0,
          "date": "2020-03-16"
        },
        {
          "confirmed": 4,
          "deaths": 0,
          "recovered": 0,
          "date": "2020-03-17"
        },
        {
          "confirmed": 7,
          "deaths": 0,
          "recovered": 0,
          "date": "2020-03-18"
        },
        {
          "confirmed": 7,
          "deaths": 0,
          "recovered": 0,
          "date": "2020-03-19"
        },
        {
          "confirmed": 7,
          "deaths": 0,
          "recovered": 0,
          "date": "2020-03-20"
        },
        {
          "confirmed": 7,
          "deaths": 0,
          "recovered": 0,
          "date": "2020-03-21"
        },
        {
          "confirmed": 15,
          "deaths": 0,
          "recovered": 0,
          "date": "2020-03-22"
        },
        {
          "confirmed": 16,
          "deaths": 0,
          "recovered": 0,
          "date": "2020-03-23"
        },
        {
          "confirmed": 25,
          "deaths": 0,
          "recovered": 0,
          "date": "2020-03-24"
        },
        {
          "confirmed": 28,
          "deaths": 0,
          "recovered": 0,
          "date": "2020-03-25"
        },
        {
          "confirmed": 31,
          "deaths": 0,
          "recovered": 0,
          "date": "2020-03-26"
        },
        {
          "confirmed": 31,
          "deaths": 0,
          "recovered": 0,
          "date": "2020-03-27"
        },
        {
          "confirmed": 38,
          "deaths": 0,
          "recovered": 0,
          "date": "2020-03-28"
        },
        {
          "confirmed": 42,
          "deaths": 0,
          "recovered": 0,
          "date": "2020-03-29"
        },
        {
          "confirmed": 50,
          "deaths": 0,
          "recovered": 0,
          "date": "2020-03-30"
        },
        {
          "confirmed": 59,
          "deaths": 0,
          "recovered": 0,
          "date": "2020-03-31"
        },
        {
          "confirmed": 81,
          "deaths": 0,
          "recovered": 0,
          "date": "2020-04-01"
        },
        {
          "confirmed": 110,
          "deaths": 0,
          "recovered": 0,
          "date": "2020-04-02"
        },
        {
          "confirmed": 122,
          "deaths": 0,
          "recovered": 0,
          "date": "2020-04-03"
        },
        {
          "confirmed": 126,
          "deaths": 4,
          "recovered": 4,
          "date": "2020-04-04"
        },
        {
          "confirmed": 142,
          "deaths": 5,
          "recovered": 4,
          "date": "2020-04-05"
        },
        {
          "confirmed": 158,
          "deaths": 6,
          "recovered": 4,
          "date": "2020-04-06"
        },
        {
          "confirmed": 172,
          "deaths": 6,
          "recovered": 7,
          "date": "2020-04-07"
        },
        {
          "confirmed": 179,
          "deaths": 6,
          "recovered": 9,
          "date": "2020-04-08"
        },
        {
          "confirmed": 184,
          "deaths": 7,
          "recovered": 12,
          "date": "2020-04-09"
        },
        {
          "confirmed": 189,
          "deaths": 7,
          "recovered": 22,
          "date": "2020-04-10"
        },
        {
          "confirmed": 191,
          "deaths": 7,
          "recovered": 24,
          "date": "2020-04-11"
        },
        {
          "confirmed": 197,
          "deaths": 8,
          "recovered": 25,
          "date": "2020-04-12"
        },
        {
          "confirmed": 208,
          "deaths": 9,
          "recovered": 40,
          "date": "2020-04-13"
        },
        {
          "confirmed": 216,
          "deaths": 10,
          "recovered": 53,
          "date": "2020-04-14"
        },
        {
          "confirmed": 225,
          "deaths": 11,
          "recovered": 53,
          "date": "2020-04-15"
        },
        {
          "confirmed": 234,
          "deaths": 11,
          "recovered": 53,
          "date": "2020-04-16"
        },
        {
          "confirmed": 246,
          "deaths": 11,
          "recovered": 53,
          "date": "2020-04-17"
        },
        {
          "confirmed": 262,
          "deaths": 13,
          "recovered": 60,
          "date": "2020-04-18"
        }
       ]
  